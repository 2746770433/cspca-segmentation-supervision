# Third-party PI-CAI clinical information

`configs/official_marksheet.csv` is an unchanged copy of the PI-CAI public clinical-information marksheet published by DIAGNijmegen. It is not original data created by this repository's authors.

- Source repository: https://github.com/DIAGNijmegen/picai_labels
- Exact source file: https://github.com/DIAGNijmegen/picai_labels/blob/ce4a4723d7c46d882a6cbaacb40ed6c4be86282f/clinical_information/marksheet.csv
- Source commit: `ce4a4723d7c46d882a6cbaacb40ed6c4be86282f`
- Source license: Creative Commons Attribution-NonCommercial 4.0 International (https://github.com/DIAGNijmegen/picai_labels/blob/main/LICENSE)
- SHA-256 of the copied file: `23eab23790886258440b4af2842733332003f2c59f0a007b1e7b6b44572cf0ae`

The PI-CAI images and masks are not redistributed here. Use the original sources and comply with their terms when acquiring them. The split tables and prediction files in this repository reference de-identified PI-CAI study identifiers for reproducibility.
