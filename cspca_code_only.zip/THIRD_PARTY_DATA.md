# Third-party PI-CAI clinical information

The PI-CAI clinical-information marksheet is published by DIAGNijmegen. It is not redistributed in this code-only release. Obtain it from the source below and place it at `configs/official_marksheet.csv` if the evaluation scripts require it.

- Source repository: https://github.com/DIAGNijmegen/picai_labels
- Exact source file: https://github.com/DIAGNijmegen/picai_labels/blob/ce4a4723d7c46d882a6cbaacb40ed6c4be86282f/clinical_information/marksheet.csv
- Source commit: `ce4a4723d7c46d882a6cbaacb40ed6c4be86282f`
- Source license: Creative Commons Attribution-NonCommercial 4.0 International (https://github.com/DIAGNijmegen/picai_labels/blob/main/LICENSE)
- SHA-256 of the version used for this study: `23eab23790886258440b4af2842733332003f2c59f0a007b1e7b6b44572cf0ae`

The PI-CAI images and masks are not redistributed here. Use the original sources and comply with their terms when acquiring them. Study split tables and patient-level prediction files are not included in this code-only release.
