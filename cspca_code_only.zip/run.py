"""PyCharm: default action is checking, never training implicitly."""
import argparse
import subprocess
import sys
sys.dont_write_bytecode=True
from datetime import datetime
from settings import ROOT, MODELS, checkpoint, data_root, environment, settings

def call(script,*args):
    subprocess.run([sys.executable,'-u',str(ROOT/script),*map(str,args)],cwd=ROOT,env=environment(),check=True)

def main():
    p=argparse.ArgumentParser(description='Paper code: single-GPU training, checkpoint testing and analyses.')
    p.add_argument('action',nargs='?',default='check',choices=['check','train','train-scratch','pretrain','test','summarize','analyze','centers','clinical','errors','complexity','cases','preprocess'])
    p.add_argument('--model',choices=MODELS,default='mtl')
    p.add_argument('--seed',type=int,default=42,choices=[42,7,2026])
    p.add_argument('--device',default='cuda')
    p.add_argument('--smoke',action='store_true')
    p.add_argument('--dry-run',action='store_true')
    p.add_argument('--output-root',default='results/runs')
    p.add_argument('--step',type=int,choices=range(5),default=0)
    a=p.parse_args();s=settings()
    if a.action=='check':call('check.py',*(['--smoke'] if a.smoke else []))
    elif a.action=='train':
        call('training/run_multiseed.py','--project-root',ROOT,'--output-root',a.output_root,'--sequential','--gpu-override',s['gpu'],'--num-workers',s['num_workers'],'--epochs',s['epochs'],'--seeds',*s['seeds'],*(['--dry-run'] if a.dry_run else []))
    elif a.action=='train-scratch':call('training/train_scratch.py',*(['--dry-run'] if a.dry_run else []))
    elif a.action=='pretrain':call('training/train_pretraining.py')
    elif a.action=='preprocess':
        names=['step0_align_images_to_t2w.py','step1_build_dataset_master.py','step2_verify_and_repair_alignment.py','step3_build_patient_splits.py','step4_build_multitask_tables.py']
        call('preprocessing/'+names[a.step])
    elif a.action=='test':
        weight=checkpoint(a.model,a.seed)
        if not weight.is_file():raise FileNotFoundError(f'Place the selected checkpoint here: {weight}')
        output=ROOT/'results/retests'/a.model/f'seed_{a.seed}'/datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        call('evaluation/test_model.py','--branch-dir',ROOT/'training'/('mtl' if a.model=='mtl_scratch' else a.model),'--checkpoint',weight,'--test-table',ROOT/'configs/splits/test.xlsx','--project-root',data_root(),'--output-dir',output,'--device',a.device,'--num-workers',s['num_workers'],'--bootstrap',0,'--seed',a.seed,*(['--classification-only'] if a.model=='classification' else []))
    elif a.action=='summarize':call('evaluation/summarize_multiseed.py','--root',ROOT/'results/runs')
    elif a.action=='analyze':
        call('evaluation/analyze_main.py');call('evaluation/initialization.py');call('evaluation/clinical.py')
    elif a.action in ('clinical','errors'):call(f'evaluation/{a.action}.py')
    elif a.action=='centers':call('evaluation/centers.py','--project-root',data_root(),'--run-root',ROOT/'results/runs')
    elif a.action=='complexity':call('evaluation/complexity.py','--project-root',ROOT,'--device',a.device)
    elif a.action=='cases':call('evaluation/cases.py','--project-root',data_root(),'--run-root',ROOT/'results/runs','--device',a.device,'--checkpoint-seed',a.seed)

if __name__=='__main__':main()
