# 现有权重逐个放置

先复制，验证成功后再决定是否清理旧位置。当前所有权重位置留空。

| 实验 | 新位置 |
|---|---|
| 纯分割预训练 | `pretraining/best_model.pth` |
| 分类基线 | `classification/seed_42/best_cls_model.pth` |
| MTL | `mtl/seed_42/best_multitask_model.pth` |
| MTL+Focal | `mtl_focal/seed_42/best_multitask_model.pth` |
| 随机初始化MTL | `mtl_scratch/seed_42/best_multitask_model.pth` |

其他种子使用 `seed_7` 或 `seed_2026` 目录。下游目录也接受旧名称 `best_model.pth`，规范名和旧名同时存在时优先规范名。

每5轮保存的 `model_epoch_XXX.pth`、最后一轮及其他选择准则的权重，可以稍后放在同一模型/种子目录；统一测试入口目前自动选择预设评分的最佳模型，其他轮次需要明确指定 `evaluation/test_model.py --checkpoint`。

建议顺序：分割预训练 → 分类seed42 → MTL seed42 → MTL+Focal seed42 → 其他种子 → 随机初始化MTL。每次核对来源、模型类型、种子、检查点轮次及测试指标，再继续下一项。

以分类seed42为例，在PyCharm中运行根目录 `run.py`，脚本参数填写：

```text
test --model classification --seed 42 --device cuda
```

重新测试会写入 `results/retests/classification/seed_42/时间编号`，现有正式预测保留在 `results/runs`，可逐项比较。
