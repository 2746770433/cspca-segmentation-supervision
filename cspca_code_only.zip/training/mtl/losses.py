import torch
import torch.nn as nn
import torch.nn.functional as F


class DiceLoss(nn.Module):
    def __init__(self, smooth=1e-5):
        super(DiceLoss, self).__init__()
        self.smooth = smooth

    def forward(self, preds, targets):
        # preds: [B, 1, H, W, D] 或 [B, 1, D, H, W]
        # targets: [B, 1, H, W, D] 或 [B, 1, D, H, W]
        preds = torch.sigmoid(preds)

        # 展平
        preds_flat = preds.view(preds.size(0), -1)
        targets_flat = targets.view(targets.size(0), -1)

        intersection = (preds_flat * targets_flat).sum(dim=1)
        union = preds_flat.sum(dim=1) + targets_flat.sum(dim=1)

        dice = (2. * intersection + self.smooth) / (union + self.smooth)
        return 1.0 - dice.mean()


class MultiTaskLoss(nn.Module):
    def __init__(self, lambda_cls=0.05, pos_weight_val=7.5):
        """
        pos_weight_val: 论文实验在前期开发后固定的阳性类别权重
        """
        super().__init__()
        self.lambda_cls = lambda_cls

        # 动态检测可用设备，防止多卡或单卡训练时报错
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        pos_weight = torch.tensor([pos_weight_val], dtype=torch.float).to(device)

        self.seg_criterion = DiceLoss()
        self.cls_criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

    def forward(self, masks_pred, masks_gt, cls_logits, cls_labels, has_valid_mask):
        """
        masks_pred: [B, 1, D, H, W]
        masks_gt: [B, 1, D, H, W]
        cls_logits: [B, 1]
        cls_labels: [B, 1]
        has_valid_mask: [B, 1] - 指示该样本是否有有效Mask，只有为1时才计算分割损失
        """
        # 1. 分类损失 (所有样本都参与分类损失计算)
        loss_cls = self.cls_criterion(cls_logits, cls_labels)

        # 2. 分割损失 (只有阳性样本且有有效Mask的才计算分割损失)
        # has_valid_mask 维度为 [B, 1]，我们需要将其扩展到与 mask 相同的维度 [B, 1, D, H, W]
        weight_mask = has_valid_mask.view(-1, 1, 1, 1, 1).float()

        # 仅对有有效 mask 的样本计算 Dice Loss
        loss_seg = self.seg_criterion(masks_pred * weight_mask, masks_gt * weight_mask)

        # 3. 联合损失
        total_loss = loss_seg + self.lambda_cls * loss_cls

        return total_loss, loss_seg, loss_cls
