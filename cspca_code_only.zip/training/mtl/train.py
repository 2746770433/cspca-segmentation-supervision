import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import random
import numpy as np
import pandas as pd
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm
from sklearn.metrics import roc_auc_score, confusion_matrix
import matplotlib.pyplot as plt

from config import *
from dataset import ProstateMultiTaskDataset
from model import MultiTaskUNet3D
from losses import MultiTaskLoss




def set_seed(seed=42):
    random.seed(seed)
    np.seed = seed
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True


def calculate_dice(preds, targets, smooth=1e-5):
    """计算阳性样本的 Dice 相似系数"""
    preds = (torch.sigmoid(preds) > THRESHOLD).float()
    preds_flat = preds.view(-1)
    targets_flat = targets.view(-1)
    intersection = (preds_flat * targets_flat).sum()
    return ((2. * intersection + smooth) / (preds_flat.sum() + targets_flat.sum() + smooth)).item()


def save_visualization(image, mask_gt, mask_pred, label_gt, epoch, sample_idx, save_dir=VIS_DIR):
    img_np   = image.detach().cpu().numpy()
    gt_np    = mask_gt.detach().cpu().numpy()[0]       # [D, H, W]
    prob_np  = torch.sigmoid(mask_pred).detach().cpu().numpy()[0]
    pred_bin = (prob_np > THRESHOLD).astype(np.float32)

    # 选取 GT 有标注且预测 Dice 最高的切片，否则取中间切片
    gt_slices = np.where(gt_np.sum(axis=(1, 2)) > 0)[0]
    if len(gt_slices) > 0:
        best_slice = max(
            gt_slices,
            key=lambda z: (2 * (pred_bin[z] * gt_np[z]).sum() /
                           (pred_bin[z].sum() + gt_np[z].sum() + 1e-5))
        )
    else:
        best_slice = img_np.shape[1] // 2

    slice_img  = img_np[0, best_slice, :, :]
    slice_gt   = gt_np[best_slice, :, :]
    slice_pred = pred_bin[best_slice, :, :]
    slice_prob = prob_np[best_slice, :, :]

    fig, axes = plt.subplots(1, 4, figsize=(20, 5))
    fig.suptitle(f"Sample: {sample_idx:02d} | Slice: {best_slice} | Epoch: {epoch}", fontsize=13)

    axes[0].imshow(slice_img, cmap="gray")
    axes[0].set_title("MRI Image")
    axes[0].axis("off")

    axes[1].imshow(slice_img, cmap="gray")
    if slice_gt.max() > 0:
        axes[1].imshow(np.ma.masked_where(slice_gt == 0, slice_gt), cmap="Reds", alpha=0.6, vmin=0, vmax=1)
    axes[1].set_title("GT Mask")
    axes[1].axis("off")

    axes[2].imshow(slice_img, cmap="gray")
    if slice_pred.max() > 0:
        axes[2].imshow(np.ma.masked_where(slice_pred == 0, slice_pred), cmap="Blues", alpha=0.6, vmin=0, vmax=1)
    axes[2].set_title(f"Pred (Thresh={THRESHOLD})")
    axes[2].axis("off")

    im = axes[3].imshow(slice_prob, cmap="jet", vmin=0.0, vmax=1.0)
    axes[3].set_title("Prob Map")
    axes[3].axis("off")
    fig.colorbar(im, ax=axes[3], fraction=0.046, pad=0.04, ticks=[0.0, 0.2, 0.4, 0.6, 0.8, 1.0])

    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, f"epoch_{epoch:03d}_sample_{sample_idx:02d}.png"), bbox_inches="tight", dpi=150)
    plt.close()



def load_pretrained_weights(model, checkpoint_path):
    if not os.path.exists(checkpoint_path):
        print(f"⚠️ 未找到预训练权重文件: {checkpoint_path}，将从头开始训练。")
        return model

    print(f"🔥 检测到 Baseline 预训练权重: {checkpoint_path}")
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    pretrained_dict = checkpoint["model_state_dict"] if "model_state_dict" in checkpoint else checkpoint
    model_dict = model.state_dict()

    cleaned_pretrained_dict = {k.replace("module.", ""): v for k, v in pretrained_dict.items()}
    state_dict_to_load = {}
    matched_count = 0

    for model_key in model_dict.keys():
        if model_key in cleaned_pretrained_dict:
            state_dict_to_load[model_key] = cleaned_pretrained_dict[model_key]
            matched_count += 1
        else:
            for pt_key in cleaned_pretrained_dict.keys():
                if pt_key in model_key or model_key in pt_key:
                    state_dict_to_load[model_key] = cleaned_pretrained_dict[pt_key]
                    matched_count += 1
                    break

    if matched_count > 0:
        model_dict.update(state_dict_to_load)
        model.load_state_dict(model_dict)
        print(f"✅ 成功匹配并载入 {matched_count} 个权重 Key 到 Backbone 中！")
    return model


def main():
    set_seed(SEED)

    # ✅ 直接读取 train_mul / val_mul，无需合并
    print("📂 正在加载数据表...")
    train_df = pd.read_excel(TRAIN_TABLE)
    val_df   = pd.read_excel(VAL_TABLE)

    # 统一清洗 has_valid_human_mask 列
    for df in [train_df, val_df]:
        df["has_valid_human_mask_clean"] = df["has_valid_human_mask"].apply(
            lambda x: str(x).strip().upper() in ["TRUE", "1", "1.0"]
            if not pd.isna(x) else False
        )

    # 统计分布
    def print_stats(name, df):
        seg_pos = df["has_valid_human_mask_clean"].sum()
        cls_pos = (df["cspca_label"] == 1).sum()
        cls_neg = (df["cspca_label"] == 0).sum()
        print(f"  [{name}] 总样本: {len(df)} | "
              f"分割阳性(有mask): {seg_pos} | "
              f"分类阳性: {cls_pos} | 分类阴性: {cls_neg}")

    print("\n📊 数据集分布:")
    print_stats("Train", train_df)
    print_stats("Val  ", val_df)

    # ✅ Dataset 直接使用完整表（内部通过 has_valid_human_mask 区分任务）
    train_loader = DataLoader(
        ProstateMultiTaskDataset(train_df, mode="train",
                                 target_shape=TARGET_SHAPE,
                                 crop_shape=CROP_SHAPE,
                                 use_roi_crop=USE_ROI_CROP),
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=NUM_WORKERS,
        pin_memory=True,
    )

    val_loader = DataLoader(
        ProstateMultiTaskDataset(val_df, mode="val",
                                 target_shape=TARGET_SHAPE,
                                 crop_shape=CROP_SHAPE,
                                 use_roi_crop=USE_ROI_CROP),
        batch_size=1,
        shuffle=False,
        num_workers=NUM_WORKERS,
        pin_memory=True,
    )

    # 后续模型初始化、训练循环保持不变...


    # 4. 初始化模型
    model = MultiTaskUNet3D(in_channels=3, out_channels=1, base_channels=32, backbone=BACKBONE).to(DEVICE)
    model = load_pretrained_weights(model, os.path.join(BASE_DIR,
                                                        str(Path(__file__).resolve().parents[2] / "weights/pretraining/best_model.pth")))

    # 5. 降低分类 Loss 权重以保护分割 (lambda_cls 从 0.1 降到 0.05)
    criterion = MultiTaskLoss(lambda_cls=0.05)

    # ==================== 【确保 100% 精确冻结 Backbone 参数】 ====================
    # 明确指定：除了 cls_head 之外，所有的参数（即 self.net 内部的所有参数）都属于 Backbone
    backbone_params = [p for n, p in model.named_parameters() if "cls_head" not in n]
    head_params = [p for n, p in model.named_parameters() if "cls_head" in n]

    # 初始状态：彻底冻结 Backbone
    for param in backbone_params:
        param.requires_grad = False

    optimizer = torch.optim.AdamW([{"params": head_params, "lr": LR}], weight_decay=WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS, eta_min=1e-6)

    best_composite_score = -999.0
    backbone_unfrozen = False
    os.makedirs(CHECKPOINT_DIR, exist_ok=True)

    print(f"\n🚀 开始多任务联合训练... 设备: {DEVICE}")

    # 6. 训练主循环
    for epoch in range(1, EPOCHS + 1):
        # 第 11 轮解冻 Backbone，并使用极低的学习率微调
        if epoch > 10 and not backbone_unfrozen:
            print("\n🔓 [解冻提示] 10 轮已满，正在解冻 Backbone 进行联合微调...")
            for param in backbone_params:
                param.requires_grad = True
            # Backbone 学习率设为 LR * 0.1，Head 设为 LR * 0.5
            optimizer = torch.optim.AdamW([
                {"params": backbone_params, "lr": LR * 0.1},
                {"params": head_params, "lr": LR * 0.5}
            ], weight_decay=WEIGHT_DECAY)
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS - 10, eta_min=1e-6)
            backbone_unfrozen = True

        # ==================== 【核心保护：锁定归一化层统计量】 ====================
        model.train()
        if not backbone_unfrozen:
            # 在 Backbone 冻结期间，强制将其中的 InstanceNorm3d/BatchNorm3d 设为 eval 模式
            # 这样可以防止阴性样本的特征统计量冲垮预训练好的归一化均值和方差
            for name, module in model.named_modules():
                if "cls_head" not in name:
                    if isinstance(module, (nn.BatchNorm3d, nn.InstanceNorm3d)):
                        module.eval()
        # ====================================================================

        epoch_loss = 0.0
        epoch_loss_seg = 0.0
        epoch_loss_cls = 0.0

        train_preds, train_targets = [], []
        train_dices = []

        progress_bar = tqdm(
            train_loader,
            desc=f"Epoch {epoch:03d}/{EPOCHS:03d}",
            ncols=120,
            bar_format="{l_bar}{bar:10}{r_bar}"
        )

        for batch in progress_bar:
            # 自适应解析 Batch 格式
            if isinstance(batch, dict):
                images = batch["image"].to(DEVICE)
                masks_gt = batch["mask"].to(DEVICE)
                labels_gt = batch["label"].to(DEVICE).unsqueeze(1).float()
                has_valid_mask = batch["has_valid_mask"].to(DEVICE).unsqueeze(1)
            elif isinstance(batch, (list, tuple)):
                if len(batch) == 4:
                    images, masks_gt, labels_gt, has_valid_mask = batch
                elif len(batch) == 3:
                    images, masks_gt, labels_gt = batch
                    has_valid_mask = labels_gt.clone()
                elif isinstance(batch[0], dict):
                    images = torch.stack([item["image"] for item in batch]).to(DEVICE)
                    masks_gt = torch.stack([item["mask"] for item in batch]).to(DEVICE)
                    labels_gt = torch.tensor([item["label"] for item in batch]).to(DEVICE).unsqueeze(1).float()
                    has_valid_mask = torch.tensor([item["has_valid_mask"] for item in batch]).to(DEVICE).unsqueeze(1)

                images = images.to(DEVICE)
                masks_gt = masks_gt.to(DEVICE)
                labels_gt = labels_gt.unsqueeze(1).float().to(DEVICE) if labels_gt.dim() == 1 else labels_gt.float().to(DEVICE)
                has_valid_mask = has_valid_mask.unsqueeze(1).to(DEVICE) if has_valid_mask.dim() == 1 else has_valid_mask.to(DEVICE)

            optimizer.zero_grad()
            masks_pred, cls_logits = model(images)
            loss, loss_seg, loss_cls = criterion(masks_pred, masks_gt, cls_logits, labels_gt, has_valid_mask)

            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

            epoch_loss += loss.item()
            epoch_loss_seg += loss_seg.item()
            epoch_loss_cls += loss_cls.item()

            train_preds.extend(torch.sigmoid(cls_logits).detach().cpu().numpy())
            train_targets.extend(labels_gt.cpu().numpy())

            for i in range(images.size(0)):
                if has_valid_mask[i].item() == 1:
                    step_dice = calculate_dice(masks_pred[i:i + 1], masks_gt[i:i + 1])
                    train_dices.append(step_dice)

            current_dice = np.mean(train_dices) if len(train_dices) > 0 else 0.0
            progress_bar.set_postfix({
                "Loss": f"{loss.item():.3f}",
                "Seg": f"{loss_seg.item():.3f}",
                "Cls": f"{loss_cls.item():.3f}",
                "Dice": f"{current_dice:.3f}"
            })

        scheduler.step()

        avg_loss = epoch_loss / len(train_loader)
        train_auc = roc_auc_score(train_targets, train_preds) if len(np.unique(train_targets)) > 1 else 0.5
        train_dice = np.mean(train_dices) if len(train_dices) > 0 else 0.0

        # 7. 验证阶段 (混合验证集)
        model.eval()
        val_dices = []
        val_preds, val_targets = [], []
        val_vis_pool = []  # 只收集 has_valid_mask=True 的样本


        if len(val_loader) > 0:
            with torch.no_grad():
                for idx, batch in enumerate(val_loader):
                    if isinstance(batch, dict):
                        images = batch["image"].to(DEVICE)
                        masks_gt = batch["mask"].to(DEVICE)
                        labels_gt = batch["label"].to(DEVICE)
                    elif isinstance(batch, (list, tuple)):
                        images, masks_gt, labels_gt = batch[0], batch[1], batch[2]

                    images = images.to(DEVICE)
                    masks_gt = masks_gt.to(DEVICE)

                    masks_pred, cls_logits = model(images)

                    # ==================== 【核心修正：严格对齐有效分割标注】 ====================
                    # 只有当验证样本真正具有分割标注（masks_gt 不全为 0）时，才计算验证 Dice
                    if masks_gt.sum() > 0:
                        val_dice = calculate_dice(masks_pred, masks_gt)
                        val_dices.append(val_dice)
                    # ====================================================================

                    val_preds.append(torch.sigmoid(cls_logits).item())
                    val_targets.append(int(labels_gt.item()))

                    # 只收集 has_valid_human_mask=True 的样本（masks_gt 不全为0即有效）
                    if masks_gt.sum() > 0 and len(val_vis_pool) < 4:
                        val_vis_pool.append((images[0], masks_gt[0], masks_pred[0], int(labels_gt.item())))

            # 计算验证集指标
            val_targets_np = np.array(val_targets)
            val_preds_np = np.array(val_preds)

            avg_val_dice = np.mean(val_dices) if len(val_dices) > 0 else 0.0
            val_auc = roc_auc_score(val_targets_np, val_preds_np) if len(np.unique(val_targets_np)) > 1 else 0.5
            '''
            # 计算分类假阳性率 (FPR)
            val_preds_bin = (val_preds_np > 0.5).astype(int)
            tn, fp, fn, tp = confusion_matrix(val_targets_np, val_preds_bin, labels=[0, 1]).ravel()
            val_fpr = fp / (fp + tn + 1e-8)

            # ==================== 【多维度联合评分机制】 ====================
            # 目标：Dice 不明显下降（以 0.50 为底线），同时最大化 AUC 并降低 FPR
            dice_penalty = 0.0 if avg_val_dice >= 0.50 else (0.50 - avg_val_dice) * 3.0
            composite_score = val_auc - val_fpr - dice_penalty
            # ===============================================================

            current_lr = optimizer.param_groups[0]['lr']
            print(
                f"✨ [Epoch {epoch:03d} 结束] Loss: {avg_loss:.4f} | Val Dice: {avg_val_dice:.4f} | Val AUC: {val_auc:.4f} | Val FPR: {val_fpr:.4f} | Score: {composite_score:.4f}")

            # 每轮强制保存可视化图片（直观呈现假阳性病灶）
            print(f"🎨 [每轮可视化] 正在保存 Epoch {epoch:03d} 典型样本的分割对比图...")
            random.shuffle(val_vis_pool)
            for i, (img, gt, pred, lbl) in enumerate(val_vis_pool[:4]):
                save_visualization(img, gt, pred, lbl, epoch=epoch, sample_idx=i + 1)

            # 保存最佳模型 (基于综合评分 Composite Score)
            if composite_score > best_composite_score:
                best_composite_score = composite_score
                torch.save({
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "best_score": best_composite_score,
                    "val_dice": avg_val_dice,
                    "val_auc": val_auc,
                    "val_fpr": val_fpr
                }, MODEL_SAVE_PATH)
                print(f"🌟 发现更好的多任务平衡模型！已更新 best_model.pth")
                print(
                    f"   [新纪录] Score: {best_composite_score:.4f} (Dice: {avg_val_dice:.4f}, AUC: {val_auc:.4f}, FPR: {val_fpr:.4f})")

            # 每 5 轮定期保存
            if epoch % 5 == 0:
                epoch_save_path = os.path.join(CHECKPOINT_DIR, f"model_epoch_{epoch:03d}.pth")
                torch.save({
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "val_dice": avg_val_dice,
                    "val_auc": val_auc,
                    "val_fpr": val_fpr
                }, epoch_save_path)
                print(f"💾 [定期备份] 已保存第 {epoch} 轮模型至: {epoch_save_path}")
            '''
            # 计算分类假阳性率 (FPR) 和 真阳性率 (TPR)
            val_preds_bin = (val_preds_np > 0.5).astype(int)
            tn, fp, fn, tp = confusion_matrix(val_targets_np, val_preds_bin, labels=[0, 1]).ravel()
            val_fpr = fp / (fp + tn + 1e-8)
            val_tpr = tp / (tp + fn + 1e-8)  # ✅ 新增：计算 TPR

            # ==================== 【贴合临床目标的终极评分机制】 ====================
            # 优先级1: 显著性癌症分辨 -> 赋予 AUC 最高权重 (x2.0)，并奖励高 TPR
            # 优先级2: 降低假阳性 -> 强力惩罚高 FPR (x1.5)
            # 优先级3: Dice不降太多 -> 设定 0.55 为安全底线，低于则重罚
            dice_penalty = 0.0 if avg_val_dice >= 0.55 else (0.55 - avg_val_dice) * 5.0
            composite_score = (val_auc * 2.0) + val_tpr - (val_fpr * 1.5) - dice_penalty
            # ===============================================================

            current_lr = optimizer.param_groups[0]['lr']
            # ✅ 新增：日志打印加入 Val TPR
            print(
                f"✨ [Epoch {epoch:03d} 结束] Loss: {avg_loss:.4f} | Val Dice: {avg_val_dice:.4f} | Val AUC: {val_auc:.4f} | Val FPR: {val_fpr:.4f} | Val TPR: {val_tpr:.4f} | Score: {composite_score:.4f}")

            # 每轮强制保存可视化图片（直观呈现假阳性病灶）
            print(f"🎨 [每轮可视化] 正在保存 Epoch {epoch:03d} 典型样本的分割对比图...")
            random.shuffle(val_vis_pool)
            for i, (img, gt, pred, lbl) in enumerate(val_vis_pool[:4]):
                save_visualization(img, gt, pred, lbl, epoch=epoch, sample_idx=i + 1)

            # 保存最佳模型 (基于综合评分 Composite Score)
            if composite_score > best_composite_score:
                best_composite_score = composite_score
                torch.save({
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "best_score": best_composite_score,
                    "val_dice": avg_val_dice,
                    "val_auc": val_auc,
                    "val_fpr": val_fpr,
                    "val_tpr": val_tpr  # ✅ 新增：将 TPR 存入权重字典
                }, MODEL_SAVE_PATH)
                print(f"🌟 发现更好的多任务平衡模型！已更新 best_model.pth")
                # ✅ 新增：最佳记录打印 TPR
                print(
                    f"   [新纪录] Score: {best_composite_score:.4f} (Dice: {avg_val_dice:.4f}, AUC: {val_auc:.4f}, FPR: {val_fpr:.4f}, TPR: {val_tpr:.4f})")

            # 每 5 轮定期保存
            if epoch % 5 == 0:
                epoch_save_path = os.path.join(CHECKPOINT_DIR, f"model_epoch_{epoch:03d}.pth")
                torch.save({
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "val_dice": avg_val_dice,
                    "val_auc": val_auc,
                    "val_fpr": val_fpr,
                    "val_tpr": val_tpr  # ✅ 新增：将 TPR 存入定期备份
                }, epoch_save_path)
                print(f"💾 [定期备份] 已保存第 {epoch} 轮模型至: {epoch_save_path}")

        else:
            print(f"✨ [Epoch {epoch:03d} 结束] Avg Loss: {avg_loss:.4f}")


if __name__ == "__main__":
    main()