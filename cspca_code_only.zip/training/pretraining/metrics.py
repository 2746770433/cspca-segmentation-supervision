import torch


def dice_coefficient(logits, targets, threshold=0.5, smooth=1e-5):
    """
    logits : [B, 1, D, H, W]
    targets: [B, 1, D, H, W]
    """
    probs = torch.sigmoid(logits)
    preds = (probs >= threshold).float()

    preds = preds.contiguous().view(preds.size(0), -1)
    targets = targets.contiguous().view(targets.size(0), -1).float()

    intersection = (preds * targets).sum(dim=1)
    union = preds.sum(dim=1) + targets.sum(dim=1)

    dice = (2.0 * intersection + smooth) / (union + smooth)

    return dice.mean().item()


def iou_score(logits, targets, threshold=0.5, smooth=1e-5):
    """
    logits : [B, 1, D, H, W]
    targets: [B, 1, D, H, W]
    """
    probs = torch.sigmoid(logits)
    preds = (probs >= threshold).float()

    preds = preds.contiguous().view(preds.size(0), -1)
    targets = targets.contiguous().view(targets.size(0), -1).float()

    intersection = (preds * targets).sum(dim=1)
    union = preds.sum(dim=1) + targets.sum(dim=1) - intersection

    iou = (intersection + smooth) / (union + smooth)

    return iou.mean().item()


def sensitivity_score(logits, targets, threshold=0.5, smooth=1e-5):
    """
    sensitivity / recall
    """
    probs = torch.sigmoid(logits)
    preds = (probs >= threshold).float()

    preds = preds.contiguous().view(preds.size(0), -1)
    targets = targets.contiguous().view(targets.size(0), -1).float()

    tp = (preds * targets).sum(dim=1)
    fn = ((1.0 - preds) * targets).sum(dim=1)

    sens = (tp + smooth) / (tp + fn + smooth)

    return sens.mean().item()


def precision_score(logits, targets, threshold=0.5, smooth=1e-5):
    """
    precision
    """
    probs = torch.sigmoid(logits)
    preds = (probs >= threshold).float()

    preds = preds.contiguous().view(preds.size(0), -1)
    targets = targets.contiguous().view(targets.size(0), -1).float()

    tp = (preds * targets).sum(dim=1)
    fp = (preds * (1.0 - targets)).sum(dim=1)

    prec = (tp + smooth) / (tp + fp + smooth)

    return prec.mean().item()
