import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

import csv
import random
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
import matplotlib.pyplot as plt

from config import (
    TRAIN_MUL_TABLE,  # 改为读取多任务对齐表
    VAL_MUL_TABLE,  # 改为读取多任务对齐表
    CHECKPOINT_DIR,
    VIS_DIR,
    VAL_RATIO,
    SEED,
    IN_CHANNELS,
    OUT_CHANNELS,
    BASE_CHANNELS,
    TARGET_SHAPE,
    CROP_SHAPE,
    USE_ROI_CROP,
    ROI_MARGIN,
    BATCH_SIZE,
    NUM_WORKERS,
    EPOCHS,
    LR,
    WEIGHT_DECAY,
    THRESHOLD,
    DEVICE,
    BEST_MODEL_NAME,
    LAST_MODEL_NAME,
    NUM_VIS_CASES,
    VIS_MODALITY,
    DICE_WEIGHT,
    BCE_WEIGHT,
    POS_WEIGHT,
)

from dataset_seg import PositiveSegDataset
# from model_nnunet3d import NNUNet3D
from model_3dunet import UNet3D
from losses import WeightedBCEDiceLoss

from metrics import (
    dice_coefficient,
    iou_score,
    sensitivity_score,
    precision_score,
)


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True
    torch.backends.cudnn.deterministic = False


# =========================================================
# 替换原有的随机划分，直接读取对齐的多任务表格并过滤
# =========================================================
def load_aligned_train_val_dfs(train_table_path, val_table_path):
    print(f"📖 正在载入多任务对齐的原始表格...")
    train_df = pd.read_excel(train_table_path)
    val_df = pd.read_excel(val_table_path)

    # 排除已知裁剪异常病例
    exclude_patient_ids = ["11475"]

    # 1. 过滤训练集：必须有有效 mask，且排除异常病例
    train_df = train_df[
        (train_df["has_valid_human_mask"] == True) &
        (train_df["mask_path_human"].notna())
        ].reset_index(drop=True)

    before_exclude_t = len(train_df)
    train_df = train_df[~train_df["patient_id"].astype(str).isin(exclude_patient_ids)].reset_index(drop=True)
    print(f"   [Train] 排除异常病患 {exclude_patient_ids}: {before_exclude_t} -> {len(train_df)}")

    # 2. 过滤验证集：必须有有效 mask，且排除异常病例
    val_df = val_df[
        (val_df["has_valid_human_mask"] == True) &
        (val_df["mask_path_human"].notna())
        ].reset_index(drop=True)

    before_exclude_v = len(val_df)
    val_df = val_df[~val_df["patient_id"].astype(str).isin(exclude_patient_ids)].reset_index(drop=True)
    print(f"   [Val]   排除异常病患 {exclude_patient_ids}: {before_exclude_v} -> {len(val_df)}")

    print(f"📊 [对齐完成] 纯分割训练集: {len(train_df)} 例 | 纯分割验证集: {len(val_df)} 例")
    return train_df, val_df


def init_log_file(log_path):
    with open(log_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "epoch", "train_loss", "train_dice_loss", "train_bce_loss", "train_dice", "train_iou", "train_sens",
            "train_prec",
            "val_loss", "val_dice_loss", "val_bce_loss", "val_dice", "val_iou", "val_sens", "val_prec", "lr"
        ])


def append_log_file(log_path, epoch, t_loss, t_dice_l, t_bce, t_dice, t_iou, t_sens, t_prec, v_loss, v_dice_l, v_bce,
                    v_dice, v_iou, v_sens, v_prec, lr):
    with open(log_path, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(
            [epoch, t_loss, t_dice_l, t_bce, t_dice, t_iou, t_sens, t_prec, v_loss, v_dice_l, v_bce,
             v_dice, v_iou, v_sens, v_prec, lr])


@torch.no_grad()
def save_validation_visualization(model, val_loader, device, epoch, vis_dir, threshold=0.5, num_cases=4,
                                  modality_index=0):
    model.eval()
    epoch_vis_dir = os.path.join(vis_dir, f"epoch_{epoch:03d}")
    os.makedirs(epoch_vis_dir, exist_ok=True)
    saved = 0

    for batch in val_loader:
        images = batch["image"].to(device, non_blocking=True)
        masks = batch["mask"].to(device, non_blocking=True)
        patient_ids = batch.get("patient_id", None)

        logits = model(images)
        probs = torch.sigmoid(logits)
        preds = (probs >= threshold).float()

        for i in range(images.shape[0]):
            if saved >= num_cases:
                return
            image_i = images[i, modality_index].cpu().numpy()
            mask_i = masks[i, 0].cpu().numpy()
            pred_i = preds[i, 0].cpu().numpy()
            prob_i = probs[i, 0].cpu().numpy()

            mask_per_slice = mask_i.reshape(mask_i.shape[0], -1).sum(axis=1)
            z = int(mask_per_slice.argmax()) if mask_per_slice.max() > 0 else mask_i.shape[0] // 2

            fig, axes = plt.subplots(1, 4, figsize=(16, 4))
            axes[0].imshow(image_i[z], cmap="gray")
            axes[0].set_title("MRI Image")
            axes[0].axis("off")

            axes[1].imshow(image_i[z], cmap="gray")
            axes[1].imshow(mask_i[z], cmap="Reds", alpha=0.4)
            axes[1].set_title("GT Mask")
            axes[1].axis("off")

            axes[2].imshow(image_i[z], cmap="gray")
            axes[2].imshow(pred_i[z], cmap="Blues", alpha=0.4)
            axes[2].set_title(f"Pred (Thresh={threshold})")
            axes[2].axis("off")

            im = axes[3].imshow(prob_i[z], cmap="jet", vmin=0, vmax=1)
            axes[3].set_title("Prob Map")
            axes[3].axis("off")
            fig.colorbar(im, ax=axes[3])

            pid = patient_ids[i] if patient_ids else f"idx_{saved}"
            plt.suptitle(f"Patient: {pid} | Slice: {z} | Epoch: {epoch}")
            plt.savefig(os.path.join(epoch_vis_dir, f"{pid}_slice_{z}.png"), bbox_inches="tight", dpi=150)
            plt.close()
            saved += 1


def train_one_epoch(model, loader, optimizer, criterion, device, epoch):
    model.train()
    total_loss, total_dice_loss, total_bce_loss = 0.0, 0.0, 0.0
    total_dice, total_iou, total_sens, total_prec = 0.0, 0.0, 0.0, 0.0

    # 💡 100% 还原你原本带 tqdm 的训练进度条
    for step, batch in enumerate(tqdm(loader, desc=f"Epoch {epoch:03d} [Train]")):
        images = batch["image"].to(device, non_blocking=True)
        masks = batch["mask"].to(device, non_blocking=True)

        optimizer.zero_grad()
        logits = model(images)

        # 100% 还原你原本的 Loss 调用，不传任何额外参数
        loss, dice_loss, bce_loss = criterion(logits, masks)

        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        total_dice_loss += dice_loss.item()
        total_bce_loss += bce_loss.item()

        with torch.no_grad():
            total_dice += float(dice_coefficient(logits, masks, threshold=THRESHOLD))
            total_iou += float(iou_score(logits, masks, threshold=THRESHOLD))
            total_sens += float(sensitivity_score(logits, masks, threshold=THRESHOLD))
            total_prec += float(precision_score(logits, masks, threshold=THRESHOLD))

    n = len(loader)
    return {
        "loss": total_loss / n, "dice_loss": total_dice_loss / n, "bce_loss": total_bce_loss / n,
        "dice": total_dice / n, "iou": total_iou / n, "sens": total_sens / n, "prec": total_prec / n
    }


@torch.no_grad()
def validate(model, loader, criterion, device):
    model.eval()
    total_loss, total_dice_loss, total_bce_loss = 0.0, 0.0, 0.0

    all_dices = []
    all_ious = []
    all_sens = []
    all_precs = []

    # 💡 100% 还原你原本带 tqdm 的验证进度条
    for batch in tqdm(loader, desc="[Val]"):
        images = batch["image"].to(device, non_blocking=True)
        masks = batch["mask"].to(device, non_blocking=True)

        logits = model(images)

        # 100% 还原你原本的 Loss 调用，不传任何额外参数
        loss, dice_loss, bce_loss = criterion(logits, masks)

        total_loss += loss.item()
        total_dice_loss += dice_loss.item()
        total_bce_loss += bce_loss.item()

        probs = torch.sigmoid(logits)
        preds = (probs >= THRESHOLD).float()
        targets = masks.float()

        for i in range(images.size(0)):
            pred_i = preds[i, 0].contiguous().view(-1)
            target_i = targets[i, 0].contiguous().view(-1)

            tp = (pred_i * target_i).sum().item()
            fp = (pred_i * (1.0 - target_i)).sum().item()
            fn = ((1.0 - pred_i) * target_i).sum().item()

            smooth = 1e-5
            dice_i = (2.0 * tp + smooth) / (2.0 * tp + fp + fn + smooth)
            iou_i = (tp + smooth) / (tp + fp + fn + smooth)
            sens_i = (tp + smooth) / (tp + fn + smooth)
            prec_i = (tp + smooth) / (tp + fp + smooth)

            all_dices.append(dice_i)
            all_ious.append(iou_i)
            all_sens.append(sens_i)
            all_precs.append(prec_i)

    num_batches = len(loader)
    num_samples = len(all_dices)

    return {
        "loss": total_loss / num_batches,
        "dice_loss": total_dice_loss / num_batches,
        "bce_loss": total_bce_loss / num_batches,
        "dice": np.mean(all_dices) if num_samples > 0 else 0.0,
        "iou": np.mean(all_ious) if num_samples > 0 else 0.0,
        "sens": np.mean(all_sens) if num_samples > 0 else 0.0,
        "prec": np.mean(all_precs) if num_samples > 0 else 0.0
    }


def main():
    set_seed(SEED)

    # 1. 改为直接读取多任务对齐表格
    train_df, val_df = load_aligned_train_val_dfs(TRAIN_MUL_TABLE, VAL_MUL_TABLE)

    # 2. 实例化数据集 (100% 保持你原本的参数和数据增强设置)
    train_dataset = PositiveSegDataset(
        df=train_df,
        mode="train",
        target_shape=TARGET_SHAPE,
        crop_shape=CROP_SHAPE,
        use_roi_crop=USE_ROI_CROP,
        augment=True
    )
    val_dataset = PositiveSegDataset(
        df=val_df,
        mode="val",
        target_shape=TARGET_SHAPE,
        crop_shape=CROP_SHAPE,
        use_roi_crop=USE_ROI_CROP,
        augment=False
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=NUM_WORKERS,
        pin_memory=True,
        drop_last=True
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=NUM_WORKERS,
        pin_memory=True,
        drop_last=False
    )

    model = UNet3D(in_channels=IN_CHANNELS, out_channels=OUT_CHANNELS, base_channels=BASE_CHANNELS).to(DEVICE)
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS, eta_min=1e-6)
    criterion = WeightedBCEDiceLoss(bce_weight=BCE_WEIGHT, dice_weight=DICE_WEIGHT, pos_weight=POS_WEIGHT)

    log_path = CHECKPOINT_DIR / "train_log.csv"
    init_log_file(log_path)

    best_dice = 0.0
    print("\n🚀 开始纯物理空间 ROI 裁剪 3D 分割训练...")

    for epoch in range(1, EPOCHS + 1):
        train_metrics = train_one_epoch(model, train_loader, optimizer, criterion, DEVICE, epoch)
        val_metrics = validate(model, val_loader, criterion, DEVICE)
        scheduler.step()

        current_lr = optimizer.param_groups[0]["lr"]
        append_log_file(
            log_path, epoch,
            train_metrics["loss"], train_metrics["dice_loss"], train_metrics["bce_loss"], train_metrics["dice"],
            train_metrics["iou"], train_metrics["sens"], train_metrics["prec"],
            val_metrics["loss"], val_metrics["dice_loss"], val_metrics["bce_loss"], val_metrics["dice"],
            val_metrics["iou"], val_metrics["sens"], val_metrics["prec"],
            current_lr
        )

        print(
            f"[Epoch {epoch:03d}/{EPOCHS}] "
            f"Train Loss: {train_metrics['loss']:.4f} | Dice: {train_metrics['dice']:.4f} | "
            f"Val Loss: {val_metrics['loss']:.4f} | Dice: {val_metrics['dice']:.4f} | LR: {current_lr:.6f}"
        )

        # 保存最佳模型
        if val_metrics["dice"] > best_dice:
            best_dice = val_metrics["dice"]
            torch.save(model.state_dict(), CHECKPOINT_DIR / BEST_MODEL_NAME)
            print(f"🔥 发现更佳模型，已保存至 {BEST_MODEL_NAME} (Best Val Dice: {best_dice:.4f})")

        # 每一轮保存最新模型
        torch.save(model.state_dict(), CHECKPOINT_DIR / LAST_MODEL_NAME)

        # 每一轮对前几个验证病例进行 3D 可视化保存
        save_validation_visualization(
            model, val_loader, DEVICE, epoch, VIS_DIR, threshold=THRESHOLD,
            num_cases=NUM_VIS_CASES, modality_index=VIS_MODALITY
        )


if __name__ == "__main__":
    main()