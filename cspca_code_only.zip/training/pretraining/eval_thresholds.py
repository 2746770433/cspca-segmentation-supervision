import os

# 和 train3.py 保持一致
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

import csv
import random
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from config import (
    TRAIN_MUL_TABLE,  # 改为读取多任务对齐表
    VAL_MUL_TABLE,  # 改为读取多任务对齐表
    CHECKPOINT_DIR,
    TARGET_SHAPE,
    CROP_SHAPE,
    USE_ROI_CROP,
    ROI_MARGIN,
    IN_CHANNELS,
    OUT_CHANNELS,
    BASE_CHANNELS,
    NUM_WORKERS,
    DEVICE,
    BEST_MODEL_NAME,
    VAL_RATIO,
    SEED,
)

from dataset_seg import PositiveSegDataset
# from model_nnunet3d import NNUNet3D  # 需要用 NNUNet3D 时取消注释这行
from model_3dunet import UNet3D  # 默认使用 UNet3D


# =========================================================
# 固定随机种子
# =========================================================
def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# =========================================================
# 直接读取对齐的多任务验证表格并过滤
# =========================================================
def load_aligned_val_df(val_table_path):
    print(f"📖 正在载入多任务对齐的验证表格...")
    val_df = pd.read_excel(val_table_path)

    # 排除已知裁剪异常病例
    exclude_patient_ids = ["11475"]

    # 过滤验证集：必须有有效 mask，且排除异常病例
    val_df = val_df[
        (val_df["has_valid_human_mask"] == True) &
        (val_df["mask_path_human"].notna())
        ].reset_index(drop=True)

    before_exclude = len(val_df)
    val_df = val_df[~val_df["patient_id"].astype(str).isin(exclude_patient_ids)].reset_index(drop=True)
    print(f"   [Val] 排除异常病患 {exclude_patient_ids}: {before_exclude} -> {len(val_df)}")

    print(f"📊 [对齐完成] 纯分割验证集: {len(val_df)} 例")
    return val_df


# =========================================================
# 根据 probs 和 mask 计算指标
# =========================================================
@torch.no_grad()
def compute_metrics_from_probs(probs, targets, threshold=0.5, smooth=1e-5):
    """
    probs  : [B, 1, D, H, W], sigmoid 后概率
    targets: [B, 1, D, H, W]
    """
    preds = (probs >= threshold).float()
    targets = targets.float()

    preds = preds.contiguous().view(preds.size(0), -1)
    targets = targets.contiguous().view(targets.size(0), -1)

    tp = (preds * targets).sum(dim=1)
    fp = (preds * (1.0 - targets)).sum(dim=1)
    fn = ((1.0 - preds) * targets).sum(dim=1)

    dice = (2.0 * tp + smooth) / (2.0 * tp + fp + fn + smooth)
    iou = (tp + smooth) / (tp + fp + fn + smooth)
    sens = (tp + smooth) / (tp + fn + smooth)
    prec = (tp + smooth) / (tp + fp + smooth)

    return {
        "dice": dice.mean().item(),
        "iou": iou.mean().item(),
        "sensitivity": sens.mean().item(),
        "precision": prec.mean().item(),
        "pred_voxels": preds.sum(dim=1).mean().item(),
        "gt_voxels": targets.sum(dim=1).mean().item(),
    }


# =========================================================
# 评估多个 threshold
# =========================================================
@torch.no_grad()
def evaluate_thresholds(model, loader, device, thresholds):
    model.eval()

    results = {}

    for th in thresholds:
        results[th] = {
            "dice": 0.0,
            "iou": 0.0,
            "sensitivity": 0.0,
            "precision": 0.0,
            "pred_voxels": 0.0,
            "gt_voxels": 0.0,
        }

    for batch in tqdm(loader, desc="Evaluating Thresholds"):
        images = batch["image"].to(device, non_blocking=True)
        masks = batch["mask"].to(device, non_blocking=True)

        logits = model(images)
        probs = torch.sigmoid(logits)

        for th in thresholds:
            metrics = compute_metrics_from_probs(probs, masks, threshold=th)
            for k in results[th].keys():
                results[th][k] += metrics[k]

    # 取平均
    n_samples = len(loader)
    for th in thresholds:
        for k in results[th].keys():
            results[th][k] /= n_samples

    return results


def main():
    set_seed(SEED)

    # 1. 载入对齐的验证集 DataFrame
    val_df = load_aligned_val_df(VAL_MUL_TABLE)

    # 2. 实例化 Dataset (保持你原本的 Dataset 参数)
    val_dataset = PositiveSegDataset(
        df=val_df,
        mode="val",
        target_shape=TARGET_SHAPE,
        crop_shape=CROP_SHAPE,
        use_roi_crop=USE_ROI_CROP,
        roi_margin=ROI_MARGIN,
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=1,
        shuffle=False,
        num_workers=NUM_WORKERS,
        pin_memory=True,
    )

    # 3. 初始化模型 (保持你原本的实例化逻辑)
    print("\n🏗️  正在初始化分割模型...")
    # model = NNUNet3D(in_channels=IN_CHANNELS, out_channels=OUT_CHANNELS, base_channels=BASE_CHANNELS).to(DEVICE)
    model = UNet3D(in_channels=IN_CHANNELS, out_channels=OUT_CHANNELS, base_channels=BASE_CHANNELS).to(DEVICE)

    # 载入最佳权重
    best_model_path = os.path.join(CHECKPOINT_DIR, BEST_MODEL_NAME)
    if not os.path.exists(best_model_path):
        raise FileNotFoundError(f"未找到最佳权重文件: {best_model_path}，请先运行 train.py 训练。")

    print(f"💾 正在载入最佳权重: {best_model_path}")
    model.load_state_dict(torch.load(best_model_path, map_location=DEVICE))

    # 4. 评估不同的 Thresholds
    thresholds = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    print(f"\n🔍 开始在验证集上评估阈值: {thresholds}")
    results = evaluate_thresholds(model, val_loader, DEVICE, thresholds)

    # 5. 打印并保存结果
    print("\n" + "=" * 80)
    print(f"{'Threshold':<10}{'Dice':<10}{'IoU':<10}{'Sensitivity':<15}{'Precision':<15}{'Pred Voxels':<15}")
    print("=" * 80)

    csv_path = os.path.join(CHECKPOINT_DIR, "threshold_evaluation.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["threshold", "dice", "iou", "sensitivity", "precision", "pred_voxels", "gt_voxels"])

        for th in thresholds:
            res = results[th]
            print(
                f"{th:<10.1f}"
                f"{res['dice']:<10.4f}"
                f"{res['iou']:<10.4f}"
                f"{res['sensitivity']:<15.4f}"
                f"{res['precision']:<15.4f}"
                f"{res['pred_voxels']:<15.1f}"
            )
            writer.writerow([
                th, res["dice"], res["iou"], res["sensitivity"], res["precision"],
                res["pred_voxels"], res["gt_voxels"]
            ])

    print("=" * 80)
    print(f"💾 评估结果已保存至: {csv_path}")


if __name__ == "__main__":
    main()