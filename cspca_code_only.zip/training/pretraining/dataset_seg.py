import numpy as np
import pandas as pd
import nibabel as nib
import torch
from torch.utils.data import Dataset
from scipy.ndimage import rotate


class PositiveSegDataset(Dataset):
    """
    仅用于 3D U-Net / nnU-Net-like 分割 baseline (无 Resize 纯物理空间 ROI 裁剪版)。

    只使用阳性且有真实 lesion mask 的病例：
        has_valid_human_mask == True

    输入：
        T2W / ADC / HBV 三模态 MRI (已重采样对齐到同一空间)

    标签：
        mask_path_human (二值化：0 -> 背景, >0 -> 病灶)

    全新纯物理空间流程：
        1. 读取原始 NIfTI 图像 (Shape 可能是 1024x1024x27, 384x384x19 等)
        2. 图像独立进行 z-score 归一化
        3. 以前列腺腺体 (whole_gland_mask) 为中心，直接在 3D 空间进行 Crop/Pad
           输出精确的 target_shape (如 20x256x256)
        4. 在 target_shape 基础上进行 crop_shape (如 20x224x224) 的随机/中心裁剪，并输出
    """

    def __init__(
            self,
            table_path=None,
            df=None,
            mode="train",
            target_shape=(20, 256, 256),
            crop_shape=(20, 224, 224),
            augment=True,
            use_roi_crop=True,  # 强制建议为 True
            roi_margin=(2, 24, 24),
            fallback_center_crop=True,
    ):
        if df is not None:
            self.df = df.copy()
        elif table_path is not None:
            self.df = pd.read_excel(table_path)
        else:
            raise ValueError("table_path 和 df 至少需要提供一个")

        required_cols = [
            "t2w_path",
            "adc_path",
            "hbv_path",
            "mask_path_human",
            "has_valid_human_mask",
            "patient_id",
        ]

        for col in required_cols:
            if col not in self.df.columns:
                raise ValueError(f"表格中缺少字段: {col}")

        if use_roi_crop:
            roi_required_cols = ["whole_gland_mask_path"]
            for col in roi_required_cols:
                if col not in self.df.columns:
                    raise ValueError(f"use_roi_crop=True 但表格中缺少字段: {col}")

        # 只保留有真实有效人工 mask 的病例
        self.df = self.df[
            (self.df["has_valid_human_mask"] == True) &
            (self.df["mask_path_human"].notna())
            ].reset_index(drop=True)

        # 如果使用 ROI crop，则优先过滤 whole gland mask 可用病例
        if use_roi_crop:
            if "has_whole_gland_mask" in self.df.columns:
                self.df = self.df[
                    self.df["has_whole_gland_mask"] == True
                    ].reset_index(drop=True)

            if "gland_t2w_all_ok" in self.df.columns:
                self.df = self.df[
                    self.df["gland_t2w_all_ok"] == True
                    ].reset_index(drop=True)

        self.mode = mode
        self.target_shape = target_shape
        self.crop_shape = crop_shape
        self.augment = augment and mode == "train"

        self.use_roi_crop = use_roi_crop
        self.roi_margin = roi_margin
        self.fallback_center_crop = fallback_center_crop

        print(
            f"[PositiveSegDataset] mode={mode} | "
            f"samples={len(self.df)} | "
            f"target_shape={target_shape} | "
            f"crop_shape={crop_shape} | "
            f"augment={self.augment} | "
            f"use_roi_crop={self.use_roi_crop} | "
            f"roi_margin={self.roi_margin} | "
            f"fallback_center_crop={self.fallback_center_crop}"
        )

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        # =====================================================
        # 1. 读取原始物理空间图像和 Mask (不进行任何 Resize)
        # =====================================================
        t2w = self._load_nii(row["t2w_path"])  # [D, H, W]
        adc = self._load_nii(row["adc_path"])  # [D, H, W]
        hbv = self._load_nii(row["hbv_path"])  # [D, H, W]
        mask = self._load_nii(row["mask_path_human"])  # [D, H, W]

        # 二值化病灶标签
        mask = (mask > 0).astype(np.float32)

        # =====================================================
        # 2. 图像独立归一化
        # =====================================================
        t2w = self._normalize(t2w)
        adc = self._normalize(adc)
        hbv = self._normalize(hbv)

        # 拼接多模态 [C, D, H, W]
        image = np.stack([t2w, adc, hbv], axis=0)

        # =====================================================
        # 3. 纯物理空间 ROI 裁剪与填充 (直接对齐到 target_shape)
        # =====================================================
        if self.use_roi_crop:
            gland_mask = self._load_nii(row["whole_gland_mask_path"])
            gland_mask = (gland_mask > 0).astype(np.float32)

            image, mask = self._crop_or_pad_to_target(image, mask, gland_mask, self.target_shape)
        else:
            # 如果不启用 ROI，则退退到图像中心裁剪
            image, mask = self._crop_or_pad_to_target(image, mask, None, self.target_shape)

        # =====================================================
        # 4. 裁剪到 crop_shape (如 20x224x224)
        # =====================================================
        image, mask = self._apply_crop(image, mask, self.crop_shape)

        # =====================================================
        # 5. 数据增强 (可选)
        # =====================================================
        if self.augment:
            image, mask = self._apply_augmentation(image, mask)

        # =====================================================
        # 6. 转换为 PyTorch Tensor
        # =====================================================
        image_tensor = torch.from_numpy(image.copy()).float()
        mask_tensor = torch.from_numpy(mask.copy()).float().unsqueeze(0)  # [1, D, H, W]

        return {
            "image": image_tensor,
            "mask": mask_tensor,
            "patient_id": str(row["patient_id"]),
        }

    def _load_nii(self, path):
        nii = nib.load(str(path))
        data = nii.get_fdata().astype(np.float32)
        # 统一将 nibabel 的 [H, W, D] 调整为深度学习常用的 [D, H, W]
        if data.ndim == 3:
            data = np.transpose(data, (2, 0, 1))
        return data

    def _normalize(self, data):
        mean = np.mean(data)
        std = np.std(data)
        if std > 1e-5:
            return (data - mean) / std
        return data - mean

    def _crop_or_pad_to_target(self, image, mask, gland_mask, target_shape):
        """
        以前列腺腺体中心为锚点，直接在 3D 空间中进行物理裁剪和零填充。
        """
        C, Z, H, W = image.shape
        t_Z, t_H, t_W = target_shape

        # 1. 确定 3D 锚点中心
        if gland_mask is not None and np.any(gland_mask > 0):
            gland_indices = np.argwhere(gland_mask > 0)
            z_min, y_min, x_min = gland_indices.min(axis=0)
            z_max, y_max, x_max = gland_indices.max(axis=0)

            center_z = (z_min + z_max) // 2
            center_y = (y_min + y_max) // 2
            center_x = (x_min + x_max) // 2
        else:
            # 兜底：使用物理中心
            center_z, center_y, center_x = Z // 2, H // 2, W // 2

        # 2. 计算 H/W 轴的裁剪边界
        h_start = max(0, center_y - t_H // 2)
        h_end = h_start + t_H
        if h_end > H:
            h_end = H
            h_start = max(0, h_end - t_H)

        w_start = max(0, center_x - t_W // 2)
        w_end = w_start + t_W
        if w_end > W:
            w_end = W
            w_start = max(0, w_end - t_W)

        # 3. 计算 Z 轴的裁剪边界 (居中截取)
        z_start = max(0, center_z - t_Z // 2)
        z_end = z_start + t_Z
        if z_end > Z:
            z_end = Z
            z_start = max(0, z_end - t_Z)

        # 4. 裁剪
        cropped_image = image[:, z_start:z_end, h_start:h_end, w_start:w_end]
        cropped_mask = mask[z_start:z_end, h_start:h_end, w_start:w_end]

        # 5. 零填充 (Padding)：如果原始图像尺寸在某些轴上小于目标尺寸
        pad_z = max(0, t_Z - cropped_image.shape[1])
        pad_h = max(0, t_H - cropped_image.shape[2])
        pad_w = max(0, t_W - cropped_image.shape[3])

        if pad_z > 0 or pad_h > 0 or pad_w > 0:
            cropped_image = np.pad(
                cropped_image,
                ((0, 0), (0, pad_z), (0, pad_h), (0, pad_w)),
                mode="constant",
                constant_values=0,
            )
            cropped_mask = np.pad(
                cropped_mask,
                ((0, pad_z), (0, pad_h), (0, pad_w)),
                mode="constant",
                constant_values=0,
            )

        return cropped_image, cropped_mask

    def _apply_crop(self, image, mask, crop_shape):
        """
        在 target_shape 基础上，裁剪到 crop_shape。
        训练集采用随机裁剪，验证集/测试集采用中心裁剪。
        """
        C, Z, H, W = image.shape
        c_Z, c_H, c_W = crop_shape

        if self.mode == "train":
            z_start = np.random.randint(0, Z - c_Z + 1) if Z > c_Z else 0
            h_start = np.random.randint(0, H - c_H + 1) if H > c_H else 0
            w_start = np.random.randint(0, W - c_W + 1) if W > c_W else 0
        else:
            z_start = (Z - c_Z) // 2 if Z > c_Z else 0
            h_start = (H - c_H) // 2 if H > c_H else 0
            w_start = (W - c_W) // 2 if W > c_W else 0

        cropped_image = image[:, z_start:z_start + c_Z, h_start:h_start + c_H, w_start:w_start + c_W]
        cropped_mask = mask[z_start:z_start + c_Z, h_start:h_start + c_H, w_start:w_start + c_W]

        return cropped_image, cropped_mask

    def _apply_augmentation(self, image, mask):
        # 1. 随机水平/垂直翻转
        if np.random.rand() > 0.5:
            image = np.flip(image, axis=3)  # W 轴翻转
            mask = np.flip(mask, axis=2)
        if np.random.rand() > 0.5:
            image = np.flip(image, axis=2)  # H 轴翻转
            mask = np.flip(mask, axis=1)

        # 2. 随机旋转 (仅在 H-W 平面内旋转)
        if np.random.rand() > 0.5:
            angle = np.random.uniform(-15, 15)
            for c in range(image.shape[0]):
                image[c] = rotate(image[c], angle, axes=(1, 2), reshape=False, order=1, mode='constant', cval=0.0)
            mask = rotate(mask, angle, axes=(1, 2), reshape=False, order=0, mode='constant', cval=0.0)

        return image, mask