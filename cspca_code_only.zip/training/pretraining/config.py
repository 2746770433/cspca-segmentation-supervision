from pathlib import Path
import os
import torch

# =========================================================
# 路径配置
# =========================================================
# 自动解析项目根目录
BASE_DIR = Path(os.environ.get("PICAI_PROJECT_ROOT", Path(__file__).resolve().parents[2]))

DATA_DIR = BASE_DIR / "data"
TABLE_DIR = DATA_DIR / "tables"

# 多任务对齐的训练集与验证集表格路径（顶替原有的 SEG_TABLE）
TRAIN_MUL_TABLE = TABLE_DIR / "train_mul.xlsx"
VAL_MUL_TABLE = TABLE_DIR / "val_mul.xlsx"

# 当前实验目录
EXP_DIR = Path(__file__).resolve().parents[2] / "results/pretraining"

# checkpoint 文件夹
CHECKPOINT_DIR = EXP_DIR / "checkpoints" / "roi_crop_pure192new"
VIS_DIR = CHECKPOINT_DIR / "vis"

# The pretraining entry creates directories when training is explicitly run.

# =========================================================
# 训练超参数
# =========================================================
SEED = 42
VAL_RATIO = 0.2
BATCH_SIZE = 2
NUM_WORKERS = 4
EPOCHS = 100
LR = 1e-3
WEIGHT_DECAY = 1e-4
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# =========================================================
# 图像与裁剪超参数
# =========================================================
# 目标尺寸与裁剪尺寸 (D, H, W)
TARGET_SHAPE = (20, 256, 256)
CROP_SHAPE = (20, 192, 192)

# 是否启用物理空间 ROI 裁剪
USE_ROI_CROP = True
ROI_MARGIN = (2, 24, 24)

# =========================================================
# 模型与损失函数超参数
# =========================================================
IN_CHANNELS = 3
OUT_CHANNELS = 1
BASE_CHANNELS = 32

# 损失函数权重
DICE_WEIGHT = 1.0
BCE_WEIGHT = 1.0
POS_WEIGHT = 50.0  # 前景像素极少时，加大此权重避免模型预测全背景

# 预测二值化阈值
THRESHOLD = 0.5

# =========================================================
# 模型保存与可视化配置
# =========================================================
BEST_MODEL_NAME = "best_model.pth"
LAST_MODEL_NAME = "last_model.pth"

NUM_VIS_CASES = 4  # 验证集可视化病例数
VIS_MODALITY = 0   # 可视化时背景使用的模态索引 (0: T2W, 1: ADC, 2: HBV)
