import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

import pandas as pd
import numpy as np
from tqdm import tqdm
from config import (
    SEG_TABLE,
    TARGET_SHAPE,
    CROP_SHAPE,
    USE_ROI_CROP,
    ROI_MARGIN,
)
from dataset_seg import PositiveSegDataset


def main():
    print("=" * 80)
    print("🔍 纯物理空间 ROI 裁剪完整性检查 (无 Resize)")
    print("=" * 80)
    print(f"SEG_TABLE    = {SEG_TABLE}")
    print(f"TARGET_SHAPE = {TARGET_SHAPE}")
    print(f"CROP_SHAPE   = {CROP_SHAPE}")
    print(f"USE_ROI_CROP = {USE_ROI_CROP}")
    print("=" * 80)

    df = pd.read_excel(SEG_TABLE)

    # 实例化数据集 (mode="val" 采用中心裁剪)
    dataset = PositiveSegDataset(
        df=df,
        mode="val",
        target_shape=TARGET_SHAPE,
        crop_shape=CROP_SHAPE,
        use_roi_crop=USE_ROI_CROP,
        roi_margin=ROI_MARGIN,
    )

    print(f"\n开始逐例扫描 {len(dataset)} 个有效阳性病例，检查病灶保留率...")

    zero_mask_cases = []
    low_ratio_cases = []

    for i in tqdm(range(len(dataset))):
        sample = dataset[i]
        pid = sample["patient_id"]
        mask = sample["mask"].numpy()  # [1, D, H, W]

        # 读取原始未裁剪的真实 mask 算出病灶像素总数
        row = dataset.df.iloc[i]
        orig_mask_nii = dataset._load_nii(row["mask_path_human"])
        orig_sum = np.sum(orig_mask_nii > 0)

        cropped_sum = np.sum(mask > 0)

        if orig_sum == 0:
            print(f"⚠️ 病例 {pid}: 原始 Mask 中病灶像素数为 0！请检查数据。")
            continue

        ratio = cropped_sum / orig_sum

        if cropped_sum == 0:
            zero_mask_cases.append((pid, orig_sum))
        elif ratio < 0.80:  # 如果裁剪后丢失了超过 20% 的病灶
            low_ratio_cases.append((pid, ratio, orig_sum, cropped_sum))

    print("\n" + "=" * 80)
    print("📊 检查报告汇总")
    print("=" * 80)
    print(f" 扫描总例数: {len(dataset)}")
    print(f" ❌ 完全丢失病灶的病例数 (病灶被切到边界外): {len(zero_mask_cases)}")
    for pid, orig in zero_mask_cases:
        print(f"    - 病例 {pid}: 原始病灶像素 = {orig}")

    print(f" ⚠️ 病灶保留率低于 80% 的病例数: {len(low_ratio_cases)}")
    for pid, ratio, orig, crop in low_ratio_cases:
        print(f"    - 病例 {pid}: 保留率 = {ratio * 100:.2f}% (原始: {orig} -> 裁剪后: {crop})")

    if len(zero_mask_cases) == 0 and len(low_ratio_cases) == 0:
        print("\n🎉 完美！所有病例的病灶在纯物理空间裁剪后均得到了 100% 完整保留！")
    else:
        print("\n💡 提示：如果有少量病例保留率偏低，通常是因为病灶极度偏离腺体中心。")
    print("=" * 80)


if __name__ == "__main__":
    main()