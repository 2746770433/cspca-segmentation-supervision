import torch
import torch.nn as nn


class DiceLoss(nn.Module):
    def __init__(self, smooth=1e-5):
        super().__init__()
        self.smooth = smooth

    def forward(self, logits, targets):
        """
        logits : [B, 1, D, H, W]
        targets: [B, 1, D, H, W]
        """
        targets = targets.float()
        probs = torch.sigmoid(logits)

        probs = probs.contiguous().view(probs.shape[0], -1)
        targets = targets.contiguous().view(targets.shape[0], -1)

        intersection = (probs * targets).sum(dim=1)
        denominator = probs.sum(dim=1) + targets.sum(dim=1)

        dice = (2.0 * intersection + self.smooth) / (denominator + self.smooth)
        loss = 1.0 - dice

        return loss.mean()


class WeightedBCEDiceLoss(nn.Module):
    """
    Weighted BCE + Dice Loss

    用于极度前景稀疏的病灶分割，避免模型全预测背景。

    loss = dice_weight * DiceLoss + bce_weight * BCEWithLogitsLoss(pos_weight)

    参数：
        dice_weight: Dice loss 权重
        bce_weight : BCE loss 权重
        pos_weight : BCE 中前景像素权重，前景极少时可设大一些，例如 20, 50, 100
        smooth     : Dice 平滑项
    """

    def __init__(
        self,
        dice_weight=0.7,
        bce_weight=0.3,
        pos_weight=50.0,
        smooth=1e-5,
    ):
        super().__init__()

        self.dice_weight = float(dice_weight)
        self.bce_weight = float(bce_weight)
        self.pos_weight_value = float(pos_weight)
        self.smooth = smooth

        self.bce_loss = None

    def _get_bce_loss(self, device):
        """
        BCEWithLogitsLoss 的 pos_weight 需要和 logits 在同一个 device。
        """
        if self.bce_loss is None:
            pos_weight_tensor = torch.tensor(
                [self.pos_weight_value],
                dtype=torch.float32,
                device=device,
            )
            self.bce_loss = nn.BCEWithLogitsLoss(pos_weight=pos_weight_tensor)

        return self.bce_loss

    def dice_loss(self, logits, targets):
        """
        logits : [B, 1, D, H, W]
        targets: [B, 1, D, H, W]
        """
        targets = targets.float()
        probs = torch.sigmoid(logits)

        probs = probs.contiguous().view(probs.shape[0], -1)
        targets = targets.contiguous().view(targets.shape[0], -1)

        intersection = (probs * targets).sum(dim=1)
        denominator = probs.sum(dim=1) + targets.sum(dim=1)

        dice = (2.0 * intersection + self.smooth) / (denominator + self.smooth)
        loss = 1.0 - dice

        return loss.mean()

    def forward(self, logits, targets):
        """
        返回：
            loss : 总损失
            dice : detached dice loss
            bce  : detached bce loss
        """
        targets = targets.float()

        dice = self.dice_loss(logits, targets)

        bce_fn = self._get_bce_loss(logits.device)
        bce = bce_fn(logits, targets)

        loss = self.dice_weight * dice + self.bce_weight * bce

        return loss, dice.detach(), bce.detach()
