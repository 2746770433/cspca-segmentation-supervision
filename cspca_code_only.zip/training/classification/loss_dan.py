import torch
import torch.nn as nn


class SingleTaskClsLoss(nn.Module):
    def __init__(self, pos_weight_val=7.5):
        """
        单任务纯分类 Loss
        pos_weight_val: 论文实验在前期开发后固定的阳性类别权重
        """
        super().__init__()

        # 动态检测可用设备
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        pos_weight = torch.tensor([pos_weight_val], dtype=torch.float).to(device)

        self.cls_criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

    def forward(self, cls_logits, cls_labels):
        """
        cls_logits: [B, 1]
        cls_labels: [B, 1]
        """
        loss_cls = self.cls_criterion(cls_logits, cls_labels)
        return loss_cls
