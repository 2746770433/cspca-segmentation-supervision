import torch
import torch.nn as nn
import torch.nn.functional as F

# 导入本地标准的两个模型类
from model_3dunet import UNet3D
from model_nnunet3d import NNUNet3D


class MultiTaskUNet3D(nn.Module):
    """
    多任务双分支通用网络。
    包装并拦截本地的 model_3dunet.py 或 model_nnunet3d.py，挂载分类 Head。
    """

    def __init__(self, in_channels=3, out_channels=1, base_channels=32, num_classes=1, backbone="3dunet"):
        super().__init__()
        self.backbone_type = backbone.lower()
        assert self.backbone_type in ["3dunet", "nnunet"], "backbone 必须是 '3dunet' 或 'nnunet'"

        # 1. 实例化 Backbone
        if self.backbone_type == "3dunet":
            self.net = UNet3D(in_channels=in_channels, out_channels=out_channels, base_channels=base_channels)
            # 3D U-Net 的 Bottleneck 对应的通道数是 base_channels * 16 (即 512)
            bottleneck_channels = base_channels * 16
        elif self.backbone_type == "nnunet":
            self.net = NNUNet3D(in_channels=in_channels, out_channels=out_channels, base_channels=base_channels)
            # nn-UNet 的 Bottleneck 对应的通道数是 base_channels * 10 (即 320)
            bottleneck_channels = base_channels * 10

        # 2. 共享分类 Head (挂载在对应骨干的 Bottleneck 上)
        self.cls_head = nn.Sequential(
            nn.AdaptiveAvgPool3d(1),  # 全局自适应池化到 1x1x1
            nn.Flatten(),
            nn.Linear(bottleneck_channels, 128),
            nn.LayerNorm(128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes)
        )

    def forward(self, x):
        # ==================== 【核心拦截：优雅提取真正的 Bottleneck 特征】 ====================
        if self.backbone_type == "3dunet":
            # 1. 模拟 model_3dunet.py 内部的前向传播，拦截最底层的 bottleneck 特征
            # 这样既不需要修改 model_3dunet.py，又能拿到 100% 真实的特征，告别随机数！
            x1 = self.net.inc(x)
            x2 = self.net.down1(x1)
            x3 = self.net.down2(x2)
            x4 = self.net.down3(x3)

            # 拦截的最底层特征 (Bottleneck)
            bottleneck_feat = self.net.bottleneck(x4)  # [B, 512, D_b, H_b, W_b]

            # 继续完成 U-Net 的上采样分割分支
            x_dec = self.net.up3(bottleneck_feat, x4)
            x_dec = self.net.up2(x_dec, x3)
            x_dec = self.net.up1(x_dec, x2)
            x_dec = self.net.up0(x_dec, x1)
            seg_logits = self.net.outc(x_dec)

        else:
            # nnunet 备用拦截逻辑
            seg_logits = self.net(x)
            if hasattr(self.net, 'bottleneck_feature') and self.net.bottleneck_feature is not None:
                bottleneck_feat = self.net.bottleneck_feature
            else:
                bottleneck_feat = torch.zeros(x.size(0), 320, 1, 1, 1, device=x.device)

        # 2. 将真实的 Bottleneck 特征送入分类头
        cls_logits = self.cls_head(bottleneck_feat)

        return seg_logits, cls_logits