import os
from pathlib import Path
import torch

# =========================================================
# 可移植路径配置
# =========================================================
BASE_DIR = Path(os.environ.get("PICAI_PROJECT_ROOT", Path(__file__).resolve().parents[2]))
TABLE_DIR = BASE_DIR / "data/tables"

TRAIN_TABLE = TABLE_DIR / "train_mul.xlsx"
VAL_TABLE   = TABLE_DIR / "val_mul.xlsx"
TEST_TABLE  = TABLE_DIR / "test.xlsx"

# 本地输出路径（自动在当前运行目录下创建）
CURRENT_WORKSPACE = Path(__file__).resolve().parents[2] / "results/runs/classification"
CHECKPOINT_DIR = CURRENT_WORKSPACE / "checkpoints"
VIS_DIR = CURRENT_WORKSPACE / "vis_results"

# Output directories are created by the selected runner, not during import.

# 显式定义模型保存路径
MODEL_SAVE_PATH = CHECKPOINT_DIR / "best_cls_model.pth"

# =========================================================
# 训练与模型超参数
# =========================================================
SEED = 42
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
BACKBONE = "3dunet"  # 默认使用 3D UNet 骨干

# 图像尺寸（与您 0.54 的分割模型完全一致）
TARGET_SHAPE = (20, 256, 256)
CROP_SHAPE = (20, 192, 192)
USE_ROI_CROP = True  # 启用前列腺腺体中心物理对齐

# 训练超参数
BATCH_SIZE = 4
NUM_WORKERS = 4
EPOCHS = 100
LR = 3e-4
WEIGHT_DECAY = 1e-4

# =========================================================
# 论文固定设置
# =========================================================
LAMBDA_CLS = 0.05
THRESHOLD = 0.45
