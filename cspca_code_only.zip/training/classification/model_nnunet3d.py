import torch
import torch.nn as nn
import torch.nn.functional as F


# =========================================================
# nnU-Net-like Conv Block
# Conv3d + InstanceNorm3d + LeakyReLU
# =========================================================
class ConvNormLReLU(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1):
        super().__init__()

        padding = kernel_size // 2

        self.block = nn.Sequential(
            nn.Conv3d(
                in_channels,
                out_channels,
                kernel_size=kernel_size,
                stride=stride,
                padding=padding,
                bias=False,
            ),
            nn.InstanceNorm3d(out_channels, affine=True),
            nn.LeakyReLU(negative_slope=1e-2, inplace=True),
        )

    def forward(self, x):
        return self.block(x)


# =========================================================
# Stacked Conv Block
# nnU-Net 常用形式：
# 第一层可 stride=2 完成下采样，后面 stride=1
# =========================================================
class StackedConvBlocks(nn.Module):
    def __init__(self, in_channels, out_channels, num_convs=2, first_stride=1):
        super().__init__()

        layers = []

        layers.append(
            ConvNormLReLU(
                in_channels=in_channels,
                out_channels=out_channels,
                kernel_size=3,
                stride=first_stride,
            )
        )

        for _ in range(num_convs - 1):
            layers.append(
                ConvNormLReLU(
                    in_channels=out_channels,
                    out_channels=out_channels,
                    kernel_size=3,
                    stride=1,
                )
            )

        self.block = nn.Sequential(*layers)

    def forward(self, x):
        return self.block(x)


# =========================================================
# nnU-Net-like 3D U-Net
# 输入:  [B, 3, D, H, W]
# 输出:  [B, 1, D, H, W]
#
# 针对你的 CROP_SHAPE=(20,192,192)
# 下采样层数不宜太深，因为 D=20 比较小。
# 这里采用 4 层 encoder：
#   20x192x192
#   10x96x96
#   5x48x48
#   3x24x24
#   2x12x12
# =========================================================
class NNUNet3D(nn.Module):
    def __init__(
        self,
        in_channels=3,
        out_channels=1,
        base_channels=32,
        num_convs_per_stage=2,
    ):
        super().__init__()

        c1 = base_channels          # 32
        c2 = base_channels * 2      # 64
        c3 = base_channels * 4      # 128
        c4 = base_channels * 8      # 256
        c5 = base_channels * 10     # 320, nnU-Net 常有 channel cap

        # =====================================================
        # Encoder
        # 使用 stride conv 下采样，而不是 MaxPool
        # =====================================================
        self.enc1 = StackedConvBlocks(
            in_channels,
            c1,
            num_convs=num_convs_per_stage,
            first_stride=1,
        )

        self.enc2 = StackedConvBlocks(
            c1,
            c2,
            num_convs=num_convs_per_stage,
            first_stride=2,
        )

        self.enc3 = StackedConvBlocks(
            c2,
            c3,
            num_convs=num_convs_per_stage,
            first_stride=2,
        )

        self.enc4 = StackedConvBlocks(
            c3,
            c4,
            num_convs=num_convs_per_stage,
            first_stride=2,
        )

        self.bottleneck = StackedConvBlocks(
            c4,
            c5,
            num_convs=num_convs_per_stage,
            first_stride=2,
        )

        # =====================================================
        # Decoder
        # =====================================================
        self.up4 = nn.ConvTranspose3d(c5, c4, kernel_size=2, stride=2)
        self.dec4 = StackedConvBlocks(
            c4 + c4,
            c4,
            num_convs=num_convs_per_stage,
            first_stride=1,
        )

        self.up3 = nn.ConvTranspose3d(c4, c3, kernel_size=2, stride=2)
        self.dec3 = StackedConvBlocks(
            c3 + c3,
            c3,
            num_convs=num_convs_per_stage,
            first_stride=1,
        )

        self.up2 = nn.ConvTranspose3d(c3, c2, kernel_size=2, stride=2)
        self.dec2 = StackedConvBlocks(
            c2 + c2,
            c2,
            num_convs=num_convs_per_stage,
            first_stride=1,
        )

        self.up1 = nn.ConvTranspose3d(c2, c1, kernel_size=2, stride=2)
        self.dec1 = StackedConvBlocks(
            c1 + c1,
            c1,
            num_convs=num_convs_per_stage,
            first_stride=1,
        )

        # =====================================================
        # Segmentation Head
        # =====================================================
        self.seg_head = nn.Conv3d(c1, out_channels, kernel_size=1)

        self._init_weights()

    def _init_weights(self):
        """
        nnU-Net 风格初始化：
        Conv3d 使用 Kaiming 初始化。
        """
        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                nn.init.kaiming_normal_(
                    m.weight,
                    a=1e-2,
                    mode="fan_out",
                    nonlinearity="leaky_relu",
                )
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

            elif isinstance(m, nn.ConvTranspose3d):
                nn.init.kaiming_normal_(
                    m.weight,
                    a=1e-2,
                    mode="fan_out",
                    nonlinearity="leaky_relu",
                )
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

    def _match_size(self, x, ref):
        """
        处理奇偶尺寸导致的 shape 不一致。
        你的 D=20，连续 stride=2 后会出现 5->3->2 这类情况，
        所以必须做尺寸对齐。
        """
        diff_d = ref.size(2) - x.size(2)
        diff_h = ref.size(3) - x.size(3)
        diff_w = ref.size(4) - x.size(4)

        x = F.pad(
            x,
            [
                diff_w // 2,
                diff_w - diff_w // 2,
                diff_h // 2,
                diff_h - diff_h // 2,
                diff_d // 2,
                diff_d - diff_d // 2,
            ],
        )

        return x

    def forward(self, x):
        # Encoder
        e1 = self.enc1(x)          # [B, 32, D, H, W]
        e2 = self.enc2(e1)         # [B, 64, D/2, H/2, W/2]
        e3 = self.enc3(e2)         # [B, 128, ...]
        e4 = self.enc4(e3)         # [B, 256, ...]

        b = self.bottleneck(e4)    # [B, 320, ...]

        # Decoder
        d4 = self.up4(b)
        d4 = self._match_size(d4, e4)
        d4 = torch.cat([e4, d4], dim=1)
        d4 = self.dec4(d4)

        d3 = self.up3(d4)
        d3 = self._match_size(d3, e3)
        d3 = torch.cat([e3, d3], dim=1)
        d3 = self.dec3(d3)

        d2 = self.up2(d3)
        d2 = self._match_size(d2, e2)
        d2 = torch.cat([e2, d2], dim=1)
        d2 = self.dec2(d2)

        d1 = self.up1(d2)
        d1 = self._match_size(d1, e1)
        d1 = torch.cat([e1, d1], dim=1)
        d1 = self.dec1(d1)

        logits = self.seg_head(d1)

        return logits


if __name__ == "__main__":
    model = NNUNet3D(in_channels=3, out_channels=1, base_channels=32)

    x = torch.randn(1, 3, 20, 192, 192)
    y = model(x)

    print("input :", x.shape)
    print("output:", y.shape)
