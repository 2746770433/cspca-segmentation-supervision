import os
import numpy as np
import pandas as pd
import nibabel as nib
import torch
from torch.utils.data import Dataset
from scipy.ndimage import rotate


class ProstateMultiTaskDataset(Dataset):
    def __init__(
            self,
            df,
            mode="train",
            target_shape=(20, 256, 256),
            crop_shape=(20, 224, 224),
            augment=True,
            use_roi_crop=True,
    ):
        self.df = df.copy().reset_index(drop=True)
        self.mode = mode
        self.target_shape = target_shape
        self.crop_shape = crop_shape
        self.augment = augment and mode == "train"
        self.use_roi_crop = use_roi_crop

    def __len__(self):
        return len(self.df)

    def _load_nii(self, path):
        if pd.isna(path) or not os.path.exists(path):
            return np.zeros(self.target_shape, dtype=np.float32)

        nii = nib.load(str(path))
        data = nii.get_fdata().astype(np.float32)

        if data.ndim == 3:
            data = np.transpose(data, (2, 0, 1))
        return data

    def _normalize(self, data):
        # 严格对齐 dataset_seg.py 的 z-score 归一化
        mean = np.mean(data)
        std = np.std(data)
        if std > 1e-5:
            return (data - mean) / std
        return data - mean

    def _crop_or_pad_to_target(self, image, mask, gland_mask, target_shape):
        C, Z, H, W = image.shape
        t_Z, t_H, t_W = target_shape

        # 1. 确定 3D 锚点中心
        if gland_mask is not None and np.any(gland_mask > 0):
            gland_indices = np.argwhere(gland_mask > 0)
            z_min, y_min, x_min = gland_indices.min(axis=0)
            z_max, y_max, x_max = gland_indices.max(axis=0)

            center_z = (z_min + z_max) // 2
            center_y = (y_min + y_max) // 2
            center_x = (x_min + x_max) // 2
        else:
            center_z, center_y, center_x = Z // 2, H // 2, W // 2

        # 2. 计算 H/W 轴的裁剪边界
        h_start = max(0, center_y - t_H // 2)
        h_end = h_start + t_H
        if h_end > H:
            h_end = H
            h_start = max(0, h_end - t_H)

        w_start = max(0, center_x - t_W // 2)
        w_end = w_start + t_W
        if w_end > W:
            w_end = W
            w_start = max(0, w_end - t_W)

        # 3. 计算 Z 轴的裁剪边界
        z_start = max(0, center_z - t_Z // 2)
        z_end = z_start + t_Z
        if z_end > Z:
            z_end = Z
            z_start = max(0, z_end - t_Z)

        # 4. 裁剪
        cropped_image = image[:, z_start:z_end, h_start:h_end, w_start:w_end]
        cropped_mask = mask[z_start:z_end, h_start:h_end, w_start:w_end]

        # 5. 零填充 (Padding)
        pad_z = max(0, t_Z - cropped_image.shape[1])
        pad_h = max(0, t_H - cropped_image.shape[2])
        pad_w = max(0, t_W - cropped_image.shape[3])

        if pad_z > 0 or pad_h > 0 or pad_w > 0:
            cropped_image = np.pad(
                cropped_image,
                ((0, 0), (0, pad_z), (0, pad_h), (0, pad_w)),
                mode="constant",
                constant_values=0,
            )
            cropped_mask = np.pad(
                cropped_mask,
                ((0, pad_z), (0, pad_h), (0, pad_w)),
                mode="constant",
                constant_values=0,
            )

        return cropped_image, cropped_mask

    def _apply_crop(self, image, mask, crop_shape):
        C, Z, H, W = image.shape
        c_Z, c_H, c_W = crop_shape

        if self.mode == "train":
            z_start = np.random.randint(0, Z - c_Z + 1) if Z > c_Z else 0
            h_start = np.random.randint(0, H - c_H + 1) if H > c_H else 0
            w_start = np.random.randint(0, W - c_W + 1) if W > c_W else 0
        else:
            z_start = (Z - c_Z) // 2 if Z > c_Z else 0
            h_start = (H - c_H) // 2 if H > c_H else 0
            w_start = (W - c_W) // 2 if W > c_W else 0

        cropped_image = image[:, z_start:z_start + c_Z, h_start:h_start + c_H, w_start:w_start + c_W]
        cropped_mask = mask[z_start:z_start + c_Z, h_start:h_start + c_H, w_start:w_start + c_W]

        return cropped_image, cropped_mask

    def _apply_augmentation(self, image, mask):
        if np.random.rand() > 0.5:
            image = np.flip(image, axis=3).copy()  # W 轴翻转
            mask = np.flip(mask, axis=2).copy()
        if np.random.rand() > 0.5:
            image = np.flip(image, axis=2).copy()  # H 轴翻转
            mask = np.flip(mask, axis=1).copy()

        if np.random.rand() > 0.5:
            angle = np.random.uniform(-15, 15)
            for c in range(image.shape[0]):
                image[c] = rotate(image[c], angle, axes=(1, 2), reshape=False, order=1, mode='constant', cval=0.0)
            mask = rotate(mask, angle, axes=(1, 2), reshape=False, order=0, mode='constant', cval=0.0)

        return image, mask

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        # 1. 加载三模态图像
        t2w = self._load_nii(row["t2w_path"])
        adc = self._load_nii(row["adc_path"])
        hbv = self._load_nii(row["hbv_path"])

        t2w = self._normalize(t2w)
        adc = self._normalize(adc)
        hbv = self._normalize(hbv)
        image = np.stack([t2w, adc, hbv], axis=0)

        # 2. 分类标签（所有样本都有）
        cspca_label = int(row["cspca_label"])

        # ✅ 核心改动：直接用 has_valid_human_mask 判断是否有分割标注
        has_valid_mask = str(row.get("has_valid_human_mask", "FALSE")).strip().upper() in ["TRUE", "1", "1.0"]

        if has_valid_mask and pd.notna(row.get("mask_path_human", None)):
            mask = self._load_nii(row["mask_path_human"])
            mask = (mask > 0).astype(np.float32)
        else:
            mask = np.zeros_like(t2w)  # 阴性/无标注 → 全零mask

        # 3. 腺体ROI对齐
        if self.use_roi_crop and pd.notna(row.get("whole_gland_mask_path", None)):
            gland_mask = self._load_nii(row["whole_gland_mask_path"])
            gland_mask = (gland_mask > 0).astype(np.float32)
        else:
            gland_mask = None

        # 4. 预处理流水线（保持不变）
        image, mask = self._crop_or_pad_to_target(image, mask, gland_mask, self.target_shape)
        image, mask = self._apply_crop(image, mask, self.crop_shape)
        if self.augment:
            image, mask = self._apply_augmentation(image, mask)

        mask = mask[np.newaxis, ...]  # [1, D, H, W]

        return {
            "image": torch.from_numpy(image).float(),
            "mask": torch.from_numpy(mask).float(),
            "label": torch.tensor(cspca_label, dtype=torch.long),
            "has_valid_mask": torch.tensor(float(has_valid_mask), dtype=torch.float),
        }

