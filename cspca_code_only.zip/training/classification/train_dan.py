import os

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm
from sklearn.metrics import roc_auc_score, confusion_matrix

from config import *
from dataset import ProstateMultiTaskDataset
from model import MultiTaskUNet3D
from loss_dan import SingleTaskClsLoss

# =========================================================
# 独立保存路径，防止覆盖多任务权重
# =========================================================
CHECKPOINT_DIR = CURRENT_WORKSPACE / "checkpoints" / 'cls_only'
# The unified runner creates its seed-specific output directory.
MODEL_SAVE_PATH = CHECKPOINT_DIR / "best_cls_model.pth"


def set_seed(seed=42):
    random.seed(seed)
    np.seed = seed
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = True


def load_pretrained_weights(model, checkpoint_path):
    if not os.path.exists(checkpoint_path):
        print(f"⚠️ 未找到预训练权重文件: {checkpoint_path}，将从头开始训练。")
        return model

    print(f"🔥 检测到 Baseline 预训练权重: {checkpoint_path}")
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    pretrained_dict = checkpoint["model_state_dict"] if "model_state_dict" in checkpoint else checkpoint
    model_dict = model.state_dict()

    cleaned_pretrained_dict = {k.replace("module.", ""): v for k, v in pretrained_dict.items()}
    state_dict_to_load = {}
    matched_count = 0

    for model_key in model_dict.keys():
        if model_key in cleaned_pretrained_dict:
            state_dict_to_load[model_key] = cleaned_pretrained_dict[model_key]
            matched_count += 1
        else:
            for pt_key in cleaned_pretrained_dict.keys():
                if pt_key in model_key or model_key in pt_key:
                    state_dict_to_load[model_key] = cleaned_pretrained_dict[pt_key]
                    matched_count += 1
                    break

    if matched_count > 0:
        model_dict.update(state_dict_to_load)
        model.load_state_dict(model_dict)
        print(f"✅ 成功匹配并载入 {matched_count} 个权重 Key 到 Backbone 中！")
    return model


def main():
    set_seed(SEED)

    print("📂 正在加载数据表...")
    train_df = pd.read_excel(TRAIN_TABLE)
    val_df = pd.read_excel(VAL_TABLE)

    for df in [train_df, val_df]:
        df["has_valid_human_mask_clean"] = df["has_valid_human_mask"].apply(
            lambda x: str(x).strip().upper() in ["TRUE", "1", "1.0"]
            if not pd.isna(x) else False
        )

    def print_stats(name, df):
        seg_pos = df["has_valid_human_mask_clean"].sum()
        cls_pos = (df["cspca_label"] == 1).sum()
        cls_neg = (df["cspca_label"] == 0).sum()
        print(f"  [{name}] 总样本: {len(df)} | "
              f"分割阳性(有mask): {seg_pos} | "
              f"分类阳性: {cls_pos} | 分类阴性: {cls_neg}")

    print("\n📊 数据集分布:")
    print_stats("Train", train_df)
    print_stats("Val  ", val_df)

    train_loader = DataLoader(
        ProstateMultiTaskDataset(train_df, mode="train",
                                 target_shape=TARGET_SHAPE,
                                 crop_shape=CROP_SHAPE,
                                 use_roi_crop=USE_ROI_CROP),
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=NUM_WORKERS,
        pin_memory=True,
    )

    val_loader = DataLoader(
        ProstateMultiTaskDataset(val_df, mode="val",
                                 target_shape=TARGET_SHAPE,
                                 crop_shape=CROP_SHAPE,
                                 use_roi_crop=USE_ROI_CROP),
        batch_size=1,
        shuffle=False,
        num_workers=NUM_WORKERS,
        pin_memory=True,
    )

    # 初始化模型
    model = MultiTaskUNet3D(in_channels=3, out_channels=1, base_channels=32, backbone=BACKBONE).to(DEVICE)
    model = load_pretrained_weights(model, os.path.join(BASE_DIR,
                                                        str(Path(__file__).resolve().parents[2] / "weights/pretraining/best_model.pth")))

    # 纯分类 Loss
    criterion = SingleTaskClsLoss()

    backbone_params = [p for n, p in model.named_parameters() if "cls_head" not in n]
    head_params = [p for n, p in model.named_parameters() if "cls_head" in n]

    for param in backbone_params:
        param.requires_grad = False

    optimizer = torch.optim.AdamW([{"params": head_params, "lr": LR}], weight_decay=WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS, eta_min=1e-6)

    best_composite_score = -999.0
    backbone_unfrozen = False

    print(f"\n🚀 开始单任务(纯分类)训练... 设备: {DEVICE}")

    for epoch in range(1, EPOCHS + 1):
        if epoch > 10 and not backbone_unfrozen:
            print("\n🔓 [解冻提示] 10 轮已满，正在解冻 Backbone 进行联合微调...")
            for param in backbone_params:
                param.requires_grad = True
            optimizer = torch.optim.AdamW([
                {"params": backbone_params, "lr": LR * 0.1},
                {"params": head_params, "lr": LR * 0.5}
            ], weight_decay=WEIGHT_DECAY)
            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS - 10, eta_min=1e-6)
            backbone_unfrozen = True

        model.train()
        if not backbone_unfrozen:
            for name, module in model.named_modules():
                if "cls_head" not in name:
                    if isinstance(module, (nn.BatchNorm3d, nn.InstanceNorm3d)):
                        module.eval()

        epoch_loss = 0.0
        train_preds, train_targets = [], []

        progress_bar = tqdm(
            train_loader,
            desc=f"Epoch {epoch:03d}/{EPOCHS:03d}",
            ncols=100,
            bar_format="{l_bar}{bar:10}{r_bar}"
        )

        for batch in progress_bar:
            if isinstance(batch, dict):
                images = batch["image"].to(DEVICE)
                labels_gt = batch["label"].to(DEVICE).unsqueeze(1).float()
            elif isinstance(batch, (list, tuple)):
                images = batch[0].to(DEVICE)
                labels_gt = batch[2].unsqueeze(1).float().to(DEVICE) if batch[2].dim() == 1 else batch[2].float().to(
                    DEVICE)

            optimizer.zero_grad()

            # 网络依然输出分割mask，但我们不计算它的loss
            _, cls_logits = model(images)

            # 仅计算分类 Loss
            loss = criterion(cls_logits, labels_gt)

            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

            epoch_loss += loss.item()
            train_preds.extend(torch.sigmoid(cls_logits).detach().cpu().numpy())
            train_targets.extend(labels_gt.cpu().numpy())

            progress_bar.set_postfix({
                "Loss": f"{loss.item():.3f}"
            })

        scheduler.step()
        avg_loss = epoch_loss / len(train_loader)

        # 验证阶段
        model.eval()
        val_preds, val_targets = [], []

        if len(val_loader) > 0:
            with torch.no_grad():
                for idx, batch in enumerate(val_loader):
                    if isinstance(batch, dict):
                        images = batch["image"].to(DEVICE)
                        labels_gt = batch["label"].to(DEVICE)
                    elif isinstance(batch, (list, tuple)):
                        images, labels_gt = batch[0].to(DEVICE), batch[2].to(DEVICE)

                    _, cls_logits = model(images)

                    val_preds.append(torch.sigmoid(cls_logits).item())
                    val_targets.append(int(labels_gt.item()))

            val_targets_np = np.array(val_targets)
            val_preds_np = np.array(val_preds)

            val_auc = roc_auc_score(val_targets_np, val_preds_np) if len(np.unique(val_targets_np)) > 1 else 0.5

            val_preds_bin = (val_preds_np > 0.5).astype(int)
            tn, fp, fn, tp = confusion_matrix(val_targets_np, val_preds_bin, labels=[0, 1]).ravel()
            val_fpr = fp / (fp + tn + 1e-8)
            val_tpr = tp / (tp + fn + 1e-8)
            val_tpr = tp / (tp + fn + 1e-8)  # ✅ 新增：计算 TPR
            # 纯分类评分：仅考虑 AUC 和 FPR 的平衡
            composite_score =2 * val_auc +val_tpr- val_fpr*1.5

            print(
                f"✨ [Epoch {epoch:03d} 结束] Loss: {avg_loss:.4f} | Val AUC: {val_auc:.4f} | Val TPR: {val_tpr:.4f} | Val FPR: {val_fpr:.4f} | Score: {composite_score:.4f}")

            if composite_score > best_composite_score:
                best_composite_score = composite_score
                torch.save({
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "best_score": best_composite_score,
                    "val_auc": val_auc,
                    "val_fpr": val_fpr,
                    "val_tpr": val_tpr
                }, MODEL_SAVE_PATH)
                print(f"🌟 发现更好的纯分类模型！已更新 best_model.pth")
                print(
                    f"   [新纪录] Score: {best_composite_score:.4f} (AUC: {val_auc:.4f}, TPR: {val_tpr:.4f}, FPR: {val_fpr:.4f})")


if __name__ == "__main__":
    main()
