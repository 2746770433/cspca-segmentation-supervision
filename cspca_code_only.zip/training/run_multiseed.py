"""Run the three manuscript configurations with fixed random seeds.

The original branch files are loaded without rewriting them. Paths, seed,
output directory and worker count are overridden in memory for each run.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import types
from settings import data_root
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


EXPERIMENTS = {
    "classification": {
        "branch": Path("training/classification"),
        "train_script": "train_dan.py",
        "checkpoint_name": "best_cls_model.pth",
        "gpu": "0",
        "classification_only": True,
    },
    "mtl": {
        "branch": Path("training/mtl"),
        "train_script": "train.py",
        "checkpoint_name": "best_multitask_model.pth",
        "gpu": "0",
        "classification_only": False,
    },
    "mtl_focal": {
        "branch": Path("training/mtl_focal"),
        "train_script": "train.py",
        "checkpoint_name": "best_multitask_model.pth",
        "gpu": "0",
        "classification_only": False,
    },
}

PATH_COLUMNS = (
    "t2w_path",
    "adc_path",
    "hbv_path",
    "mask_path_human",
    "mask_path_ai",
    "whole_gland_mask_path",
)


def project_root_from_script() -> Path:
    return Path(__file__).resolve().parents[1]


def validate_server_inputs(project_root: Path, require_pretraining: bool = True) -> None:
    required = [
        project_root / "configs" / "splits" / "train_mul.xlsx",
        project_root / "configs" / "splits" / "val_mul.xlsx",
        project_root / "configs" / "splits" / "test.xlsx",
    ]
    if require_pretraining:
        required.append(project_root / "weights/pretraining/best_model.pth")
    missing = [str(path) for path in required if not path.exists()]
    image_root = data_root() / "data" / "nii_resample"
    if not image_root.exists():
        missing.append(str(image_root))
    if missing:
        raise FileNotFoundError(
            "Required server data are missing:\n  " + "\n  ".join(missing)
        )


def load_training_module(script_path: Path, visible_gpu: str):
    branch_dir = script_path.parent
    sys.path.insert(0, str(branch_dir))
    source = script_path.read_text(encoding="utf-8")
    source, replacements = re.subn(
        r'os\.environ\["CUDA_VISIBLE_DEVICES"\]\s*=\s*["\'][^"\']+["\']',
        f'os.environ["CUDA_VISIBLE_DEVICES"] = "{visible_gpu}"',
        source,
        count=1,
    )
    if replacements != 1:
        raise RuntimeError(
            f"Expected one CUDA_VISIBLE_DEVICES assignment in {script_path}; "
            f"found {replacements}."
        )

    module_name = f"_multiseed_train_{script_path.parent.name}_{script_path.stem}"
    module = types.ModuleType(module_name)
    module.__file__ = str(script_path)
    module.__package__ = ""
    exec(compile(source, str(script_path), "exec"), module.__dict__)
    return module


def install_project_path_remapping(module, project_root: Path) -> None:
    """Redirect legacy absolute paths to the relocated project in memory."""

    table_dir = project_root / "configs" / "splits"
    module.BASE_DIR = data_root()
    module.TABLE_DIR = table_dir
    module.TRAIN_TABLE = table_dir / "train_mul.xlsx"
    module.VAL_TABLE = table_dir / "val_mul.xlsx"
    module.TEST_TABLE = table_dir / "test.xlsx"

    original_read_excel = module.pd.read_excel

    def read_excel_with_current_root(*args, **kwargs):
        frame = original_read_excel(*args, **kwargs)
        for column in PATH_COLUMNS:
            if column not in frame.columns:
                continue

            def remap(value):
                if not isinstance(value, str) or not value.strip():
                    return value
                normalized = value.replace("\\", "/")
                marker = "/data/"
                marker_index = normalized.find(marker)
                if marker_index < 0:
                    return value
                relative = normalized[marker_index + 1 :]
                return str(data_root() / Path(relative))

            frame[column] = frame[column].map(remap)
        return frame

    module.pd.read_excel = read_excel_with_current_root


def run_saved_checkpoint_test(
    project_root: Path,
    experiment: str,
    seed: int,
    checkpoint: Path,
    test_dir: Path,
    num_workers: int,
    visible_gpu: str,
) -> None:
    config = EXPERIMENTS[experiment]
    branch_dir = project_root / config["branch"]
    test_command = [
        sys.executable,
        str(project_root / "evaluation" / "test_model.py"),
        "--branch-dir",
        str(branch_dir),
        "--checkpoint",
        str(checkpoint),
        "--test-table",
        str(project_root / "configs" / "splits" / "test.xlsx"),
        "--project-root", str(data_root()),
        "--output-dir",
        str(test_dir),
        "--device",
        "cuda",
        "--batch-size",
        "1",
        "--num-workers",
        str(num_workers),
        "--bootstrap",
        "0",
        "--seed",
        str(seed),
    ]
    if config["classification_only"]:
        test_command.append("--classification-only")
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = visible_gpu
    subprocess.run(test_command, check=True, env=env)


def test_summary_uses_current_mask_rule(run_dir: Path, experiment: str) -> bool:
    summary_json = run_dir / "test" / "test_summary.json"
    if not summary_json.exists():
        return False
    try:
        summary = json.loads(summary_json.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return False
    expected_masks = 0 if EXPERIMENTS[experiment]["classification_only"] else 26
    return summary.get("n_cases") == 148 and summary.get("n_valid_masks") == expected_masks


def worker(args) -> int:
    project_root = Path(args.project_root).resolve()
    output_root = Path(args.output_root)
    if not output_root.is_absolute():
        output_root = project_root / output_root
    output_root = output_root.resolve()
    config = EXPERIMENTS[args.experiment]
    visible_gpu = (
        str(args.gpu_override)
        if args.gpu_override is not None
        else config["gpu"]
    )
    os.environ["CUDA_VISIBLE_DEVICES"] = visible_gpu
    os.environ["PICAI_PROJECT_ROOT"] = str(data_root())
    validate_server_inputs(project_root)

    branch_dir = project_root / config["branch"]
    run_dir = (
        output_root
        / args.experiment
        / f"seed_{args.seed}"
    )
    checkpoint_dir = run_dir / "checkpoints"
    test_dir = run_dir / "test"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    test_dir.mkdir(parents=True, exist_ok=True)
    checkpoint = checkpoint_dir / config["checkpoint_name"]

    metadata = {
        "experiment": args.experiment,
        "seed": args.seed,
        "physical_gpu": visible_gpu,
        "branch_dir": str(branch_dir),
        "train_script": str(branch_dir / config["train_script"]),
        "checkpoint": str(checkpoint),
        "test_dir": str(test_dir),
    }
    (run_dir / "run_config.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )

    module = load_training_module(
        branch_dir / config["train_script"],
        visible_gpu,
    )
    install_project_path_remapping(module, project_root)
    module.SEED = args.seed
    module.CHECKPOINT_DIR = checkpoint_dir
    module.MODEL_SAVE_PATH = checkpoint
    module.VIS_DIR = run_dir / "visualizations_disabled"
    module.NUM_WORKERS = args.num_workers
    if args.epochs is not None:
        module.EPOCHS = args.epochs
    if hasattr(module, "save_visualization"):
        module.save_visualization = lambda *unused_args, **unused_kwargs: None

    print(
        f"[START] experiment={args.experiment} seed={args.seed} "
        f"physical_gpu={visible_gpu} visible_device=cuda:0 output={run_dir}",
        flush=True,
    )
    module.main()
    if not checkpoint.exists():
        raise FileNotFoundError(f"Training finished without checkpoint: {checkpoint}")

    run_saved_checkpoint_test(
        project_root=project_root,
        experiment=args.experiment,
        seed=args.seed,
        checkpoint=checkpoint,
        test_dir=test_dir,
        num_workers=args.num_workers,
        visible_gpu=visible_gpu,
    )
    print(
        f"[DONE] experiment={args.experiment} seed={args.seed} "
        f"summary={test_dir / 'test_summary.md'}",
        flush=True,
    )
    return 0


def run_subprocess(
    project_root: Path,
    experiment: str,
    seed: int,
    args,
) -> None:
    output_root = Path(args.output_root)
    if not output_root.is_absolute():
        output_root = project_root / output_root
    run_dir = output_root.resolve() / experiment / f"seed_{seed}"
    run_dir.mkdir(parents=True, exist_ok=True)
    completed_summary = run_dir / "test" / "test_summary.md"
    if completed_summary.exists():
        if not test_summary_uses_current_mask_rule(run_dir, experiment):
            config = EXPERIMENTS[experiment]
            checkpoint = (
                run_dir / "checkpoints" / config["checkpoint_name"]
            )
            if not checkpoint.exists():
                raise FileNotFoundError(
                    f"Completed summary needs refreshed testing, but checkpoint "
                    f"is missing: {checkpoint}"
                )
            visible_gpu = (
                str(args.gpu_override)
                if args.gpu_override is not None
                else config["gpu"]
            )
            print(
                f"[RETEST] experiment={experiment} seed={seed} "
                "using current 26-mask evaluation rule",
                flush=True,
            )
            run_saved_checkpoint_test(
                project_root=project_root,
                experiment=experiment,
                seed=seed,
                checkpoint=checkpoint,
                test_dir=run_dir / "test",
                num_workers=args.num_workers,
                visible_gpu=visible_gpu,
            )
        print(
            f"[SKIP] experiment={experiment} seed={seed} already completed: "
            f"{completed_summary}",
            flush=True,
        )
        return
    log_path = run_dir / "train_and_test.log"
    if log_path.exists() or any((run_dir / "checkpoints").glob("*.pth")):
        raise RuntimeError(f"Incomplete existing run: {run_dir}. Select a new --output-root to preserve these files.")
    command = [
        sys.executable,
        str(Path(__file__).resolve()),
        "--worker",
        "--project-root",
        str(project_root),
        "--output-root",
        str(output_root.resolve()),
        "--experiment",
        experiment,
        "--seed",
        str(seed),
        "--num-workers",
        str(args.num_workers),
    ]
    if args.epochs is not None:
        command.extend(["--epochs", str(args.epochs)])
    if args.gpu_override is not None:
        command.extend(["--gpu-override", str(args.gpu_override)])

    with log_path.open("w", encoding="utf-8", errors="replace") as log:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        assert process.stdout is not None
        for line in process.stdout:
            tagged = f"[{experiment} seed={seed}] {line}"
            print(tagged, end="", flush=True)
            log.write(line)
            log.flush()
        return_code = process.wait()
    if return_code != 0:
        raise subprocess.CalledProcessError(return_code, command)


def run_experiment_series(
    project_root: Path,
    experiment: str,
    seeds: list[int],
    args,
) -> None:
    for seed in seeds:
        run_subprocess(project_root, experiment, seed, args)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run classification, MTL, and MTL+Focal with additional seeds."
    )
    parser.add_argument("--project-root", default=str(project_root_from_script()))
    parser.add_argument(
        "--output-root",
        default="results/runs",
        help="Output directory, absolute or relative to the project root.",
    )
    parser.add_argument(
        "--experiments",
        nargs="+",
        choices=sorted(EXPERIMENTS),
        default=list(EXPERIMENTS),
    )
    parser.add_argument("--seeds", nargs="+", type=int, default=[42, 7, 2026])
    parser.set_defaults(parallel=False)
    parser.add_argument(
        "--parallel",
        dest="parallel",
        action="store_true",
        help="Run experiment branches concurrently (requires enough GPUs).",
    )
    parser.add_argument(
        "--sequential",
        dest="parallel",
        action="store_false",
        help="Run all experiment branches sequentially (default).",
    )
    parser.add_argument("--num-workers", type=int, default=4)
    parser.add_argument(
        "--gpu-override",
        type=int,
        default=None,
        help="Map every selected experiment to this physical GPU.",
    )
    parser.add_argument(
        "--epochs",
        type=int,
        default=None,
        help="Testing only. Omit for the manuscript experiment (100 epochs).",
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--experiment", choices=sorted(EXPERIMENTS))
    parser.add_argument("--seed", type=int)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.worker:
        if args.experiment is None or args.seed is None:
            raise ValueError("--worker requires --experiment and --seed")
        return worker(args)

    project_root = Path(args.project_root).resolve()
    output_root = Path(args.output_root)
    if not output_root.is_absolute():
        output_root = project_root / output_root
    output_root = output_root.resolve()
    jobs = [
        {
            "experiment": experiment,
            "gpu": (
                str(args.gpu_override)
                if args.gpu_override is not None
                else EXPERIMENTS[experiment]["gpu"]
            ),
            "seeds": args.seeds,
            "output": str(output_root / experiment),
        }
        for experiment in args.experiments
    ]
    print(json.dumps(jobs, indent=2), flush=True)
    if args.dry_run:
        return 0

    validate_server_inputs(project_root)
    if args.parallel:
        with ThreadPoolExecutor(max_workers=len(args.experiments)) as executor:
            futures = {
                executor.submit(
                    run_experiment_series,
                    project_root,
                    experiment,
                    args.seeds,
                    args,
                ): experiment
                for experiment in args.experiments
            }
            for future in as_completed(futures):
                experiment = futures[future]
                future.result()
                print(f"[SERIES DONE] {experiment}", flush=True)
    else:
        for experiment in args.experiments:
            run_experiment_series(project_root, experiment, args.seeds, args)

    completed_all_core_experiments = set(args.experiments) == set(EXPERIMENTS)
    if completed_all_core_experiments:
        summary_seeds = list(dict.fromkeys(args.seeds))
        summary_command = [
            sys.executable,
            str(
                project_root
                / "evaluation"
                / "summarize_multiseed.py"
            ),
            "--root",
            str(output_root),
            "--seeds",
            *[str(seed) for seed in summary_seeds],
        ]
        print("[SUMMARY] " + " ".join(summary_command), flush=True)
        subprocess.run(summary_command, check=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
