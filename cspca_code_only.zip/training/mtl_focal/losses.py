import torch
import torch.nn as nn
import torch.nn.functional as F


class DiceLoss(nn.Module):
    def __init__(self, smooth=1e-5):
        super(DiceLoss, self).__init__()
        self.smooth = smooth

    def forward(self, preds, targets):
        # preds: [B, 1, H, W, D] 或 [B, 1, D, H, W]
        # targets: [B, 1, H, W, D] 或 [B, 1, D, H, W]
        preds = torch.sigmoid(preds)

        # 展平
        preds_flat = preds.view(preds.size(0), -1)
        targets_flat = targets.view(targets.size(0), -1)

        intersection = (preds_flat * targets_flat).sum(dim=1)
        union = preds_flat.sum(dim=1) + targets_flat.sum(dim=1)

        dice = (2. * intersection + self.smooth) / (union + self.smooth)
        return 1.0 - dice.mean()


# ==================== 【实验A新增：Focal Loss】 ====================
class FocalLoss(nn.Module):
    def __init__(self, alpha=0.25, gamma=2.0):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, preds, targets):
        # preds 必须是 logits (未经过 sigmoid)
        bce_loss = F.binary_cross_entropy_with_logits(preds, targets, reduction='none')
        pt = torch.exp(-bce_loss)  # 获取预测正确的概率
        focal_loss = self.alpha * (1 - pt) ** self.gamma * bce_loss
        return focal_loss.mean()
# ==============================================================


class MultiTaskLoss(nn.Module):
    def __init__(self, lambda_cls=0.05, pos_weight_val=7.5):
        """
        pos_weight_val: 论文实验在前期开发后固定的阳性类别权重
        """
        super().__init__()
        self.lambda_cls = lambda_cls

        # 动态检测可用设备，防止多卡或单卡训练时报错
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        pos_weight = torch.tensor([pos_weight_val], dtype=torch.float).to(device)

        self.seg_criterion_dice = DiceLoss()
        self.seg_criterion_focal = FocalLoss()  # 挂载 Focal Loss
        self.cls_criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

    def forward(self, masks_pred, masks_gt, cls_logits, cls_labels, has_valid_mask):
        """
        masks_pred: [B, 1, D, H, W]
        masks_gt: [B, 1, D, H, W]
        cls_logits: [B, 1]
        cls_labels: [B, 1]
        has_valid_mask: [B, 1] - 指示该样本是否有有效Mask
        """
        # 1. 分类损失 (所有样本都参与分类损失计算)
        loss_cls = self.cls_criterion(cls_logits, cls_labels)

        # 2. 分割损失 (只有阳性样本且有有效Mask的才计算)
        valid_indices = (has_valid_mask.view(-1) == 1.0).nonzero(as_tuple=True)[0]

        if len(valid_indices) > 0:
            valid_masks_pred = masks_pred[valid_indices]
            valid_masks_gt = masks_gt[valid_indices]

            # 计算 Dice Loss
            loss_dice = self.seg_criterion_dice(valid_masks_pred, valid_masks_gt)
            # 计算 Focal Loss
            loss_focal = self.seg_criterion_focal(valid_masks_pred, valid_masks_gt)

            # 组合 Seg Loss (Dice 主导，Focal 辅助惩罚困难样本)
            loss_seg = loss_dice + 0.5 * loss_focal
        else:
            loss_seg = torch.tensor(0.0, device=masks_pred.device, requires_grad=True)

        # 3. 总损失
        loss = loss_seg + self.lambda_cls * loss_cls

        return loss, loss_seg, loss_cls
