"""Run the copied original segmentation trainer with portable table paths."""
import os
from settings import ROOT,data_root,settings
import run_multiseed as runner

def main():
    os.environ['PICAI_PROJECT_ROOT']=str(data_root())
    runner.validate_server_inputs(ROOT, require_pretraining=False)
    m=runner.load_training_module(ROOT/'training/pretraining/train.py',str(settings()['gpu']))
    runner.install_project_path_remapping(m,ROOT)
    m.TRAIN_MUL_TABLE=ROOT/'configs/splits/train_mul.xlsx'
    m.VAL_MUL_TABLE=ROOT/'configs/splits/val_mul.xlsx'
    m.CHECKPOINT_DIR.mkdir(parents=True,exist_ok=True)
    m.VIS_DIR.mkdir(parents=True,exist_ok=True)
    m.main()

if __name__=='__main__':main()
