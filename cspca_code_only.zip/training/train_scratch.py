"""Same MTL implementation and schedule; skip pretraining loading only."""
import argparse,json,os,subprocess,sys
from settings import ROOT,data_root,environment,settings
import run_multiseed as runner

def worker(seed):
    s=settings();os.environ['PICAI_PROJECT_ROOT']=str(data_root())
    runner.validate_server_inputs(ROOT, require_pretraining=False)
    out=ROOT/'results/runs/mtl_scratch'/f'seed_{seed}'
    m=runner.load_training_module(ROOT/'training/mtl/train.py',str(s['gpu']))
    runner.install_project_path_remapping(m,ROOT)
    m.SEED=seed;m.NUM_WORKERS=s['num_workers'];m.EPOCHS=s['epochs']
    m.CHECKPOINT_DIR=out/'checkpoints';m.CHECKPOINT_DIR.mkdir(parents=True,exist_ok=True)
    m.MODEL_SAVE_PATH=m.CHECKPOINT_DIR/'best_multitask_model.pth'
    m.save_visualization=lambda *a,**k:None
    m.load_pretrained_weights=lambda model,path:model
    m.main()
    runner.run_saved_checkpoint_test(ROOT,'mtl',seed,m.MODEL_SAVE_PATH,out/'test',s['num_workers'],str(s['gpu']))

def main():
    p=argparse.ArgumentParser();p.add_argument('--worker',type=int);p.add_argument('--dry-run',action='store_true');a=p.parse_args()
    if a.dry_run:print(json.dumps(dict(experiment='mtl_scratch',**settings(),sequential=True),indent=2));return
    if a.worker is not None:worker(a.worker);return
    for seed in settings()['seeds']:
        out=ROOT/'results/runs/mtl_scratch'/f'seed_{seed}'
        if (out/'test/test_predictions.csv').is_file():print(f'SKIP existing predictions: seed {seed}',flush=True);continue
        if out.exists() and any(out.iterdir()):raise RuntimeError(f'Use a separate empty run folder before retraining: {out}')
        subprocess.run([sys.executable,'-u',__file__,'--worker',str(seed)],env=environment(),check=True)

if __name__=='__main__':main()
