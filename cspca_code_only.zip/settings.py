"""Shared path settings; no data or weights are moved automatically."""
import json
import os
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def settings():
    return json.loads((ROOT/'configs/settings.json').read_text(encoding='utf-8-sig'))

def data_root():
    value=os.environ.get('PICAI_DATA_ROOT') or settings().get('data_root')
    if value:
        path=Path(value).expanduser()
        return (ROOT/path).resolve() if not path.is_absolute() else path.resolve()
    if (ROOT.parent/'data').is_dir(): return ROOT.parent
    return ROOT

MODELS=('classification','mtl','mtl_focal','mtl_scratch')

def checkpoint(model,seed):
    name='best_cls_model.pth' if model=='classification' else 'best_multitask_model.pth'
    folder=ROOT/'weights'/model/f'seed_{seed}'
    preferred=folder/name
    legacy=folder/'best_model.pth'
    return preferred if preferred.is_file() or not legacy.is_file() else legacy

def environment():
    env=os.environ.copy()
    env['PICAI_PROJECT_ROOT']=str(data_root())
    env['PICAI_DATA_ROOT']=str(data_root())
    env['PYTHONPATH']=str(ROOT)+os.pathsep+env.get('PYTHONPATH','')
    env['PYTHONIOENCODING']='utf-8'
    env['PYTHONDONTWRITEBYTECODE']='1'
    env['CUDA_VISIBLE_DEVICES']=str(settings()['gpu'])
    return env
