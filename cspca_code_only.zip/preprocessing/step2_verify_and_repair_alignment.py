# prepare_datasets/step2_verify_and_repair_alignment.py
"""
目标：
验证有人工病灶 mask 的样本中，human lesion mask 是否与 T2W 对齐，
并检查 ADC/HBV/T2W 的基础空间信息是否合理。

额外功能：
如果发现 ADC 与 HBV 的 shape 不一致，则自动将 HBV 重采样到 ADC 空间，
保存到 data/nii_resampled_hbv_to_adc/{patient_id}/ 中，
并直接修改 dataset_master.csv 中原有的 hbv_path。

重要说明：
1. 本脚本不会把 ADC/HBV 重采样到 T2W。
2. 本脚本只修复 ADC shape != HBV shape 的情况。
3. 原本 ADC/HBV shape 一致的数据，adc_path/hbv_path 保持不变。
4. 不新增 adc_resampled_to_t2w_path / hbv_resampled_to_t2w_path 列。
5. human lesion mask 理论上已经在 T2W 空间，只验证，不自动重采样。

输入：
  data/tables/dataset_master.csv

依赖字段：
  patient_id
  t2w_path
  adc_path
  hbv_path
  mask_path_human
  has_valid_human_mask
  cspca_label
  isup_grade

输出：
  1. data/tables/dataset_master.csv
     - 原地更新 hbv_path
     - 只有 ADC/HBV shape 不一致的样本会被替换为重采样后的 HBV 路径

  2. data/tables/dataset_master_before_hbv_to_adc_backup.csv
     - 原始 dataset_master.csv 备份

  3. data/tables/lesion_mask_align_report.csv
     - 逐例验证报告

  4. data/tables/lesion_mask_align_summary.csv
     - 汇总报告

  5. data/nii_resampled_hbv_to_adc/{patient_id}/{patient_id}_hbv_to_adc.nii.gz
     - 保存被重采样后的 HBV
"""

import shutil
import numpy as np
import pandas as pd
import nibabel as nib
from pathlib import Path
from settings import data_root
from tqdm import tqdm
from scipy.ndimage import affine_transform


# ========== 路径配置 ==========
BASE_DIR = data_root()

TABLE_DIR = BASE_DIR / "data/tables"

MASTER = TABLE_DIR / "dataset_master.csv"

BACKUP_MASTER = TABLE_DIR / "dataset_master_before_hbv_to_adc_backup.csv"

OUT_REPORT  = TABLE_DIR / "lesion_mask_align_report.csv"
OUT_SUMMARY = TABLE_DIR / "lesion_mask_align_summary.csv"

RESAMPLED_DIR = BASE_DIR / "data/nii_resampled_hbv_to_adc"
RESAMPLED_DIR.mkdir(parents=True, exist_ok=True)


# ========== 工具函数 ==========
def safe_bool(x):
    """
    兼容 bool / str / int / nan。
    """
    if isinstance(x, bool):
        return x

    if pd.isna(x):
        return False

    s = str(x).strip().lower()
    return s in ["true", "1", "yes", "y"]


def safe_path(x):
    """
    将 csv 中的路径字段安全转为字符串。
    """
    if pd.isna(x):
        return ""

    s = str(x).strip()

    if s.lower() in ["", "nan", "none"]:
        return ""

    return s


def path_exists(p):
    p = safe_path(p)

    if p == "":
        return False

    return Path(p).exists()


def get_spacing(nii):
    """
    从 affine 计算 spacing。
    比 np.abs(np.diag(affine)) 更稳健，可处理非纯对角 affine。
    """
    affine_3x3 = nii.affine[:3, :3]
    spacing = np.sqrt(np.sum(affine_3x3 ** 2, axis=0))
    return tuple(np.round(spacing, 4))


def is_spacing_reasonable(spacing, kind):
    """
    检查 spacing 是否在合理范围。

    kind:
      - "t2w": T2W 高分辨率序列
      - "dwi": ADC/HBV 低分辨率序列
    """
    if spacing is None or len(spacing) < 3:
        return False

    x, y, z = spacing[:3]

    if kind == "t2w":
        return bool(
            0.1 <= x <= 1.5 and
            0.1 <= y <= 1.5 and
            0.5 <= z <= 5.0
        )

    if kind == "dwi":
        return bool(
            0.1 <= x <= 4.0 and
            0.1 <= y <= 4.0 and
            0.5 <= z <= 5.0
        )

    return False


def mask_nonzero(mask_nii):
    """
    判断 mask 是否非零。
    """
    data = mask_nii.get_fdata()
    return bool(np.any(data > 0))


def compare_affine(a, b, atol=1e-3):
    """
    affine 近似一致判断。
    """
    return bool(np.allclose(a, b, atol=atol))


def resample_nib_to_reference(
    moving_nii,
    reference_nii,
    order=1,
    cval=0.0,
):
    """
    使用 nibabel + scipy 将 moving_nii 重采样到 reference_nii 空间。

    参数：
      moving_nii:
        需要重采样的图像，例如 HBV

      reference_nii:
        参考图像，例如 ADC

      order:
        插值方式
        - 图像：order=1，线性插值
        - mask：order=0，最近邻插值

      cval:
        超出边界填充值

    返回：
      nib.Nifti1Image，shape 和 affine 与 reference_nii 一致
    """
    moving_data = moving_nii.get_fdata().astype(np.float32)

    ref_shape = reference_nii.shape[:3]
    ref_affine = reference_nii.affine
    mov_affine = moving_nii.affine

    # scipy affine_transform 的矩阵是：
    # output voxel index -> input voxel index
    #
    # 对于 reference 的每个 voxel index i_ref:
    #   world = ref_affine @ i_ref
    #   i_mov = inv(mov_affine) @ world
    #
    # 所以：
    #   i_mov = inv(mov_affine) @ ref_affine @ i_ref
    transform = np.linalg.inv(mov_affine) @ ref_affine

    matrix = transform[:3, :3]
    offset = transform[:3, 3]

    resampled_data = affine_transform(
        moving_data,
        matrix=matrix,
        offset=offset,
        output_shape=ref_shape,
        order=order,
        mode="constant",
        cval=cval,
    ).astype(np.float32)

    new_header = reference_nii.header.copy()
    new_header.set_data_dtype(np.float32)

    out_nii = nib.Nifti1Image(
        resampled_data,
        affine=ref_affine,
        header=new_header,
    )

    return out_nii


def resample_hbv_to_adc_if_needed(
    patient_id,
    adc_nii,
    hbv_nii,
    hbv_path,
    overwrite=False,
):
    """
    只在 HBV shape 与 ADC shape 不一致时，将 HBV 重采样到 ADC 空间。

    返回：
      new_hbv_path
      hbv_was_resampled
      adc_hbv_shape_ok_after
      hbv_resample_error
    """
    adc_shape = adc_nii.shape[:3]
    hbv_shape = hbv_nii.shape[:3]

    # shape 一致则不处理，路径保持不变
    if adc_shape == hbv_shape:
        return hbv_path, False, True, ""

    try:
        out_dir = RESAMPLED_DIR / str(patient_id)
        out_dir.mkdir(parents=True, exist_ok=True)

        out_path = out_dir / f"{patient_id}_hbv_to_adc.nii.gz"

        if out_path.exists() and not overwrite:
            out_nii = nib.load(str(out_path))
        else:
            out_nii = resample_nib_to_reference(
                moving_nii=hbv_nii,
                reference_nii=adc_nii,
                order=1,
                cval=0.0,
            )
            nib.save(out_nii, str(out_path))

        ok_after = bool(out_nii.shape[:3] == adc_shape)

        return str(out_path), True, ok_after, ""

    except Exception as e:
        return hbv_path, False, False, str(e)


def verify_one_case(row):
    """
    验证单个病例。
    如 ADC/HBV shape 不一致，则重采样 HBV 到 ADC。

    返回：
      rec, new_hbv_path
    """
    pid = str(row["patient_id"])

    t2w_path = safe_path(row["t2w_path"])
    adc_path = safe_path(row["adc_path"])
    hbv_path = safe_path(row["hbv_path"])
    mask_path = safe_path(row["mask_path_human"])

    new_hbv_path = hbv_path

    rec = {
        "patient_id": pid,
        "cspca_label": row["cspca_label"] if "cspca_label" in row.index else "",
        "isup_grade": row["isup_grade"] if "isup_grade" in row.index else "",

        "t2w_path": t2w_path,
        "adc_path": adc_path,
        "hbv_path_before": hbv_path,
        "hbv_path_after": hbv_path,
        "mask_path_human": mask_path,

        # 文件存在性
        "t2w_exists": False,
        "adc_exists": False,
        "hbv_exists": False,
        "mask_exists": False,

        # 核心检查
        "mask_nonzero": False,
        "mask_t2w_shape_ok": False,
        "mask_t2w_affine_ok": False,
        "adc_hbv_shape_ok_before": False,
        "adc_hbv_shape_ok_after": False,

        # 是否重采样
        "hbv_was_resampled_to_adc": False,
        "hbv_resample_error": "",

        # spacing 合理性
        "t2w_spacing_ok": False,
        "adc_spacing_ok": False,
        "hbv_spacing_ok_before": False,
        "hbv_spacing_ok_after": False,

        # 总判断
        "all_ok_before": False,
        "all_ok_after": False,

        # 信息记录
        "t2w_shape": "",
        "adc_shape": "",
        "hbv_shape_before": "",
        "hbv_shape_after": "",
        "mask_shape": "",

        "t2w_spacing": "",
        "adc_spacing": "",
        "hbv_spacing_before": "",
        "hbv_spacing_after": "",
        "mask_spacing": "",

        "max_mask_t2w_affine_abs_diff": "",

        "error": "",
    }

    try:
        # ---------- 文件存在性 ----------
        rec["t2w_exists"] = path_exists(t2w_path)
        rec["adc_exists"] = path_exists(adc_path)
        rec["hbv_exists"] = path_exists(hbv_path)
        rec["mask_exists"] = path_exists(mask_path)

        if not rec["t2w_exists"]:
            rec["error"] = "T2W file not found"
            return rec, new_hbv_path

        if not rec["adc_exists"]:
            rec["error"] = "ADC file not found"
            return rec, new_hbv_path

        if not rec["hbv_exists"]:
            rec["error"] = "HBV file not found"
            return rec, new_hbv_path

        if not rec["mask_exists"]:
            rec["error"] = "human lesion mask file not found"
            return rec, new_hbv_path

        # ---------- 读取 nii ----------
        t2w_nii = nib.load(t2w_path)
        adc_nii = nib.load(adc_path)
        hbv_nii = nib.load(hbv_path)
        mask_nii = nib.load(mask_path)

        # ---------- shape before ----------
        t2w_shape = t2w_nii.shape[:3]
        adc_shape = adc_nii.shape[:3]
        hbv_shape_before = hbv_nii.shape[:3]
        mask_shape = mask_nii.shape[:3]

        rec["t2w_shape"] = str(t2w_shape)
        rec["adc_shape"] = str(adc_shape)
        rec["hbv_shape_before"] = str(hbv_shape_before)
        rec["mask_shape"] = str(mask_shape)

        # ---------- spacing before ----------
        t2w_spacing = get_spacing(t2w_nii)
        adc_spacing = get_spacing(adc_nii)
        hbv_spacing_before = get_spacing(hbv_nii)
        mask_spacing = get_spacing(mask_nii)

        rec["t2w_spacing"] = str(t2w_spacing)
        rec["adc_spacing"] = str(adc_spacing)
        rec["hbv_spacing_before"] = str(hbv_spacing_before)
        rec["mask_spacing"] = str(mask_spacing)

        # ---------- mask 非零 ----------
        rec["mask_nonzero"] = mask_nonzero(mask_nii)

        # ---------- lesion mask vs T2W ----------
        rec["mask_t2w_shape_ok"] = bool(mask_shape == t2w_shape)

        rec["mask_t2w_affine_ok"] = compare_affine(
            t2w_nii.affine,
            mask_nii.affine,
            atol=1e-3
        )

        rec["max_mask_t2w_affine_abs_diff"] = float(
            np.max(np.abs(t2w_nii.affine - mask_nii.affine))
        )

        # ---------- ADC vs HBV before ----------
        rec["adc_hbv_shape_ok_before"] = bool(adc_shape == hbv_shape_before)

        # ---------- spacing 合理性 before ----------
        rec["t2w_spacing_ok"] = is_spacing_reasonable(t2w_spacing, kind="t2w")
        rec["adc_spacing_ok"] = is_spacing_reasonable(adc_spacing, kind="dwi")
        rec["hbv_spacing_ok_before"] = is_spacing_reasonable(hbv_spacing_before, kind="dwi")

        # ---------- 总判断 before ----------
        rec["all_ok_before"] = bool(
            rec["t2w_exists"]
            and rec["adc_exists"]
            and rec["hbv_exists"]
            and rec["mask_exists"]
            and rec["mask_nonzero"]
            and rec["mask_t2w_shape_ok"]
            and rec["mask_t2w_affine_ok"]
            and rec["adc_hbv_shape_ok_before"]
            and rec["t2w_spacing_ok"]
            and rec["adc_spacing_ok"]
            and rec["hbv_spacing_ok_before"]
        )

        # =====================================================
        # 如果 ADC/HBV shape 不一致，则重采样 HBV 到 ADC 空间
        # =====================================================
        (
            new_hbv_path,
            hbv_was_resampled,
            adc_hbv_shape_ok_after,
            hbv_resample_error,
        ) = resample_hbv_to_adc_if_needed(
            patient_id=pid,
            adc_nii=adc_nii,
            hbv_nii=hbv_nii,
            hbv_path=hbv_path,
            overwrite=False,
        )

        rec["hbv_path_after"] = new_hbv_path
        rec["hbv_was_resampled_to_adc"] = hbv_was_resampled
        rec["adc_hbv_shape_ok_after"] = adc_hbv_shape_ok_after
        rec["hbv_resample_error"] = hbv_resample_error

        # ---------- after 检查 ----------
        if path_exists(new_hbv_path):
            hbv_after_nii = nib.load(new_hbv_path)
            hbv_shape_after = hbv_after_nii.shape[:3]
            hbv_spacing_after = get_spacing(hbv_after_nii)

            rec["hbv_shape_after"] = str(hbv_shape_after)
            rec["hbv_spacing_after"] = str(hbv_spacing_after)

            rec["adc_hbv_shape_ok_after"] = bool(adc_shape == hbv_shape_after)

            # HBV to ADC 后，spacing 应按 DWI 合理范围判断
            rec["hbv_spacing_ok_after"] = is_spacing_reasonable(
                hbv_spacing_after,
                kind="dwi"
            )
        else:
            rec["hbv_shape_after"] = ""
            rec["hbv_spacing_after"] = ""
            rec["hbv_spacing_ok_after"] = False
            rec["adc_hbv_shape_ok_after"] = False

        # ---------- 总判断 after ----------
        rec["all_ok_after"] = bool(
            rec["t2w_exists"]
            and rec["adc_exists"]
            and rec["hbv_exists"]
            and rec["mask_exists"]
            and rec["mask_nonzero"]
            and rec["mask_t2w_shape_ok"]
            and rec["mask_t2w_affine_ok"]
            and rec["adc_hbv_shape_ok_after"]
            and rec["t2w_spacing_ok"]
            and rec["adc_spacing_ok"]
            and rec["hbv_spacing_ok_after"]
        )

    except Exception as e:
        rec["error"] = str(e)

    return rec, new_hbv_path


# ========== 主程序 ==========
def main():
    print("📖 读取 dataset_master.csv ...")
    df = pd.read_csv(MASTER)
    print(f"   dataset_master 总行数: {len(df)}")

    required_cols = [
        "patient_id",
        "t2w_path",
        "adc_path",
        "hbv_path",
        "mask_path_human",
        "has_valid_human_mask",
    ]

    missing_cols = [c for c in required_cols if c not in df.columns]

    if len(missing_cols) > 0:
        raise ValueError(
            f"dataset_master.csv 缺少必要列: {missing_cols}\n"
            f"请先运行 step1_build_dataset_master.py"
        )

    # ========== 备份原始 dataset_master.csv ==========
    if not BACKUP_MASTER.exists():
        shutil.copy2(MASTER, BACKUP_MASTER)
        print(f"💾 已备份原始总表: {BACKUP_MASTER}")
    else:
        print(f"📌 备份文件已存在，不重复覆盖: {BACKUP_MASTER}")

    # 只检查有效 human lesion mask 的样本
    df_seg = df[df["has_valid_human_mask"].apply(safe_bool)].reset_index()

    print(f"🔍 需要验证 human lesion mask 对齐的样本数: {len(df_seg)}")
    print("🔄 如果 ADC/HBV shape 不一致，将只把 HBV 重采样到 ADC 空间，并更新 hbv_path ...")

    records = []

    for _, row_with_index in tqdm(df_seg.iterrows(), total=len(df_seg), desc="验证并修复 HBV"):
        original_idx = row_with_index["index"]
        row = row_with_index.drop(labels=["index"])

        rec, new_hbv_path = verify_one_case(row)
        records.append(rec)

        # 只修改原始 df 中已有的 hbv_path
        # 对齐数据路径不变
        # 不对齐数据替换为重采样后的 HBV 路径
        if safe_path(new_hbv_path) != "":
            df.loc[original_idx, "hbv_path"] = new_hbv_path

    report = pd.DataFrame(records)
    report.to_csv(OUT_REPORT, index=False)

    # ========== 将修改后的 dataset_master.csv 写回 ==========
    df.to_csv(MASTER, index=False)

    # ========== 汇总 ==========
    summary_items = []

    def add_summary(item, value):
        summary_items.append({
            "item": item,
            "value": value,
        })

    add_summary("total_samples_in_dataset_master", len(df))
    add_summary("samples_with_valid_human_mask", len(df_seg))

    if len(report) > 0:
        add_summary("t2w_exists", int(report["t2w_exists"].sum()))
        add_summary("adc_exists", int(report["adc_exists"].sum()))
        add_summary("hbv_exists", int(report["hbv_exists"].sum()))
        add_summary("mask_exists", int(report["mask_exists"].sum()))

        add_summary("mask_nonzero", int(report["mask_nonzero"].sum()))
        add_summary("mask_t2w_shape_ok", int(report["mask_t2w_shape_ok"].sum()))
        add_summary("mask_t2w_affine_ok", int(report["mask_t2w_affine_ok"].sum()))

        add_summary("adc_hbv_shape_ok_before", int(report["adc_hbv_shape_ok_before"].sum()))
        add_summary("adc_hbv_shape_ok_after", int(report["adc_hbv_shape_ok_after"].sum()))

        add_summary("hbv_was_resampled_to_adc", int(report["hbv_was_resampled_to_adc"].sum()))

        add_summary("t2w_spacing_ok", int(report["t2w_spacing_ok"].sum()))
        add_summary("adc_spacing_ok", int(report["adc_spacing_ok"].sum()))
        add_summary("hbv_spacing_ok_before", int(report["hbv_spacing_ok_before"].sum()))
        add_summary("hbv_spacing_ok_after", int(report["hbv_spacing_ok_after"].sum()))

        add_summary("all_ok_before", int(report["all_ok_before"].sum()))
        add_summary("all_ok_after", int(report["all_ok_after"].sum()))
        add_summary("not_all_ok_after", int((~report["all_ok_after"]).sum()))
    else:
        add_summary("t2w_exists", 0)
        add_summary("adc_exists", 0)
        add_summary("hbv_exists", 0)
        add_summary("mask_exists", 0)
        add_summary("mask_nonzero", 0)
        add_summary("mask_t2w_shape_ok", 0)
        add_summary("mask_t2w_affine_ok", 0)
        add_summary("adc_hbv_shape_ok_before", 0)
        add_summary("adc_hbv_shape_ok_after", 0)
        add_summary("hbv_was_resampled_to_adc", 0)
        add_summary("t2w_spacing_ok", 0)
        add_summary("adc_spacing_ok", 0)
        add_summary("hbv_spacing_ok_before", 0)
        add_summary("hbv_spacing_ok_after", 0)
        add_summary("all_ok_before", 0)
        add_summary("all_ok_after", 0)
        add_summary("not_all_ok_after", 0)

    summary = pd.DataFrame(summary_items)
    summary.to_csv(OUT_SUMMARY, index=False)

    # ========== 控制台输出 ==========
    print(f"\n{'=' * 80}")
    print("  Human lesion mask 对齐验证 + HBV→ADC 修复结果")
    print(f"{'=' * 80}")
    print(f"  dataset_master 总样本数:             {len(df)}")
    print(f"  有效 human lesion mask 样本数:       {len(df_seg)}")

    if len(report) > 0:
        print(f"  T2W 文件存在:                        {int(report['t2w_exists'].sum())}")
        print(f"  ADC 文件存在:                        {int(report['adc_exists'].sum())}")
        print(f"  HBV 文件存在:                        {int(report['hbv_exists'].sum())}")
        print(f"  Human lesion mask 文件存在:          {int(report['mask_exists'].sum())}")

        print(f"\n  Lesion mask vs T2W:")
        print(f"  Human lesion mask 非零:              {int(report['mask_nonzero'].sum())}")
        print(f"  Mask shape 与 T2W 一致:              {int(report['mask_t2w_shape_ok'].sum())}")
        print(f"  Mask affine 与 T2W 一致:             {int(report['mask_t2w_affine_ok'].sum())}")

        print(f"\n  ADC/HBV:")
        print(f"  修复前 ADC shape 与 HBV 一致:         {int(report['adc_hbv_shape_ok_before'].sum())}")
        print(f"  HBV 被重采样到 ADC:                  {int(report['hbv_was_resampled_to_adc'].sum())}")
        print(f"  修复后 ADC shape 与 HBV 一致:         {int(report['adc_hbv_shape_ok_after'].sum())}")

        print(f"\n  Spacing:")
        print(f"  T2W spacing 合理:                    {int(report['t2w_spacing_ok'].sum())}")
        print(f"  ADC spacing 合理:                    {int(report['adc_spacing_ok'].sum())}")
        print(f"  HBV spacing 修复前合理:              {int(report['hbv_spacing_ok_before'].sum())}")
        print(f"  HBV spacing 修复后合理:              {int(report['hbv_spacing_ok_after'].sum())}")

        print(f"\n  总判断:")
        print(f"  修复前 all_ok:                       {int(report['all_ok_before'].sum())}")
        print(f"  修复后 all_ok:                       {int(report['all_ok_after'].sum())}")
        print(f"  修复后仍未全部通过:                  {int((~report['all_ok_after']).sum())}")
    else:
        print("  没有需要验证的有效 human lesion mask 样本。")

    print(f"{'=' * 80}")

    if len(report) > 0:
        bad = report[report["all_ok_after"] == False]

        if len(bad) > 0:
            print("\n⚠️  修复后仍存在异常样本，前 30 个：")

            show_cols = [
                "patient_id",
                "mask_nonzero",
                "mask_t2w_shape_ok",
                "mask_t2w_affine_ok",
                "adc_hbv_shape_ok_before",
                "hbv_was_resampled_to_adc",
                "adc_hbv_shape_ok_after",
                "t2w_shape",
                "mask_shape",
                "adc_shape",
                "hbv_shape_before",
                "hbv_shape_after",
                "t2w_spacing",
                "adc_spacing",
                "hbv_spacing_before",
                "hbv_spacing_after",
                "max_mask_t2w_affine_abs_diff",
                "hbv_resample_error",
                "error",
            ]

            show_cols = [c for c in show_cols if c in bad.columns]
            print(bad[show_cols].head(30).to_string(index=False))
        else:
            print("\n✅ 所有有效 human lesion mask 均与 T2W 对齐，ADC/HBV shape 已一致。")

    print(f"\n💾 已更新 dataset_master.csv: {MASTER}")
    print(f"💾 原始总表备份:              {BACKUP_MASTER}")
    print(f"💾 已保存详细报告:            {OUT_REPORT}")
    print(f"💾 已保存汇总报告:            {OUT_SUMMARY}")
    print(f"💾 HBV→ADC 重采样文件目录:     {RESAMPLED_DIR}")


if __name__ == "__main__":
    main()
