"""Step 4: create multitask table aliases from the fixed patient split."""

from pathlib import Path
from settings import data_root

import pandas as pd


def main():
    project_root = data_root()
    table_dir = project_root / "data" / "tables"
    train_src = table_dir / "train.xlsx"
    val_src = table_dir / "val.xlsx"
    train_mul_path = table_dir / "train_mul.xlsx"
    val_mul_path = table_dir / "val_mul.xlsx"

    train_df = pd.read_excel(train_src)
    val_df = pd.read_excel(val_src)

    train_pids = set(train_df["patient_id"].astype(str))
    val_pids = set(val_df["patient_id"].astype(str))
    overlap = train_pids & val_pids
    if overlap:
        raise RuntimeError(f"发现 {len(overlap)} 个交叉患者，请检查原始划分。")

    train_df.to_excel(train_mul_path, index=False)
    val_df.to_excel(val_mul_path, index=False)

    print("💾 已生成多任务专用表：")
    print(f"   ├── train_mul.xlsx ({len(train_df)} 行)")
    print(f"   └── val_mul.xlsx   ({len(val_df)} 行)")
    print("\n🔒 训练集和验证集患者零交集。")
    print("\n📊 有效病灶mask样本规模：")
    print(f"   ├─ 训练集: {int(train_df['has_valid_human_mask'].sum())} 例")
    print(f"   └─ 验证集: {int(val_df['has_valid_human_mask'].sum())} 例")


if __name__ == "__main__":
    main()
