# prepare_datasets/step3_build_patient_splits.py
"""
目标：从 dataset_master.csv 构建分层划分的训练/验证/测试表格
输入：data/tables/dataset_master.csv
输出：
  - train.xlsx        训练集（含 has_valid_human_mask 字段区分三任务/双任务）
  - val.xlsx          验证集
  - test.xlsx         测试集
  - train_seg.xlsx    训练集中有效mask子集（三任务：分类+分级+分割）
  - train_cls.xlsx    训练集中无有效mask子集（双任务：分类+分级）
划分比例：8:1:1，按 csPCa 标签分层，保证正负比例一致
"""

import numpy as np
import pandas as pd
from pathlib import Path
from settings import data_root
from sklearn.model_selection import train_test_split

# ========== 路径配置 ==========
BASE_DIR = data_root()

TABLE_DIR = BASE_DIR / "data/tables"
MASTER    = TABLE_DIR / "dataset_master.csv"

# ========== 读取总表 ==========
print("📖 读取 dataset_master.csv ...")
df = pd.read_csv(MASTER)
print(f"   原始总行数: {len(df)}")

# ========== 数据清洗 ==========
# 排除标签缺失（label=-1）
missing = df[df['cspca_label'] == -1]
if len(missing) > 0:
    print(f"\n⚠️  排除标签缺失: {len(missing)} 例")
    df = df[df['cspca_label'] != -1].reset_index(drop=True)

# 二次确认：有效mask中不应有阴性标签（step0已处理，此处兜底）
conflict = df[(df['has_valid_human_mask'] == True) & (df['cspca_label'] == 0)]
if len(conflict) > 0:
    print(f"⚠️  兜底清除标签冲突: {len(conflict)} 例（阴性但有非零mask）")
    df.loc[conflict.index, 'has_valid_human_mask'] = False
    df.loc[conflict.index, 'mask_path_human']      = ''

print(f"   清洗后有效总数: {len(df)}")
print(f"   ├─ csPCa 阳性: {(df['cspca_label']==1).sum()}")
print(f"   │    ├─ 有效mask: {df['has_valid_human_mask'].sum()}")
print(f"   │    └─ 无mask:   {((df['cspca_label']==1) & (~df['has_valid_human_mask'])).sum()}")
print(f"   └─ csPCa 阴性: {(df['cspca_label']==0).sum()}")

# ========== 分层划分 train:val:test = 8:1:1 ==========
print("\n✂️  分层划分数据集（8:1:1，按 csPCa 标签分层）...")
np.random.seed(42)

# 第一步：按 csPCa 标签分层，划出 10% 测试集
train_val, test = train_test_split(
    df,
    test_size=0.1,
    stratify=df['cspca_label'],
    random_state=42
)

# 第二步：剩余中再划出 ~11.1%，使最终比例为 8:1:1
train, val = train_test_split(
    train_val,
    test_size=0.111,
    stratify=train_val['cspca_label'],
    random_state=42
)

train = train.reset_index(drop=True)
val   = val.reset_index(drop=True)
test  = test.reset_index(drop=True)

# ========== 拆分训练集为 seg / cls 子集 ==========
train_seg = train[train['has_valid_human_mask'] == True].reset_index(drop=True)
train_cls = train[train['has_valid_human_mask'] == False].reset_index(drop=True)

# ========== 统计报告 ==========
print(f"\n{'='*55}")
print(f"  划分结果")
print(f"{'='*55}")

def print_split_info(name, subset):
    pos      = (subset["cspca_label"] == 1).sum()
    neg      = (subset["cspca_label"] == 0).sum()
    has_mask = subset["has_valid_human_mask"].sum()

    if "has_whole_gland_mask" in subset.columns:
        has_gland = subset["has_whole_gland_mask"].sum()
    else:
        has_gland = 0

    print(f"  {name:<16}: {len(subset):4d} 例  "
          f"阳性:{pos:3d}  阴性:{neg:4d}  "
          f"有效病灶mask:{has_mask:3d}  "
          f"whole gland:{has_gland:3d}")

print_split_info("训练集 (train)",     train)
print_split_info("  ├─ train_seg",     train_seg)
print_split_info("  └─ train_cls",     train_cls)
print_split_info("验证集 (val)",       val)
print_split_info("测试集 (test)",      test)
print(f"{'='*55}")

# ========== ISUP分布验证 ==========
print(f"\n📊 各集合 ISUP 分级分布（防止分级偏差）:")
print(f"  {'ISUP':<6}", end="")
for grade in sorted(df['isup_grade'].unique()):
    print(f"  {int(grade):>4}", end="")
print()
for name, subset in [("train", train), ("val", val), ("test", test)]:
    print(f"  {name:<6}", end="")
    for grade in sorted(df['isup_grade'].unique()):
        cnt = (subset['isup_grade'] == grade).sum()
        print(f"  {cnt:>4}", end="")
    print()

# ========== 保存 ==========
train.to_excel(    TABLE_DIR / "train.xlsx",     index=False)
val.to_excel(      TABLE_DIR / "val.xlsx",       index=False)
test.to_excel(     TABLE_DIR / "test.xlsx",      index=False)
train_seg.to_excel(TABLE_DIR / "train_seg.xlsx", index=False)
train_cls.to_excel(TABLE_DIR / "train_cls.xlsx", index=False)

print(f"\n💾 已保存至 {TABLE_DIR}:")
print(f"   ├── train.xlsx     ({len(train):4d} 行)")
print(f"   ├── val.xlsx       ({len(val):4d} 行)")
print(f"   ├── test.xlsx      ({len(test):4d} 行)")
print(f"   ├── train_seg.xlsx ({len(train_seg):4d} 行)  ← 三任务训练（分类+分级+分割）")
print(f"   └── train_cls.xlsx ({len(train_cls):4d} 行)  ← 双任务训练（分类+分级）")

print("\n✅ step1 完成！")
