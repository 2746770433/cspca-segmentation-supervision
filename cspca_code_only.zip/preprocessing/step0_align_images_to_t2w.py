"""Step 0: align all MRI sequences to each case's T2W physical grid."""

from pathlib import Path
from settings import data_root
import SimpleITK as sitk
from tqdm import tqdm


def resample_image_to_ref(image, ref_image, is_label=False):
    """
    使用 SimpleITK 将 image 重采样并对齐到 ref_image 的物理空间网格
    """
    resampler = sitk.ResampleImageFilter()
    # 设置目标物理空间（Origin, Spacing, Direction, Size）
    resampler.SetReferenceImage(ref_image)

    # 根据数据类型选择插值方式
    if is_label:
        # 标签/Mask 必须使用最近邻插值，防止产生非整数的无效类别
        resampler.SetInterpolator(sitk.sitkNearestNeighbor)
    else:
        # 灰度图像（T2W, ADC, HBV 等）使用线性插值，保持图像平滑
        resampler.SetInterpolator(sitk.sitkLinear)

    return resampler.Execute(image)


def main():
    project_root = data_root()
    src_root = project_root / "data" / "nii"
    dst_root = project_root / "data" / "nii_resample"
    dst_root.mkdir(parents=True, exist_ok=True)

    if not src_root.exists():
        raise FileNotFoundError(f"原始影像目录不存在: {src_root}")

    # 获取所有病例文件夹（过滤掉非目录文件）
    case_dirs = sorted([d for d in src_root.iterdir() if d.is_dir()])
    print(f"📂 找到 {len(case_dirs)} 个病例文件夹。开始进行批量空间对齐...")

    for case_dir in tqdm(case_dirs, desc="正在对齐病例"):
        case_id = case_dir.name

        # 在目标目录下创建对应的病例文件夹
        dst_case_dir = dst_root / case_id
        dst_case_dir.mkdir(parents=True, exist_ok=True)

        # 1. 寻找该病例下的基准 T2W 图像
        t2w_files = list(case_dir.glob("*_t2w.nii.gz"))
        if len(t2w_files) == 0:
            print(f"\n⚠️ 警告: 病例 {case_id} 文件夹下未找到 *_t2w.nii.gz，跳过该病例！")
            continue

        t2w_path = t2w_files[0]

        try:
            # 读取基准 T2W 图像
            ref_t2w = sitk.ReadImage(str(t2w_path))

            # T2W 作为基准本身，直接保存到目标文件夹
            sitk.WriteImage(ref_t2w, str(dst_case_dir / t2w_path.name))

            # 2. 遍历该病例文件夹下的其他所有 .nii.gz 文件并进行对齐
            all_nii_files = list(case_dir.glob("*.nii.gz"))
            for file_path in all_nii_files:
                # 跳过 T2W 本身（上面已经保存过了）
                if "_t2w.nii.gz" in file_path.name:
                    continue

                # 判断是否为标签文件 (Mask)
                # 如果你的数据集里有分割标签（比如包含 'mask' 或 'label' 字符），请在此处指定
                # 如果该目录下纯粹只有影像（没有 Mask），则全部按灰度图插值
                is_label = "mask" in file_path.name.lower() or "label" in file_path.name.lower()

                # 加载待对齐图像
                img_to_align = sitk.ReadImage(str(file_path))

                # 执行重采样对齐
                aligned_img = resample_image_to_ref(img_to_align, ref_t2w, is_label=is_label)

                # 保存对齐后的图像到目标病例文件夹
                sitk.WriteImage(aligned_img, str(dst_case_dir / file_path.name))

        except Exception as e:
            print(f"\n❌ 处理病例 {case_id} 时发生错误: {str(e)}")

    print(f"\n🎉 恭喜！所有数据集的空间对齐与重采样已全部完成！")
    print(f"📂 对齐后的数据已保存在: {dst_root}")


if __name__ == "__main__":
    main()
