# prepare_datasets/step1_build_dataset_master.py
"""
Step 1：扫描对齐影像、标签与mask，生成 dataset_master.csv。

功能：
1. 扫描三模态 MRI:
   - T2W
   - ADC
   - HBV / DWI

2. 扫描 csPCa lesion mask:
   - human_expert/resampled
   - AI

3. 扫描 whole gland mask:
   - 优先使用 Guerbet23
   - 如果 Guerbet23 没有，再使用 Bosma22b

4. 在 dataset_master.csv 中只保留以下 whole gland 相关列：
   - whole_gland_mask_path
   - has_whole_gland_mask
   - gland_t2w_all_ok

5. 直接验证 whole gland mask 是否与 T2W 对齐：
   - shape 一致
   - affine 一致
   - spacing 一致
   - mask 非零
"""

import numpy as np
import pandas as pd
import nibabel as nib
from pathlib import Path
from settings import data_root
from tqdm import tqdm


# ========== 路径配置 ==========
BASE_DIR = data_root()

NII_DIR    = BASE_DIR / "data/nii_resample"
MARK_CSV   = BASE_DIR / "data/picai_labels-main/clinical_information/marksheet.csv"

MASK_HUMAN = BASE_DIR / "data/picai_labels-main/csPCa_lesion_delineations/human_expert/resampled"
MASK_AI    = BASE_DIR / "data/picai_labels-main/csPCa_lesion_delineations/AI"

# whole gland mask 路径
GLAND_BOSMA_DIR   = BASE_DIR / "data/picai_labels-main/anatomical_delineations/whole_gland/AI/Bosma22b"
GLAND_GUERBET_DIR = BASE_DIR / "data/picai_labels-main/anatomical_delineations/whole_gland/AI/Guerbet23"

OUT_DIR = BASE_DIR / "data/tables"
OUT_DIR.mkdir(parents=True, exist_ok=True)


# ========== 序列识别 ==========
SEQ_KEYWORDS = {
    "t2w": ["t2w", "t2"],
    "adc": ["adc"],
    "hbv": ["hbv", "dwi", "b1400", "b1500"],
}


def classify_seq(filename: str):
    fn = filename.lower()
    for seq, keywords in SEQ_KEYWORDS.items():
        if any(k in fn for k in keywords):
            return seq
    return None


# ========== 工具函数 ==========
def has_valid_mask(mask_path) -> bool:
    """
    判断 mask 是否存在且非零。
    """
    if not mask_path:
        return False

    mask_path = Path(str(mask_path))
    if not mask_path.exists():
        return False

    try:
        data = nib.load(str(mask_path)).get_fdata()
        return bool(np.any(data > 0))
    except Exception:
        return False


def parse_cspca(val) -> int:
    if pd.isna(val):
        return -1

    s = str(val).strip().upper()

    if s in ("YES", "TRUE", "1", "POSITIVE"):
        return 1

    if s in ("NO", "FALSE", "0", "NEGATIVE"):
        return 0

    return -1


def parse_isup(val) -> int:
    if pd.isna(val):
        return -1

    try:
        return int(float(str(val).strip()))
    except Exception:
        return -1


def find_first_mask(mask_dir: Path, pid: str, study_id: str = None):
    """
    根据 patient_id / study_id 查找 mask 文件。

    优先级：
    1. pid_study_id.nii.gz
    2. pid_*.nii.gz
    3. *pid*.nii.gz

    返回：
    str(path) 或 ''
    """
    if not mask_dir.exists():
        return ""

    candidates = []

    # 最精确：patient_id + study_id
    if study_id is not None and str(study_id).strip() != "":
        candidates.extend(list(mask_dir.glob(f"{pid}_{study_id}.nii*")))

    # 常规：patient_id 开头
    candidates.extend(list(mask_dir.glob(f"{pid}_*.nii*")))

    # 兜底：文件名中包含 patient_id
    candidates.extend(list(mask_dir.glob(f"*{pid}*.nii*")))

    candidates = sorted(list(dict.fromkeys(candidates)))

    if len(candidates) == 0:
        return ""

    return str(candidates[0])


def get_spacing(nii):
    """
    从 affine 计算 spacing。
    比直接取 np.diag 更稳健。
    """
    affine_3x3 = nii.affine[:3, :3]
    spacing = np.sqrt(np.sum(affine_3x3 ** 2, axis=0))
    return tuple(np.round(spacing, 4))


def check_gland_t2w_align(t2w_path, gland_path, affine_atol=1e-3, spacing_atol=1e-3):
    """
    检查 whole gland mask 是否与 T2W 对齐。

    条件：
    1. T2W 文件存在
    2. gland 文件存在
    3. gland 非零
    4. shape 一致
    5. affine 近似一致
    6. spacing 近似一致

    返回：
    True / False
    """
    if not t2w_path or not gland_path:
        return False

    t2w_path = Path(str(t2w_path))
    gland_path = Path(str(gland_path))

    if not t2w_path.exists():
        return False

    if not gland_path.exists():
        return False

    try:
        t2w_nii = nib.load(str(t2w_path))
        gland_nii = nib.load(str(gland_path))

        t2w_shape = t2w_nii.shape[:3]
        gland_shape = gland_nii.shape[:3]

        if t2w_shape != gland_shape:
            return False

        gland_data = gland_nii.get_fdata()
        if not np.any(gland_data > 0):
            return False

        affine_ok = np.allclose(t2w_nii.affine, gland_nii.affine, atol=affine_atol)
        if not affine_ok:
            return False

        t2w_spacing = get_spacing(t2w_nii)
        gland_spacing = get_spacing(gland_nii)

        spacing_ok = np.allclose(t2w_spacing, gland_spacing, atol=spacing_atol)
        if not spacing_ok:
            return False

        return True

    except Exception:
        return False


def select_whole_gland_mask(pid, study_id):
    """
    选择 whole gland mask。

    选择逻辑：
    1. 优先 Guerbet23
    2. Guerbet23 没有或无效，则用 Bosma22b
    3. 两者都没有，则返回空

    注意：
    这里的“有效”只表示文件存在且非零。
    是否与 T2W 对齐由 gland_t2w_all_ok 单独记录。
    """
    guerbet_path = find_first_mask(GLAND_GUERBET_DIR, pid, study_id)
    bosma_path = find_first_mask(GLAND_BOSMA_DIR, pid, study_id)

    valid_guerbet = has_valid_mask(guerbet_path)
    valid_bosma = has_valid_mask(bosma_path)

    if valid_guerbet:
        return guerbet_path

    if valid_bosma:
        return bosma_path

    return ""


# ========== 读取 marksheet ==========
print("📖 读取 marksheet.csv ...")
mark = pd.read_csv(MARK_CSV)
mark["patient_id"] = mark["patient_id"].astype(str).str.strip()

col_cspca, col_isup = None, None

for c in mark.columns:
    cl = c.lower()

    if "cspca" in cl or "cs_pca" in cl:
        col_cspca = c

    if "isup" in cl or "grade" in cl:
        col_isup = c

print(f"   csPCa列: {col_cspca}  |  ISUP列: {col_isup}")


# ========== 遍历患者目录 ==========
print("\n🔍 扫描患者目录 ...")
patient_dirs = sorted([d for d in NII_DIR.iterdir() if d.is_dir()])
print(f"   发现患者目录: {len(patient_dirs)} 个")

records = []
anomaly_count = 0

for p_dir in tqdm(patient_dirs, desc="处理患者"):
    pid = p_dir.name.strip()

    # ---------- 扫描三模态 ----------
    seq_map = {
        "t2w": None,
        "adc": None,
        "hbv": None,
    }

    study_id = None

    for f in p_dir.glob("*.nii*"):
        seq = classify_seq(f.name)

        if seq and seq_map[seq] is None:
            seq_map[seq] = str(f)

        if study_id is None:
            parts = f.stem.replace(".nii", "").split("_")
            if len(parts) >= 2:
                study_id = parts[1]

    # 三模态不完整则跳过
    if not all(seq_map.values()):
        continue

    # ---------- 匹配 csPCa lesion mask ----------
    human_masks = list(MASK_HUMAN.glob(f"{pid}_*.nii*"))
    ai_masks = list(MASK_AI.glob(f"{pid}_*.nii*"))

    mask_human_path = str(human_masks[0]) if human_masks else ""
    mask_ai_path = str(ai_masks[0]) if ai_masks else ""

    valid_human = has_valid_mask(mask_human_path)
    valid_ai = has_valid_mask(mask_ai_path)

    # ---------- 匹配 whole gland mask ----------
    whole_gland_mask_path = select_whole_gland_mask(pid, study_id)
    has_whole_gland_mask = bool(whole_gland_mask_path)

    # 直接验证 whole gland mask 是否与 T2W 对齐
    gland_t2w_all_ok = check_gland_t2w_align(
        t2w_path=seq_map["t2w"],
        gland_path=whole_gland_mask_path,
    )

    # ---------- 匹配临床标签 ----------
    row = mark[mark["patient_id"] == pid]

    if len(row) == 0:
        continue

    row = row.iloc[0]

    cspca_label = parse_cspca(row[col_cspca]) if col_cspca else -1
    isup_grade = parse_isup(row[col_isup]) if col_isup else -1

    # 阴性但有非零 human lesion mask，视为冲突并清除
    if cspca_label == 0 and valid_human:
        print(f"  ⚠️  标签冲突清除: patient={pid} | 阴性标签但有非零mask")
        valid_human = False
        mask_human_path = ""
        anomaly_count += 1

    records.append({
        "patient_id": pid,
        "study_id": study_id,

        # image paths
        "t2w_path": seq_map["t2w"],
        "adc_path": seq_map["adc"],
        "hbv_path": seq_map["hbv"],

        # csPCa lesion mask
        "mask_path_human": mask_human_path,
        "mask_path_ai": mask_ai_path,
        "has_human_mask_file": bool(human_masks),
        "has_valid_human_mask": valid_human,
        "has_ai_mask_file": bool(ai_masks),
        "has_valid_ai_mask": valid_ai,

        # whole gland mask：只保留这三列
        "whole_gland_mask_path": whole_gland_mask_path,
        "has_whole_gland_mask": has_whole_gland_mask,
        "gland_t2w_all_ok": gland_t2w_all_ok,

        # labels
        "cspca_label": cspca_label,
        "isup_grade": isup_grade,
    })


# ========== 保存 ==========
df = pd.DataFrame(records)
out_path = OUT_DIR / "dataset_master.csv"
df.to_csv(out_path, index=False)


# ========== 统计报告 ==========
print(f"\n{'=' * 65}")
print("  数据集总览")
print(f"{'=' * 65}")
print(f"  有效患者总数:                {len(df)}")
print(f"  ├─ csPCa 阳性:               {(df['cspca_label'] == 1).sum()}")
print(f"  │    ├─ 有真实病灶mask:      {df['has_valid_human_mask'].sum()}")
print(f"  │    └─ 无mask，仅标签:      {((df['cspca_label'] == 1) & (~df['has_valid_human_mask'])).sum()}")
print(f"  └─ csPCa 阴性:               {(df['cspca_label'] == 0).sum()}")

print(f"\n  Whole gland mask:")
print(f"  ├─ 有 whole gland mask:      {df['has_whole_gland_mask'].sum()}")
print(f"  ├─ 与 T2W 完全对齐:          {df['gland_t2w_all_ok'].sum()}")
print(f"  └─ 未完全对齐:               {(~df['gland_t2w_all_ok']).sum()}")

print(f"\n  标签冲突已清除:              {anomaly_count} 例")
print(f"{'=' * 65}")

# ISUP分布
print("\n📊 ISUP分级分布:")
isup_counts = df["isup_grade"].value_counts().sort_index()

for grade, cnt in isup_counts.items():
    has_mask = int(((df["isup_grade"] == grade) & df["has_valid_human_mask"]).sum())
    bar = "█" * (cnt // 10)
    print(f"   ISUP {grade}: {cnt:4d}例  有病灶mask: {has_mask:3d}  {bar}")

pos = (df["cspca_label"] == 1).sum()

print(f"\n📊 csPCa 阳性率:              {pos}/{len(df)} = {pos / len(df) * 100:.1f}%")
print(f"📊 有效病灶mask率:            {df['has_valid_human_mask'].sum()}/{len(df)} = {df['has_valid_human_mask'].sum() / len(df) * 100:.1f}%")
print(f"📊 有效whole gland mask率:    {df['has_whole_gland_mask'].sum()}/{len(df)} = {df['has_whole_gland_mask'].sum() / len(df) * 100:.1f}%")
print(f"📊 gland与T2W对齐率:          {df['gland_t2w_all_ok'].sum()}/{len(df)} = {df['gland_t2w_all_ok'].sum() / len(df) * 100:.1f}%")

# 输出未对齐病例，方便检查
bad_gland = df[(df["has_whole_gland_mask"] == True) & (df["gland_t2w_all_ok"] == False)]

if len(bad_gland) > 0:
    print("\n⚠️  whole gland mask 未与 T2W 完全对齐的病例:")
    print(bad_gland[[
        "patient_id",
        "study_id",
        "whole_gland_mask_path",
    ]].head(30).to_string(index=False))

print(f"\n💾 已保存: {out_path}")
