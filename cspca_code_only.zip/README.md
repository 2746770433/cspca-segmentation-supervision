# Segmentation-supervised multitask MRI classification of csPCa

Code accompanying a manuscript prepared for submission to 《计算机应用研究》. The repository contains preprocessing, training, and evaluation scripts for the classification-only, segmentation-supervised multitask (MTL), and MTL+Focal configurations. The corresponding author is Zhong Jin, Hefei Normal University.

## Scope of this public code release

This release contains source code and configuration templates. It does **not** contain MRI images, lesion masks, patient-level predictions, patient split tables, training logs, or model weights. Those files must not be inferred from the scripts. The manuscript's locally prepared code attachment contains the study's fixed split tables and historical predictions for editorial review; it is separate from this public code-only release.

PI-CAI data must be obtained from its official source and used under the data provider's terms; see `THIRD_PARTY_DATA.md`. To rerun the analysis exactly, the fixed study splits and original model weights are also required. The weights are not currently distributed here, so this repository alone does not reproduce historical checkpoint inference.

## Environment and usage

The original server environment used Python 3.10.9, PyTorch 2.5.1+cu121, CUDA 12.1, NumPy 1.26.4, SciPy 1.11.4, and SimpleITK 2.2.1 on an NVIDIA A100 80 GB PCIe. Install compatible packages listed in `requirements.txt` in a separate environment.

Set the PI-CAI project root in `configs/settings.json` (`data_root`) and provide the required data, split tables, and weights in the paths documented by `settings.py` and `weights/README.md`. Use `python run.py check` to inspect local prerequisites. `python run.py train --dry-run` prints the training plan without starting training. See `run.py --help` for task entry points.

The three main configurations share the same patient split, preprocessing, backbone, and segmentation-pretrained initialization. The repository preserves the original model and training implementations; no performance claim is made from the absence of the non-public artifacts above.

## Citation

Please cite the associated manuscript once bibliographic details are available. No license is granted for the PI-CAI data or third-party material by this repository.
