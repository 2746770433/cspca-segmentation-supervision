"""Check package structure; --smoke also loads and exercises original trainers."""
import argparse,ast,hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
from settings import ROOT,MODELS,checkpoint,data_root,environment

def main():
    p=argparse.ArgumentParser();p.add_argument('--smoke',action='store_true');a=p.parse_args()
    files=list(ROOT.rglob('*.py'))
    for f in files:ast.parse(f.read_text(encoding='utf-8-sig'),filename=str(f))
    for model in MODELS:
        for seed in (42,7,2026):
            path=ROOT/'results/runs'/model/f'seed_{seed}/test/test_predictions.csv'
            if not path.is_file():raise FileNotFoundError(path)
    for fn in ('train_mul.xlsx','val_mul.xlsx','test.xlsx'):
        if not (ROOT/'configs/splits'/fn).is_file():raise FileNotFoundError(fn)
    dependencies={n:importlib.util.find_spec(n) is not None for n in ['torch','numpy','pandas','scipy','sklearn','nibabel','SimpleITK','matplotlib','openpyxl','tqdm']}
    weights=[str(ROOT/'weights/pretraining/best_model.pth')]+[str(checkpoint(m,s)) for m in MODELS for s in (42,7,2026)]
    report=dict(python=sys.version,data_root=str(data_root()),python_files=len(files),syntax_passed=True,dependencies=dependencies,weights_pending=[w for w in weights if not Path(w).is_file()])
    out=ROOT/'results/verification';out.mkdir(parents=True,exist_ok=True)
    if a.smoke:
        missing=[k for k,v in dependencies.items() if not v and k!='SimpleITK']
        if missing:raise RuntimeError('Install required runtime packages: '+', '.join(missing))
        for model in ('pretraining','classification','mtl','mtl_focal'):
            subprocess.run([sys.executable,str(ROOT/'evaluation/smoke.py'),model],cwd=ROOT,env=environment(),check=True)
        subprocess.run([sys.executable,str(ROOT/'evaluation/inference_smoke.py')],cwd=ROOT,env=environment(),check=True)
        report['model_smoke_passed']=True
    (out/'package_check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if not all(dependencies.values()):print('Missing dependencies are listed above; SimpleITK is needed for preprocessing.')

if __name__=='__main__':main()
