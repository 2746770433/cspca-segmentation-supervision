"""Summarize seed-42 reference results and new multi-seed test outputs."""

from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
EXISTING_SEED42 = {
    "classification": ROOT / "test" / "single_task_classification" / "test_summary.md",
    "mtl": ROOT / "test" / "initial_multitask_192_tpr" / "test_summary.md",
    "mtl_focal": ROOT / "test" / "focal_multitask_192_tpr" / "test_summary.md",
}
LABELS = {
    "classification": "Classification baseline",
    "mtl": "MTL",
    "mtl_focal": "MTL+Focal",
}


def parse_summary(path: Path) -> dict:
    text = path.read_text(encoding="utf-8", errors="ignore")
    values = {}
    for metric in ("AUC", "TPR", "FPR", "Dice"):
        match = re.search(
            rf"\|\s*{metric}\s*\|\s*([0-9.]+|nan|not applicable)",
            text,
            flags=re.IGNORECASE,
        )
        if match:
            raw = match.group(1).lower()
            values[metric.lower()] = (
                float(raw) if raw not in {"nan", "not applicable"} else np.nan
            )
    if not {"auc", "tpr", "fpr"}.issubset(values):
        raise RuntimeError(f"Unable to parse required metrics from {path}")
    values.setdefault("dice", np.nan)
    return values


def format_mean_sd(values: list[float]) -> str:
    array = np.asarray(values, dtype=float)
    array = array[~np.isnan(array)]
    if not len(array):
        return "-"
    if len(array) == 1:
        return f"{array[0]:.4f}"
    return (
        f"{array.mean():.4f} ± {array.std(ddof=1):.4f} "
        f"({array.min():.4f}-{array.max():.4f})"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--root",
        type=Path,
        default=ROOT / "results" / "runs",
    )
    parser.add_argument(
        "--seeds",
        nargs="+",
        type=int,
        default=[42, 7, 2026],
    )
    args = parser.parse_args()
    output_dir = args.root / "summary"
    output_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    for experiment in LABELS:
        for seed in args.seeds:
            if seed == 42:
                refreshed_seed42 = (
                    args.root
                    / experiment
                    / "seed_42"
                    / "test"
                    / "test_summary.md"
                )
                if refreshed_seed42.exists():
                    summary_path = refreshed_seed42
                elif experiment in EXISTING_SEED42:
                    summary_path = EXISTING_SEED42[experiment]
                else:
                    summary_path = refreshed_seed42
            else:
                summary_path = (
                    args.root
                    / experiment
                    / f"seed_{seed}"
                    / "test"
                    / "test_summary.md"
                )
            if not summary_path.exists():
                raise FileNotFoundError(summary_path)
            metrics = parse_summary(summary_path)
            if experiment in {"classification", "classification_scratch"}:
                metrics["dice"] = np.nan
            rows.append(
                {
                    "experiment": experiment,
                    "model": LABELS[experiment],
                    "seed": seed,
                    **metrics,
                    "summary_path": str(summary_path),
                }
            )

    with (output_dir / "per_seed_test_metrics.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    report = [
        "# 多随机种子独立测试结果",
        "",
        f"种子：{', '.join(map(str, args.seeds))}",
        "",
        "| 模型 | AUC，均值 ± SD（范围） | TPR，均值 ± SD（范围） | FPR，均值 ± SD（范围） | Dice，均值 ± SD（范围） |",
        "|---|---|---|---|---|",
    ]
    aggregate_rows = []
    for experiment, label in LABELS.items():
        selected = [row for row in rows if row["experiment"] == experiment]
        aggregate = {
            "experiment": experiment,
            "model": label,
            "n_seeds": len(selected),
        }
        for metric in ("auc", "tpr", "fpr", "dice"):
            values = [row[metric] for row in selected]
            valid = np.asarray(values, dtype=float)
            valid = valid[~np.isnan(valid)]
            aggregate[f"{metric}_mean"] = (
                float(valid.mean()) if len(valid) else np.nan
            )
            aggregate[f"{metric}_sd"] = (
                float(valid.std(ddof=1)) if len(valid) > 1 else np.nan
            )
            aggregate[f"{metric}_min"] = (
                float(valid.min()) if len(valid) else np.nan
            )
            aggregate[f"{metric}_max"] = (
                float(valid.max()) if len(valid) else np.nan
            )
        aggregate_rows.append(aggregate)
        report.append(
            f"| {label} | {format_mean_sd([row['auc'] for row in selected])} | "
            f"{format_mean_sd([row['tpr'] for row in selected])} | "
            f"{format_mean_sd([row['fpr'] for row in selected])} | "
            f"{format_mean_sd([row['dice'] for row in selected])} |"
        )
    report.extend(
        [
            "",
            "说明：所有列出的配置均使用种子42、7和2026独立训练，并由统一测试器评价。",
            "SD反映训练初始化与随机增强造成的种子间波动，不是患者抽样置信区间。",
        ]
    )
    (output_dir / "multiseed_report_CN.md").write_text(
        "\n".join(report) + "\n", encoding="utf-8"
    )
    with (output_dir / "aggregate_test_metrics.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=list(aggregate_rows[0]))
        writer.writeheader()
        writer.writerows(aggregate_rows)
    print("\n".join(report))


if __name__ == "__main__":
    main()
