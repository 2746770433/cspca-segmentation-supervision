from pathlib import Path
import json, urllib.request, hashlib, re, sys, math
import numpy as np
import pandas as pd
from types import SimpleNamespace
def binomtest(k,n):
    pval=min(1.,2*sum(math.comb(n,j) for j in range(min(k,n-k)+1))/2**n)
    def ci():
        def cdf(x,end):return sum(math.comb(n,j)*x**j*(1-x)**(n-j) for j in range(end+1))
        def inverse(end,target):
            lo,hi=0.,1.
            for _ in range(65):
                mid=(lo+hi)/2
                if cdf(mid,end)>target:lo=mid
                else:hi=mid
            return (lo+hi)/2
        return SimpleNamespace(low=0. if k==0 else inverse(k-1,.975),high=1. if k==n else inverse(k,.025))
    return SimpleNamespace(pvalue=pval,proportion_ci=ci)
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"results/analysis/clinical"
OUT.mkdir(parents=True,exist_ok=True)
RUN=ROOT/'results/runs'
SCR=ROOT/'results/runs/mtl_scratch'
SEEDS=[42,7,2026]
def fetch(url):
    return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Research-reproducibility-audit'}),timeout=40).read()
if not (ROOT/'configs/official_marksheet.csv').exists():
    meta=json.loads(fetch('https://api.github.com/repos/DIAGNijmegen/picai_labels/commits/main'))
    sha=meta['sha']
    raw=fetch(f'https://raw.githubusercontent.com/DIAGNijmegen/picai_labels/{sha}/clinical_information/marksheet.csv')
    (ROOT/'configs/official_marksheet.csv').write_bytes(raw)
    (ROOT/'configs/official_source.json').write_text(json.dumps({'commit':sha,'retrieval_date':'2026-10-12','url':f'https://raw.githubusercontent.com/DIAGNijmegen/picai_labels/{sha}/clinical_information/marksheet.csv','sha256':hashlib.sha256(raw).hexdigest()},indent=2),encoding='utf-8')
official=pd.read_csv(ROOT/'configs/official_marksheet.csv',keep_default_na=False).set_index(['patient_id','study_id'])
assert official.index.is_unique
def load(path):
    f=pd.read_csv(path).set_index(['patient_id','study_id']).sort_index()
    assert f.index.is_unique and len(f)==148 and f.label.sum()==42
    assert np.array_equal(f.prediction, (f.probability>=.5).astype(int))
    return f
ref=load(RUN/'mtl/seed_42/test/test_predictions.csv')
clinical=official.loc[ref.index].copy()
assert np.array_equal(clinical.case_csPCa.eq('YES').astype(int),ref.label)
def pirads(s):
    vals=[int(x.strip()) for x in s.split(',') if x.strip() in ['1','2','3','4','5']]
    return max(vals) if vals else np.nan
clinical['max_pirads']=clinical.lesion_PIRADS.map(pirads)
clinical['group']=clinical.max_pirads.map(lambda x:'不可分级' if pd.isna(x) else ('1–2' if x<=2 else str(int(x))))
clinical['label']=ref.label
records=[]
for m in ['classification','mtl','mtl_focal']:
    for seed in SEEDS:
        f=load(RUN/f'{m}/seed_{seed}/test/test_predictions.csv')
        assert f.index.equals(ref.index) and f.label.equals(ref.label)
        for group in ['1–2','3','4','5','不可分级']:
            mask=clinical.group.eq(group)
            for label,metric in [(1,'TPR'),(0,'FPR')]:
                a=f.loc[mask & f.label.eq(label),'prediction']; n=len(a); k=int(a.sum())
                ci=binomtest(k,n).proportion_ci() if n else None
                records.append(dict(model=m,seed=seed,group=group,metric=metric,n=n,k=k,value=k/n if n else np.nan,ci_low=ci.low if ci else np.nan,ci_high=ci.high if ci else np.nan))
ps=pd.DataFrame(records)
ps.to_csv(OUT/'pirads_per_seed.csv',index=False)
agg=ps.groupby(['group','metric','model'],sort=False).agg(n=('n','first'),mean=('value','mean'),sd=('value','std')).reset_index()
agg.to_csv(OUT/'pirads_summary.csv',index=False)
clinical.reset_index().to_csv(OUT/'clinical_matched.csv',index=False)
profiles=[]
for m in ['classification','mtl','mtl_focal']:
    pred=np.stack([load(RUN/f'{m}/seed_{seed}/test/test_predictions.csv').prediction.to_numpy() for seed in SEEDS])
    recurrence=pred.sum(0)
    for category,repeat in [('三次均假阳性',3),('三次均真阴性',0)]:
        f=clinical.loc[(ref.label.eq(0)) & (recurrence==repeat)]
        row=dict(model=m,group=category,n=len(f),with_histopath=int(f.histopath_type.ne('').sum()),pirads_ge4=int(f.max_pirads.ge(4).sum()))
        for k in ['psa','psad','prostate_volume']:
            v=pd.to_numeric(f[k],errors='coerce').dropna()
            row[k+'_n']=len(v);row[k+'_median']=v.median();row[k+'_q1']=v.quantile(.25);row[k+'_q3']=v.quantile(.75)
        profiles.append(row)
pd.DataFrame(profiles).to_csv(OUT/'fp_persistent_profiles.csv',index=False)

base=pd.read_csv(ROOT/'results/analysis/initialization/per_seed_metrics.csv')
pairs=pd.read_csv(ROOT/'results/analysis/initialization/paired_comparisons.csv')
result=[];audit=[]
sys.path.insert(0,str(ROOT/'evaluation'))
from delong_three_models import delong_for_models,pairwise_result
for seed in SEEDS:
    a=load(RUN/f'mtl/seed_{seed}/test/test_predictions.csv')
    path=SCR/f'seed_{seed}/test/test_predictions.csv'
    b=load(path) if path.exists() else None
    if b is not None:
        assert a.index.equals(b.index) and a.label.equals(b.label)
        auc,cov=delong_for_models(a.label.to_numpy(),np.stack([a.probability,b.probability]))
        dl=pairwise_result(1,0,['pretrained','scratch'],auc,cov)
        r=pairs[(pairs.seed==seed)&pairs.metric.eq('auc')].iloc[0]
        assert abs(dl['auc_difference_a_minus_b']-r.difference)<1e-12
        assert abs(dl['p_value_two_sided']-r.p)<1e-10
        audit.append(f'seed {seed}: AUC差值、p值与患者级预测复算一致')
    for metric,label,n in [('tpr',1,42),('fpr',0,106)]:
        r=pairs[(pairs.seed==seed)&pairs.metric.eq(metric)].iloc[0]
        pa=float(base[(base.seed==seed)&base.model.eq('mtl_pretrained')][metric].iloc[0])
        pb=float(base[(base.seed==seed)&base.model.eq('mtl_scratch')][metric].iloc[0])
        g,l=int(r.gain),int(r.loss)
        both=round(pa*n)-l
        counts=np.array([n-both-g-l,g,l,both],int) # (pre,scratch): 00,01,10,11
        assert min(counts)>=0 and counts.sum()==n and both+g==round(pb*n)
        assert abs((g-l)/n-r.difference)<1e-12
        assert abs(binomtest(g,g+l).pvalue-r.p)<1e-12
        if b is not None:
            aa=a.loc[a.label.eq(label),'prediction'].to_numpy();bb=b.loc[b.label.eq(label),'prediction'].to_numpy()
            actual=np.bincount(2*aa+bb,minlength=4)
            assert np.array_equal(actual,counts)
        # Parametric multinomial on empirical four-cell probabilities is exactly
        # the count distribution of nonparametric paired-patient bootstrap.
        rng=np.random.default_rng(20261012+seed+label)
        boot=rng.multinomial(n,counts/n,size=20000)
        xa=(boot[:,2]+boot[:,3])/n;xb=(boot[:,1]+boot[:,3])/n
        dif=xb-xa; h=2*(np.arcsin(np.sqrt(xb))-np.arcsin(np.sqrt(xa)))
        dl,du=np.quantile(dif,[.025,.975]);hl,hu=np.quantile(h,[.025,.975])
        result.append(dict(seed=seed,metric=metric.upper(),n=n,n00=int(counts[0]),n01=g,n10=l,n11=int(counts[3]),difference=pb-pa,ci_low=dl,ci_high=du,h=2*(math.asin(math.sqrt(pb))-math.asin(math.sqrt(pa))),h_low=hl,h_high=hu,p=r.p))
pd.DataFrame(result).to_csv(OUT/'initialization_effects.csv',index=False)

# Read original logs, never equate file modification times with training times.
timings=[]
for p in RUN.glob('*/seed_*/train_and_test.log'):
    s=p.read_text(encoding='utf-8',errors='replace');epochs={}
    for e,total,elapsed in re.findall(r'Epoch\s+(\d+)/(\d+):\s*100%[^\r\n]*?295/295\s*\[([\d:]+)<',s):
        units=list(map(int,elapsed.split(':')));seconds=sum(v*60**i for i,v in enumerate(units[::-1]));epochs.setdefault(int(e),[]).append(seconds)
    complete=set(epochs)==set(range(1,101))
    timings.append(dict(model=p.parent.parent.name,seed=int(p.parent.name.split('_')[-1]),epochs=len(epochs),complete=complete,train_loop_hours=sum(max(v) for v in epochs.values())/3600 if complete else None))
pd.DataFrame(timings).to_csv(OUT/'training_loop_times.csv',index=False)
manifest={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in list(RUN.glob('*/seed_*/test/test_predictions.csv'))+[ROOT/'results/analysis/initialization/per_seed_metrics.csv',ROOT/'results/analysis/initialization/paired_comparisons.csv']}
(OUT/'source_hashes.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(OUT/'analysis_audit.json').write_text(json.dumps({'checks':audit,'matched':len(clinical),'label_agreement':True,'pirads_counts':clinical.groupby(['group','label']).size().to_dict().__str__(),'missing_scratch_predictions':[s for s in SEEDS if not (SCR/f'seed_{s}/test/test_predictions.csv').exists()]},ensure_ascii=False,indent=2),encoding='utf-8')
print('PI-RADS counts:',clinical.groupby(['group','label']).size().to_string())
print(agg.to_string(index=False));print(pd.DataFrame(result).to_string(index=False));print(pd.DataFrame(timings).to_string(index=False))
print(pd.DataFrame(profiles).to_string(index=False))
