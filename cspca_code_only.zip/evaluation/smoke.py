"""Isolated original-trainer import, FP32 forward/backward and state-dict round trip."""
import importlib,json,sys,tempfile
from pathlib import Path
import torch
from settings import ROOT,data_root

def main():
    name=sys.argv[1];branch=ROOT/'training'/name
    sys.path.insert(0,str(ROOT/'training'));sys.path.insert(0,str(branch))
    from run_multiseed import load_training_module,install_project_path_remapping
    script='train_dan.py' if name=='classification' else 'train.py'
    trainer=load_training_module(branch/script,'0')
    install_project_path_remapping(trainer,ROOT)
    torch.set_num_threads(2);torch.manual_seed(42)
    if name=='pretraining':
        model=trainer.UNet3D(in_channels=3,out_channels=1,base_channels=32)
        criterion=trainer.WeightedBCEDiceLoss().to('cpu')
    else:
        model=trainer.MultiTaskUNet3D(in_channels=3,out_channels=1,base_channels=32,backbone='3dunet')
        criterion=(trainer.SingleTaskClsLoss() if name=='classification' else trainer.MultiTaskLoss()).to('cpu')
    model.to('cpu').eval()
    x=torch.randn(1,3,16,32,32)
    target=torch.zeros(1,1,16,32,32);target[:,:,5:9,8:15,8:15]=1
    prediction=model(x)
    if name=='pretraining':loss=criterion(prediction,target)[0]
    else:
        seg,cls=prediction
        assert tuple(seg.shape)==tuple(target.shape) and tuple(cls.shape)==(1,1)
        loss=criterion(cls,torch.ones(1,1)) if name=='classification' else criterion(seg,target,cls,torch.ones(1,1),torch.ones(1,1))[0]
    assert torch.isfinite(loss)
    loss.backward()
    assert any(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
    # Exercise the exact original checkpoint loader without needing scientific weights.
    with tempfile.TemporaryDirectory() as tmp:
        path=Path(tmp)/'synthetic_checkpoint.pth';torch.save({'model_state_dict':model.state_dict()},path)
        if name!='pretraining':
            sys.path.insert(0,str(ROOT/'evaluation'))
            from test_model import _load_checkpoint
            _,state=_load_checkpoint(path,'cpu');model.load_state_dict(state,strict=True)
    report=dict(model=name,device='cpu',input=list(x.shape),parameters=sum(p.numel() for p in model.parameters()),finite_loss=float(loss.detach()),forward=True,backward=True,checkpoint_round_trip=True)
    out=ROOT/'results/verification';out.mkdir(parents=True,exist_ok=True)
    (out/f'smoke_{name}.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report))

if __name__=='__main__':main()
