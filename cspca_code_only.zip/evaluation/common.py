from __future__ import annotations

import math
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd


MODELS = ("classification", "mtl", "mtl_focal")
OPTIONAL_MODELS = ("classification_scratch",)
MODEL_LABELS = {
    "classification": "Classification",
    "classification_scratch": "Classification (random initialization)",
    "mtl": "MTL",
    "mtl_focal": "MTL+Focal",
}
SEEDS = (42, 7, 2026)
CHECKPOINT_NAMES = {
    "classification": "best_cls_model.pth",
    "classification_scratch": "best_cls_model.pth",
    "mtl": "best_multitask_model.pth",
    "mtl_focal": "best_multitask_model.pth",
}
PATH_COLUMNS = (
    "t2w_path",
    "adc_path",
    "hbv_path",
    "mask_path_human",
    "mask_path_ai",
    "whole_gland_mask_path",
)


def default_project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def default_run_root(project_root: Path) -> Path:
    return project_root / "results" / "runs"


def is_complete_run_root(run_root: Path) -> bool:
    return all(path.is_file() for path in required_prediction_paths(run_root).values())


def discover_run_root(project_root: Path, supplied: Path | None = None) -> Path:
    """Locate a complete 3-model x 3-seed prediction tree without using discarded runs."""
    if supplied is not None:
        return supplied.resolve()

    preferred = (
        default_run_root(project_root),
        project_root / "multiseed_runs_full100",
        project_root / "training_branches" / "runs",
    )
    for candidate in preferred:
        if is_complete_run_root(candidate):
            print(f"Auto-detected formal run root: {candidate}")
            return candidate

    excluded_tokens = {
        "strict_ablation_rerun",
        "checkpoint_score_validation",
        "saved5_tests",
        "submission_priority_experiments",
    }
    candidates = set()
    for prediction in project_root.rglob("test_predictions.csv"):
        if len(prediction.parents) < 4:
            continue
        lowered_parts = {part.lower() for part in prediction.parts}
        if lowered_parts.intersection(excluded_tokens):
            continue
        test_dir = prediction.parent
        seed_dir = test_dir.parent
        model_dir = seed_dir.parent
        if test_dir.name != "test" or model_dir.name not in MODELS or not seed_dir.name.startswith("seed_"):
            continue
        candidates.add(model_dir.parent.resolve())

    complete = sorted((candidate for candidate in candidates if is_complete_run_root(candidate)), key=str)
    if len(complete) == 1:
        print(f"Auto-detected formal run root: {complete[0]}")
        return complete[0]
    if len(complete) > 1:
        joined = "\n  - ".join(str(path) for path in complete)
        raise RuntimeError(
            "Multiple complete run roots were found. Pass --run-root explicitly to avoid mixing results:\n  - " + joined
        )
    return default_run_root(project_root)


def normalize_id(value) -> str:
    if pd.isna(value):
        return ""
    text = str(value).strip()
    if text.endswith(".0"):
        text = text[:-2]
    return text


def remap_project_paths(frame: pd.DataFrame, project_root: Path) -> pd.DataFrame:
    frame = frame.copy()
    for column in PATH_COLUMNS:
        if column not in frame.columns:
            continue

        def remap(value):
            if not isinstance(value, str) or not value.strip():
                return value
            normalized = value.replace("\\", "/")
            marker = normalized.find("/data/")
            if marker < 0:
                return value
            return str(project_root / Path(normalized[marker + 1 :]))

        frame[column] = frame[column].map(remap)
    return frame


def prediction_path(run_root: Path, model: str, seed: int) -> Path:
    return run_root / model / f"seed_{seed}" / "test" / "test_predictions.csv"


def checkpoint_path(run_root: Path, model: str, seed: int = 42) -> Path:
    from settings import checkpoint
    return checkpoint(model, seed)


def required_prediction_paths(run_root: Path) -> Dict[Tuple[str, int], Path]:
    return {
        (model, seed): prediction_path(run_root, model, seed)
        for model in MODELS
        for seed in SEEDS
    }


def assert_files_exist(paths: Iterable[Path], description: str) -> None:
    missing = [str(path) for path in paths if not path.is_file()]
    if missing:
        joined = "\n  - ".join(missing)
        raise FileNotFoundError(f"Missing {description}:\n  - {joined}")


def load_all_predictions(run_root: Path) -> pd.DataFrame:
    paths = required_prediction_paths(run_root)
    assert_files_exist(paths.values(), "test prediction files")

    for model in OPTIONAL_MODELS:
        optional = {
            (model, seed): prediction_path(run_root, model, seed)
            for seed in SEEDS
        }
        present = [path.is_file() for path in optional.values()]
        if any(present) and not all(present):
            assert_files_exist(optional.values(), f"complete optional prediction series for {model}")
        if all(present):
            paths.update(optional)

    frames = []
    reference = None
    required = {"patient_id", "study_id", "label", "probability"}
    for (model, seed), path in paths.items():
        frame = pd.read_csv(path)
        absent = required.difference(frame.columns)
        if absent:
            raise ValueError(f"{path} is missing columns: {sorted(absent)}")
        frame = frame.copy()
        frame["patient_id"] = frame["patient_id"].map(normalize_id)
        frame["study_id"] = frame["study_id"].map(normalize_id)
        frame["label"] = frame["label"].astype(int)
        frame["probability"] = frame["probability"].astype(float)
        if frame[["patient_id", "study_id"]].duplicated().any():
            raise ValueError(f"Duplicate patient-study pairs in {path}")
        if not frame["probability"].between(0.0, 1.0).all():
            raise ValueError(f"Probabilities outside [0, 1] in {path}")
        keys = frame[["patient_id", "study_id", "label"]].sort_values(
            ["patient_id", "study_id"]
        ).reset_index(drop=True)
        if reference is None:
            reference = keys
        elif not keys.equals(reference):
            raise ValueError(f"Patient set or labels differ in {path}")
        frame["model"] = model
        frame["seed"] = int(seed)
        frames.append(frame[["patient_id", "study_id", "label", "probability", "model", "seed"]])
    return pd.concat(frames, ignore_index=True)


def wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> Tuple[float, float]:
    if total <= 0:
        return math.nan, math.nan
    p = successes / total
    denominator = 1.0 + z * z / total
    center = (p + z * z / (2.0 * total)) / denominator
    half = z * math.sqrt(p * (1.0 - p) / total + z * z / (4.0 * total * total)) / denominator
    return max(0.0, center - half), min(1.0, center + half)


def stratified_auc_ci(y_true, y_prob, n_boot: int, seed: int) -> Tuple[float, float]:
    y_true = np.asarray(y_true, dtype=int)
    y_prob = np.asarray(y_prob, dtype=float)
    positive = np.flatnonzero(y_true == 1)
    negative = np.flatnonzero(y_true == 0)
    if len(positive) == 0 or len(negative) == 0 or n_boot <= 0:
        return math.nan, math.nan
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(n_boot):
        indices = np.concatenate(
            [rng.choice(positive, len(positive), replace=True), rng.choice(negative, len(negative), replace=True)]
        )
        values.append(binary_auc(y_true[indices], y_prob[indices]))
    return float(np.percentile(values, 2.5)), float(np.percentile(values, 97.5))


def binary_auc(y_true, y_prob) -> float:
    """Exact binary AUC using pairwise concordance; ties contribute one half."""
    y_true = np.asarray(y_true, dtype=int)
    y_prob = np.asarray(y_prob, dtype=float)
    positive = y_prob[y_true == 1]
    negative = y_prob[y_true == 0]
    if len(positive) == 0 or len(negative) == 0:
        return math.nan
    comparison = positive[:, None] - negative[None, :]
    return float((np.count_nonzero(comparison > 0) + 0.5 * np.count_nonzero(comparison == 0)) / comparison.size)
