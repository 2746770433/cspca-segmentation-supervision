"""Recompute the paper's existing-results statistics without changing source files.

Default: NumPy-only analysis, CSVs, review report and manuscript replacement plan.
--plot-check: independent SciPy/sklearn/statsmodels checks and Matplotlib figures.
All artifacts stay beside this script. No training or checkpoint inference is run.
"""
from pathlib import Path
import csv
import hashlib
import itertools
import json
import math
import re
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "results/runs"
OUT = ROOT / "results/analysis/main"
OUT.mkdir(parents=True, exist_ok=True)
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / "evaluation"))
from delong_three_models import delong_for_models, pairwise_result

MODELS = ("classification", "mtl", "mtl_focal")
NAMES = ("分类基线", "MTL", "MTL+Focal")
EN = ("Classification baseline", "MTL", "MTL+Focal")
SEEDS = (42, 7, 2026)
REPS = 20000
BOOT_SEED = 20261011
THRESHOLDS = np.round(np.arange(.05, .501, .01), 2)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_csv(name, rows):
    assert rows, name
    with (OUT / name).open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def dump(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def logistic_fit(x, y, offset=None):
    beta = np.zeros(x.shape[1])
    offset = np.zeros(len(y)) if offset is None else offset
    for _ in range(100):
        eta = np.clip(x @ beta + offset, -700, 700)
        p = 1 / (1 + np.exp(-eta))
        step = np.linalg.solve(x.T @ ((p * (1-p))[:, None] * x), x.T @ (y-p))
        beta += step
        if np.max(np.abs(step)) < 1e-10:
            assert np.max(np.abs(x.T @ (y - 1/(1+np.exp(-(x @ beta + offset)))))) < 1e-7
            return beta
    raise RuntimeError("Calibration regression did not converge")


def exact_mcnemar(a, b):
    gain = int(np.sum(~a & b))
    loss = int(np.sum(a & ~b))
    n = gain + loss
    pv = min(1., 2 * sum(math.comb(n, k) for k in range(min(gain, loss)+1)) / 2**n) if n else 1.
    return gain, loss, pv


def h_effect(p1, p0):
    return 2 * (np.arcsin(np.sqrt(p1)) - np.arcsin(np.sqrt(p0)))


def ci(values):
    return np.quantile(values, [.025, .975], method="linear")


def mean_sd(v, digits=4):
    v = np.asarray(v)
    return f"{v.mean():.{digits}f} ± {v.std(ddof=1):.{digits}f}"


def interval_text(mask):
    parts = []
    for _, group in itertools.groupby(enumerate(np.flatnonzero(mask)), lambda z: z[1]-z[0]):
        ix = [int(z[1]) for z in group]
        lo, hi = THRESHOLDS[ix[0]], THRESHOLDS[ix[-1]]
        parts.append(f"{lo:.2f}～{hi:.2f}" if lo != hi else f"{lo:.2f}")
    return "、".join(parts) or "无"


def markdown_table(headers, rows):
    return "\n".join(["| " + " | ".join(headers) + " |", "|" + "---|"*len(headers)] +
                     ["| " + " | ".join(map(str, row)) + " |" for row in rows])


def read_sources():
    probabilities = np.zeros((3, 3, 148))
    dice = np.full((2, 3, 26), np.nan)
    histories = np.full((3, 3, 100, 6), np.nan)
    records, manifest, validation, selected, perturbations = [], [], [], [], []
    reference, reference_dice, labels = None, None, None
    for mi, model in enumerate(MODELS):
        for si, seed in enumerate(SEEDS):
            folder = RUN / model / f"seed_{seed}"
            paths = [folder/"test/test_predictions.csv", folder/"test/test_summary.json", folder/"train_and_test.log", folder/"run_config.json"]
            for path in paths:
                manifest.append(dict(path=str(path), size=path.stat().st_size, sha256=digest(path)))
            rows = sorted(read_csv(paths[0]), key=lambda r: (r["patient_id"], r["study_id"]))
            keys = [(r["patient_id"], r["study_id"]) for r in rows]
            y = np.array([int(r["label"]) for r in rows])
            p = np.array([float(r["probability"]) for r in rows])
            if reference is None:
                reference, labels = keys, y
            assert keys == reference and np.array_equal(y, labels)
            assert len(set(k[0] for k in keys)) == len(keys) == 148 and y.sum() == 42
            assert np.isfinite(p).all() and ((p >= 0) & (p <= 1)).all()
            pred = p >= .5
            assert np.array_equal(pred, [int(r["prediction"]) for r in rows])
            probabilities[mi, si] = p
            drows = [r for r in rows if r["dice"] and r["dice"].lower() != "nan"]
            if mi:
                dkeys = [(r["patient_id"], r["study_id"]) for r in drows]
                if reference_dice is None:
                    reference_dice = dkeys
                assert dkeys == reference_dice and len(dkeys) == 26
                assert all(int(r["label"]) == 1 and r["has_valid_mask"].lower() in ("1", "true") for r in drows)
                dice[mi-1, si] = [float(r["dice"]) for r in drows]
                assert ((dice[mi-1, si] >= 0) & (dice[mi-1, si] <= 1)).all()
            else:
                assert not drows
            summary = json.loads(paths[1].read_text(encoding="utf-8"))
            aucs, cov = delong_for_models(y, np.stack([p, p]))
            vals = dict(model=model, seed=seed, epoch=summary["checkpoint_epoch"],
                        auc=float(aucs[0]), tpr=float(pred[y==1].mean()), fpr=float(pred[y==0].mean()),
                        accuracy=float((pred == y).mean()), dice=float(dice[mi-1, si].mean()) if mi else None,
                        tp=int(np.sum(pred & (y==1))), fp=int(np.sum(pred & (y==0))),
                        tn=int(np.sum(~pred & (y==0))), fn=int(np.sum(~pred & (y==1))),
                        brier=float(np.mean((p-y)**2)))
            vals["ppv"] = vals["tp"] / (vals["tp"]+vals["fp"])
            for key in ("auc", "tpr", "fpr", "tp", "fp", "tn", "fn"):
                assert abs(vals[key]-summary[key]) < 1e-12, (model, seed, key)
            assert summary["classification_threshold"] == .5 and summary["segmentation_threshold"] == .45
            assert summary["n_cases"] == 148 and summary["n_valid_masks"] == len(drows)
            if mi:
                assert abs(vals["dice"]-summary["dice"]) < 1e-12
            pc = np.clip(p, 1e-6, 1-1e-6)
            logit = np.log(pc/(1-pc))
            vals["calibration_intercept"] = float(logistic_fit(np.ones((148, 1)), y, logit)[0])
            vals["calibration_slope"] = float(logistic_fit(np.column_stack([np.ones(148), logit]), y)[1])
            records.append(vals)
            log = paths[2].read_text(encoding="utf-8", errors="replace")
            hist = []
            for line in log.splitlines():
                if "[Epoch" not in line or "Val AUC:" not in line:
                    continue
                def value(label):
                    m = re.search(re.escape(label) + r":\s*([-+0-9.eE]+)", line)
                    return float(m[1]) if m else np.nan
                hist.append([int(re.search(r"\[Epoch\s+(\d+)", line)[1]), value("Val AUC"), value("Val TPR"), value("Val FPR"), value("Val Dice"), value("Score")])
            hist = np.asarray(hist)
            assert hist.shape == (100, 6) and np.array_equal(hist[:, 0], np.arange(1, 101)) and "[DONE]" in log
            histories[mi, si] = hist
            epoch = int(hist[np.argmax(hist[:, 5]), 0])
            assert epoch == vals["epoch"]
            checkpoint = folder / "checkpoints" / Path(summary["checkpoint"]).name
            # Statistical reproduction reads predictions; weight checks are in check.py.
            formula = 2*hist[:, 1] + hist[:, 2] - 1.5*hist[:, 3]
            if mi:
                formula -= 5*np.maximum(0, .55-hist[:, 4])
            assert np.max(np.abs(formula-hist[:, 5])) < .001
            row = dict(model=model, seed=seed, epoch=epoch, auc=hist[epoch-1, 1], tpr=hist[epoch-1, 2], fpr=hist[epoch-1, 3], dice=hist[epoch-1, 4] if mi else None)
            validation.append(row)
            grid = itertools.product((1.5, 2., 2.5), (1., 1.5, 2.), (.5, .55, .6), (2.5, 5., 7.5)) if mi else itertools.product((1.5, 2., 2.5), (1., 1.5, 2.), (0.,), (0.,))
            kept = 0
            fragile = 0
            trials = 0
            for aw, fw, dt, dw in grid:
                score = aw*hist[:, 1] + hist[:, 2] - fw*hist[:, 3]
                if mi:
                    score -= dw*np.maximum(0, dt-hist[:, 4])
                chosen = int(np.argmax(score))
                # Four-decimal log rounding: conservative bound on pairwise score error.
                rounding_bound = 2*.00005*(aw+1+fw+dw)
                margin = np.sort(score)[-1] - np.sort(score)[-2]
                close = margin <= rounding_bound
                kept += chosen+1 == epoch
                fragile += int(close)
                trials += 1
                perturbations.append(dict(model=model, seed=seed, auc_weight=aw, fpr_weight=fw, dice_threshold=dt, dice_penalty=dw, selected_epoch=chosen+1, retained=int(chosen+1==epoch), top_score_margin=float(margin), rounding_sensitive=int(close)))
            ae = int(hist[np.argmax(hist[:, 1]), 0])
            je = int(hist[np.argmax(hist[:, 2]-hist[:, 3]), 0])
            selected.append(dict(model=model, seed=seed, score_epoch=epoch, max_auc_epoch=ae, max_youden_epoch=je,
                                 n_retained=kept, n_settings=trials, retention=kept/trials,
                                 rounding_sensitive_settings=fragile, checkpoint=str(checkpoint)))
    return labels, probabilities, dice, histories, records, validation, selected, perturbations, manifest


def build():
    y, probs, dice, hist, records, validation, selected, perturb, manifest = read_sources()
    rng = np.random.default_rng(BOOT_SEED)
    indices = {n: rng.integers(0, n, size=(REPS, n)) for n in (42, 106, 148, 26)}
    paired = []
    for ai, bi in ((0, 1), (1, 2)):
        for si, seed in enumerate(SEEDS):
            p, q = probs[ai, si], probs[bi, si]
            aucs, cov = delong_for_models(y, np.stack([p, q]))
            u = np.stack([(v[y==1, None] > v[y==0]).astype(float) + .5*(v[y==1, None] == v[y==0]) for v in (p, q)])
            independent_cov = np.cov(u.mean(axis=2))/42 + np.cov(u.mean(axis=1))/106
            assert np.allclose(cov, independent_cov, atol=1e-12) and np.allclose(aucs, u.mean(axis=(1, 2)), atol=1e-12)
            d = pairwise_result(1, 0, [MODELS[ai], MODELS[bi]], aucs, cov)
            common = dict(comparison=f"{MODELS[bi]} - {MODELS[ai]}", seed=seed)
            paired.append(dict(**common, metric="auc", n=148, difference=d["auc_difference_a_minus_b"], ci_lower=d["difference_ci95_lower"], ci_upper=d["difference_ci95_upper"], cohens_h=None, h_ci_lower=None, h_ci_upper=None, p_value=d["p_value_two_sided"], gain=None, loss=None, ci_method="paired DeLong"))
            for metric, mask in (("tpr", y==1), ("fpr", y==0), ("accuracy", np.ones(len(y), dtype=bool))):
                a, b = p[mask] >= .5, q[mask] >= .5
                if metric == "accuracy":
                    a, b = a == y[mask], b == y[mask]
                gain, loss, pv = exact_mcnemar(a, b)
                idx = indices[len(a)]
                ba, bb = a[idx].mean(axis=1), b[idx].mean(axis=1)
                delta = bb-ba
                assert abs((gain-loss)/len(a)-(b.mean()-a.mean())) < 1e-14
                lower, upper = ci(delta)
                hc = ci(h_effect(bb, ba))
                paired.append(dict(**common, metric=metric, n=len(a), difference=float(b.mean()-a.mean()), ci_lower=float(lower), ci_upper=float(upper), cohens_h=float(h_effect(b.mean(), a.mean())) if metric != "accuracy" else None, h_ci_lower=float(hc[0]) if metric != "accuracy" else None, h_ci_upper=float(hc[1]) if metric != "accuracy" else None, p_value=pv, gain=gain, loss=loss, ci_method="paired patient percentile bootstrap (20000)"))
    dice_rows = []
    boot_dice = dice[:, :, indices[26]].mean(axis=-1)
    for mi in range(2):
        for si, seed in enumerate(SEEDS):
            lo, hi = ci(boot_dice[mi, si])
            dice_rows.append(dict(model=MODELS[mi+1], seed=str(seed), n_patients=26, estimate=float(dice[mi, si].mean()), ci_lower=float(lo), ci_upper=float(hi), bootstrap_reps=REPS))
        # Same resampled patients across seeds, not 78 independent observations.
        lo, hi = ci(boot_dice[mi].mean(axis=0))
        assert np.allclose(boot_dice[mi].mean(axis=0), dice[mi].mean(axis=0)[indices[26]].mean(axis=1))
        dice_rows.append(dict(model=MODELS[mi+1], seed="mean_of_three_fixed_seeds", n_patients=26, estimate=float(dice[mi].mean()), ci_lower=float(lo), ci_upper=float(hi), bootstrap_reps=REPS))
    for si, seed in enumerate(SEEDS):
        lo, hi = ci(boot_dice[1, si]-boot_dice[0, si])
        dice_rows.append(dict(model="mtl_focal - mtl", seed=str(seed), n_patients=26, estimate=float((dice[1, si]-dice[0, si]).mean()), ci_lower=float(lo), ci_upper=float(hi), bootstrap_reps=REPS))
    lo, hi = ci((boot_dice[1]-boot_dice[0]).mean(axis=0))
    dice_rows.append(dict(model="mtl_focal - mtl", seed="mean_of_three_fixed_seeds", n_patients=26, estimate=float((dice[1]-dice[0]).mean()), ci_lower=float(lo), ci_upper=float(hi), bootstrap_reps=REPS))
    # Numerical repeatability check with an independent bootstrap stream.
    idx2 = np.random.default_rng(BOOT_SEED+1).integers(0, 26, size=(REPS, 26))
    repeat_delta = max(float(np.max(np.abs(ci(dice[mi].mean(axis=0)[idx2].mean(axis=1)) - ci(boot_dice[mi].mean(axis=0))))) for mi in range(2))
    bins, dca_rows = [], []
    nb = np.zeros((3, 3, len(THRESHOLDS)))
    treat_all = y.mean() - (1-y.mean())*THRESHOLDS/(1-THRESHOLDS)
    for mi, model in enumerate(MODELS):
        for si, seed in enumerate(SEEDS):
            p = probs[mi, si]
            bounds = np.quantile(p, np.linspace(0, 1, 6))
            assert len(np.unique(bounds)) == 6
            categories = np.searchsorted(bounds[1:-1], p, side="left")
            for k in range(5):
                mask = categories == k
                bins.append(dict(model=model, seed=seed, bin=k+1, n=int(mask.sum()), mean_probability=float(p[mask].mean()), observed_fraction=float(y[mask].mean())))
            for ti, t in enumerate(THRESHOLDS):
                pred = p >= t
                tp, fp = int(np.sum(pred & (y==1))), int(np.sum(pred & (y==0)))
                nb[mi, si, ti] = tp/148 - fp/148*t/(1-t)
                dca_rows.append(dict(model=model, seed=seed, threshold=t, tp=tp, fp=fp, net_benefit=nb[mi, si, ti], treat_all=treat_all[ti], treat_none=0.))
    ranges = []
    for mi, model in enumerate(MODELS):
        allbest = np.all(nb[mi] > np.max(np.delete(nb, mi, axis=0), axis=0)+1e-12, axis=0)
        meanbest = nb[mi].mean(axis=0) > np.max(np.delete(nb.mean(axis=1), mi, axis=0), axis=0)+1e-12
        policies = np.all((nb[mi] > treat_all+1e-12) & (nb[mi] > 1e-12), axis=0)
        ranges.append(dict(model=model, strict_best_each_seed=interval_text(allbest), strict_best_mean=interval_text(meanbest), above_both_policies_each_seed=interval_text(policies), both_advantages_each_seed=interval_text(allbest & policies)))
    aggregate = []
    for model in MODELS:
        for metric in ("auc", "tpr", "fpr", "dice", "accuracy", "brier", "calibration_intercept", "calibration_slope", "ppv", "tp", "fp"):
            vals = [r[metric] for r in records if r["model"] == model]
            if vals[0] is None:
                continue
            v = np.array(vals)
            aggregate.append(dict(model=model, metric=metric, mean=float(v.mean()), sample_sd=float(v.std(ddof=1)), minimum=float(v.min()), maximum=float(v.max())))
    write_csv("01_test_metrics_per_seed.csv", records)
    write_csv("02_test_metrics_summary.csv", aggregate)
    write_csv("03_paired_effects_and_ci.csv", paired)
    write_csv("04_dice_patient_bootstrap.csv", dice_rows)
    write_csv("05_selected_validation.csv", validation)
    write_csv("06_checkpoint_selection.csv", selected)
    write_csv("07_checkpoint_perturbations.csv", perturb)
    write_csv("08_calibration_bins.csv", bins)
    write_csv("09_dca_per_seed.csv", dca_rows)
    write_csv("10_dca_ranges.csv", ranges)
    history_rows = [dict(model=MODELS[mi], seed=seed, epoch=int(row[0]), auc=row[1], tpr=row[2], fpr=row[3], dice=row[4] if mi else None, score=row[5]) for mi in range(3) for si, seed in enumerate(SEEDS) for row in hist[mi, si]]
    write_csv("11_validation_history.csv", history_rows)
    np.savez_compressed(OUT/"analysis_arrays.npz", labels=y, probabilities=probs, dice=dice, histories=hist, bootstrap_indices_26=indices[26])
    dump("source_manifest.json", dict(numpy_version=np.__version__, bootstrap_seed=BOOT_SEED, bootstrap_repetitions=REPS, sources=manifest))
    dump("calculation_review.json", dict(n_runs=9, n_epochs_each=100, n_patients=148, n_positive=42, n_negative=106, n_dice=26,
         raw_metrics_match_json=True, delong_independent_covariance_check=True, calibration_score_equations_check=True,
         paired_bootstrap_preserves_patients=True, dice_repeat_bootstrap_max_endpoint_difference=repeat_delta,
         manuscript_changed=False, checkpoint_inference_rerun=False))
    for row in manifest:
        assert digest(Path(row["path"])) == row["sha256"]
    print(f"Analysis complete: {OUT}")
    print("Dice CI (three fixed seeds):", [r for r in dice_rows if r["seed"] == "mean_of_three_fixed_seeds"])


def plot_and_check():
    # Optional scientific libraries used only for missing bundled capabilities.
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from scipy.stats import binomtest
    from sklearn.metrics import roc_auc_score, brier_score_loss
    import statsmodels.api as sm
    import pandas as pd
    data = np.load(OUT/"analysis_arrays.npz")
    y, probs, dice, hist = (data[k] for k in ("labels", "probabilities", "dice", "histories"))
    records = read_csv(OUT/"01_test_metrics_per_seed.csv")
    paired = read_csv(OUT/"03_paired_effects_and_ci.csv")
    bins = read_csv(OUT/"08_calibration_bins.csv")
    for mi, model in enumerate(MODELS):
        for si, seed in enumerate(SEEDS):
            r = next(r for r in records if r["model"] == model and int(r["seed"]) == seed)
            p = probs[mi, si]
            assert abs(roc_auc_score(y, p)-float(r["auc"])) < 1e-12
            assert abs(brier_score_loss(y, p)-float(r["brier"])) < 1e-12
            logit = np.log(np.clip(p, 1e-6, 1-1e-6)/(1-np.clip(p, 1e-6, 1-1e-6)))
            a = sm.GLM(y, np.ones((148, 1)), family=sm.families.Binomial(), offset=logit).fit().params[0]
            b = sm.GLM(y, sm.add_constant(logit), family=sm.families.Binomial()).fit().params[1]
            assert abs(a-float(r["calibration_intercept"])) < 1e-7
            assert abs(b-float(r["calibration_slope"])) < 1e-7
            categories = np.asarray(pd.qcut(p, 5, labels=False))
            for k in range(5):
                br = next(z for z in bins if z["model"] == model and int(z["seed"]) == seed and int(z["bin"]) == k+1)
                assert int(br["n"]) == np.sum(categories==k)
                assert abs(float(br["observed_fraction"])-y[categories==k].mean()) < 1e-12
    for r in paired:
        if r["metric"] == "auc":
            continue
        n = int(r["gain"])+int(r["loss"])
        pv = binomtest(int(r["gain"]), n, .5).pvalue if n else 1.
        assert abs(pv-float(r["p_value"])) < 1e-12
    colors = ("#D97706", "#2E7D32", "#C43C4E")
    styles = ("-", "--", "-.")
    plt.rcParams.update({"font.family": "Arial", "font.size": 10, "axes.titlesize": 11,
                         "axes.labelsize": 10, "legend.fontsize": 9, "pdf.fonttype": 42,
                         "axes.spines.top": False, "axes.spines.right": False})
    def finish(fig, stem):
        fig.savefig(OUT/f"{stem}.png", dpi=300, bbox_inches="tight", facecolor="white")
        fig.savefig(OUT/f"{stem}.pdf", bbox_inches="tight", facecolor="white")
        plt.close(fig)
    fig = plt.figure(figsize=(11.8, 7.4))
    gs = fig.add_gridspec(2, 3, hspace=.39, wspace=.31, top=.89, bottom=.10)
    axs = [fig.add_subplot(gs[0, i]) for i in range(3)] + [fig.add_subplot(gs[1, 0])]
    handles = []
    for k, ax in enumerate(axs):
        for mi in range(3):
            if k == 3 and mi == 0:
                continue
            v = hist[mi, :, :, k+1]
            line, = ax.plot(np.arange(1, 101), v.mean(axis=0), color=colors[mi], linestyle=styles[mi], lw=1.4, label=EN[mi])
            ax.fill_between(np.arange(1, 101), v.min(axis=0), v.max(axis=0), color=colors[mi], alpha=.12, linewidth=0)
            if k == 0:
                handles.append(line)
        ax.set_title(f"{'ABCD'[k]}  Validation {('AUC','TPR','FPR','Dice')[k]}", loc="left", fontweight="bold")
        ax.set_xlabel("Epoch")
        ax.set_ylabel(("AUC", "TPR", "FPR", "Dice")[k])
        ax.set_xlim(1, 100)
        ax.grid(alpha=.18)
        # Entire trajectory retained, including early high TPR/FPR.
        ax.set_ylim(max(0., ax.get_ylim()[0]), min(1.02, ax.get_ylim()[1]))
    ax = fig.add_subplot(gs[1, 1:])
    markers = ("o", "s", "^")
    offsets = ((-15, -48), (55, -42), (-30, 30))
    for mi, model in enumerate(MODELS):
        rr = [r for r in records if r["model"] == model]
        x = np.array([float(r["fpr"]) for r in rr])
        v = np.array([float(r["tpr"]) for r in rr])
        a = np.array([float(r["auc"]) for r in rr])
        ax.errorbar(x.mean(), v.mean(), xerr=x.std(ddof=1), yerr=v.std(ddof=1), fmt=markers[mi], color=colors[mi], capsize=4, ms=7, lw=1.4)
        ax.annotate(f"{EN[mi]}\nAUC {a.mean():.4f} ± {a.std(ddof=1):.4f}", (x.mean(), v.mean()), xytext=offsets[mi], textcoords="offset points", ha="center", color=colors[mi], fontsize=9)
    ax.set(xlabel="Test FPR at threshold 0.5", ylabel="Test TPR at threshold 0.5", xlim=(.10, .225), ylim=(.51, .70))
    ax.set_title("E  Held-out test operating points", loc="left", fontweight="bold")
    ax.grid(alpha=.18)
    fig.legend(handles, EN, loc="upper center", ncol=3, frameon=False, bbox_to_anchor=(.5, .99))
    fig.text(.5, .025, "A–D: mean and range across seeds.  E: mean ± sample SD across seeds (not patient CIs).", ha="center", fontsize=9)
    finish(fig, "figure2_training_and_test")
    fig, axs = plt.subplots(1, 3, figsize=(11.8, 3.9), sharex=True, sharey=True)
    for mi, ax in enumerate(axs):
        xx, yy = [], []
        for seed in SEEDS:
            rr = [r for r in bins if r["model"] == MODELS[mi] and int(r["seed"]) == seed]
            xx.append([float(r["mean_probability"]) for r in rr])
            yy.append([float(r["observed_fraction"]) for r in rr])
        x, v = np.asarray(xx), np.asarray(yy)
        ax.plot([0, 1], [0, 1], color=".5", linestyle=":", lw=1.2)
        xerr = np.stack([x.mean(axis=0)-x.min(axis=0), x.max(axis=0)-x.mean(axis=0)])
        yerr = np.stack([v.mean(axis=0)-v.min(axis=0), v.max(axis=0)-v.mean(axis=0)])
        assert xerr.min() > -1e-14 and yerr.min() > -1e-14
        ax.errorbar(x.mean(axis=0), v.mean(axis=0), xerr=np.maximum(0, xerr), yerr=np.maximum(0, yerr), fmt="o-", color=colors[mi], lw=1.4, capsize=3, ms=4)
        rr = [r for r in records if r["model"] == MODELS[mi]]
        labels = []
        for field, title, digits in (("brier", "Brier", 4), ("calibration_intercept", "Intercept", 3), ("calibration_slope", "Slope", 3)):
            labels.append(f"{title}: {mean_sd([float(r[field]) for r in rr], digits)}")
        ax.text(.045, .955, "\n".join(labels), transform=ax.transAxes, va="top", fontsize=9)
        ax.set_title(f"{'ABC'[mi]}  {EN[mi]}", loc="left", fontweight="bold")
        ax.set(xlim=(0, 1), ylim=(0, 1), xlabel="Mean predicted probability")
        ax.grid(alpha=.18)
    axs[0].set_ylabel("Observed positive fraction")
    fig.subplots_adjust(left=.06, right=.99, top=.88, bottom=.21, wspace=.15)
    fig.text(.5, .035, "Five equal-frequency groups per seed; error bars show seed ranges, not patient CIs.", ha="center", fontsize=9)
    finish(fig, "figure3_calibration")
    fig, ax = plt.subplots(figsize=(7.6, 4.8))
    nb = np.zeros((3, 3, len(THRESHOLDS)))
    saved_dca = read_csv(OUT/"09_dca_per_seed.csv")
    for mi in range(3):
        for si in range(3):
            for ti, t in enumerate(THRESHOLDS):
                pos = probs[mi, si] >= t
                nb[mi, si, ti] = np.mean(pos & (y==1))-np.mean(pos & (y==0))*t/(1-t)
                row = next(r for r in saved_dca if r["model"] == MODELS[mi] and int(r["seed"]) == SEEDS[si] and abs(float(r["threshold"])-t) < 1e-12)
                assert abs(float(row["net_benefit"])-nb[mi, si, ti]) < 1e-12
        ax.plot(THRESHOLDS, nb[mi].mean(axis=0), color=colors[mi], ls=styles[mi], lw=1.8, label=EN[mi])
        ax.fill_between(THRESHOLDS, nb[mi].min(axis=0), nb[mi].max(axis=0), color=colors[mi], alpha=.12, lw=0)
    ax.plot(THRESHOLDS, y.mean()-(1-y.mean())*THRESHOLDS/(1-THRESHOLDS), color=".35", ls=":", lw=1.4, label="Biopsy referral for all")
    ax.axhline(0, color="black", lw=1, ls="--", label="Biopsy referral for none")
    ax.set(xlim=(.05, .50), ylim=(-.05, .28), xlabel="Threshold probability", ylabel="Net benefit")
    ax.grid(alpha=.18)
    ax.legend(frameon=False, loc="upper right", ncol=1, fontsize=9)
    fig.subplots_adjust(bottom=.21, left=.12, right=.98, top=.96)
    fig.text(.53, .04, "Mean and range across seeds; threshold step 0.01.\nThe referral-for-all curve extends below the displayed y-axis.", ha="center", fontsize=9)
    finish(fig, "figure4_dca")
    manifest = json.loads((OUT/"source_manifest.json").read_text(encoding="utf-8"))
    assert all(digest(Path(r["path"])) == r["sha256"] for r in manifest["sources"])
    dump("independent_review.json", dict(sklearn_auc_and_brier_all_9=True, statsmodels_calibration_all_9=True,
         scipy_exact_binomial_all_18=True, pandas_qcut_all_45_bins=True, dca_all_414_model_seed_thresholds=True, source_hashes_unchanged=True,
         figures_created=3, visual_review="pending", matplotlib_version=matplotlib.__version__))
    print("Independent checks passed; all three figures exported as PNG/PDF.")


if __name__ == "__main__":
    if "--plot-check" in sys.argv:
        plot_and_check()
    else:
        build()
