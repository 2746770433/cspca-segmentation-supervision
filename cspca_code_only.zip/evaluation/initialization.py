"""Compare new random-initialized MTL with saved pretrained MTL, without training."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score
from scipy.stats import binomtest
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(HERE))
from delong_three_models import delong_for_models,pairwise_result

def main():
    metrics=[];paired=[]
    for seed in (42,7,2026):
        paths=[ROOT/f'results/runs/mtl/seed_{seed}/test/test_predictions.csv',
               ROOT/f'results/runs/mtl_scratch/seed_{seed}/test/test_predictions.csv']
        frames=[]
        for name,path in zip(['mtl_pretrained','mtl_scratch'],paths):
            if not path.is_file():raise FileNotFoundError(f'Complete training/testing first: {path}')
            f=pd.read_csv(path).set_index(['patient_id','study_id']).sort_index()
            assert len(f)==148 and f.label.sum()==42 and not f.index.duplicated().any()
            frames.append(f)
            metrics.append(dict(model=name,seed=seed,auc=roc_auc_score(f.label,f.probability),
                tpr=f.loc[f.label.eq(1),'prediction'].mean(),fpr=f.loc[f.label.eq(0),'prediction'].mean(),
                dice=f.loc[f.has_valid_mask.eq(1),'dice'].mean(),brier=((f.probability-f.label)**2).mean()))
        a,b=frames
        assert a.index.equals(b.index) and a.label.equals(b.label)
        assert np.array_equal(a.has_valid_mask,b.has_valid_mask)
        auc,cov=delong_for_models(a.label.to_numpy(),np.stack([a.probability,b.probability]))
        d=pairwise_result(1,0,['mtl_pretrained','mtl_scratch'],auc,cov)
        paired.append(dict(seed=seed,metric='auc',difference=d['auc_difference_a_minus_b'],
                           ci_low=d['difference_ci95_lower'],ci_high=d['difference_ci95_upper'],p=d['p_value_two_sided']))
        for metric,label in [('tpr',1),('fpr',0)]:
            aa=a.loc[a.label.eq(label),'prediction'];bb=b.loc[b.label.eq(label),'prediction']
            gain=int(((bb==1)&(aa==0)).sum());loss=int(((bb==0)&(aa==1)).sum())
            paired.append(dict(seed=seed,metric=metric,difference=float(bb.mean()-aa.mean()),
                               p=binomtest(gain,gain+loss,.5).pvalue if gain+loss else 1,gain=gain,loss=loss))
    out=ROOT/'results/analysis/initialization';out.mkdir(parents=True,exist_ok=True)
    m=pd.DataFrame(metrics);m.to_csv(out/'per_seed_metrics.csv',index=False)
    s=m.groupby('model')[['auc','tpr','fpr','dice','brier']].agg(['mean','std'])
    s.to_csv(out/'mean_sd.csv');pd.DataFrame(paired).to_csv(out/'paired_comparisons.csv',index=False)
    (out/'结果汇总.md').write_text('# 初始化对照结果\n\n'+s.to_string()+'\n\n差值按随机初始化MTL减去预训练MTL计算。三个种子独立汇总；未将种子作为独立患者。检验为探索性、未校正多重性。\n',encoding='utf-8')
    print(s.to_string());print(out)

if __name__=='__main__':main()
