"""Read-only analysis of saved predictions and masks; writes only ./analysis."""
from pathlib import Path
import importlib.util
import hashlib
import json
import sys
import numpy as np
import pandas as pd
import nibabel as nib
from nibabel.processing import resample_from_to
from scipy.stats import binom, binomtest
from scipy.optimize import brentq
from scipy.ndimage import label

from settings import ROOT, data_root
HERE=Path(__file__).resolve().parent; DATA_ROOT=data_root(); OUT=ROOT/'results/analysis/error_analysis'
MODELS=('classification','mtl','mtl_focal'); SEEDS=(42,7,2026)
KEY=['patient_id','study_id']; SOURCES=set()

def csv(path, **kwargs):
    SOURCES.add(path); return pd.read_csv(path, **kwargs)

def save(df,name):
    df.to_csv(OUT/(name+'.csv'),index=False,encoding='utf-8-sig')

def rate_ci(k,n):
    if not n:return (np.nan,np.nan,np.nan)
    ci=binomtest(int(k),int(n)).proportion_ci(method='exact')
    return k/n,ci.low,ci.high

def power(q,delta,n=42):
    if not 0<=delta<=q<=1:raise ValueError('Require 0 <= delta <= discordance <= 1')
    if q==0:return 0.
    total=0.
    for m in range(1,n+1):
        wins=np.arange(m+1)
        reject=np.minimum(1,2*binom.cdf(np.minimum(wins,m-wins),m,.5))<=.05
        total+=binom.pmf(m,n,q)*binom.pmf(wins,m,(q+delta)/(2*q))[reject].sum()
    return float(total)

def power_analysis(pred):
    rows=[]
    for q in (.1,.2,.3,.4,.5):
        for target in (.8,.9):
            maximum=power(q,q)
            mde=brentq(lambda d:power(q,d)-target,0,q) if maximum>=target else np.nan
            rows.append(dict(n_positive=42,discordance=q,target_power=target,min_tpr_difference=mde,
                             maximum_power=maximum,alpha=.05,two_sided=True))
    result=pd.DataFrame(rows);save(result,'power_minimum_detectable_difference')
    save(pd.DataFrame([dict(discordance=q,tpr_difference=d,power=power(q,d))
         for q in (.1,.2,.3,.4,.5) for d in (.025,.05,.1,.15,.2,.25,.3) if d<=q]),'power_scenarios')
    observed=[]
    for seed in SEEDS:
        for a,b in [('mtl','classification'),('mtl_focal','mtl')]:
            x=pred.query('model == @a and seed == @seed and label == 1').set_index(KEY)
            y=pred.query('model == @b and seed == @seed and label == 1').set_index(KEY).loc[x.index]
            gain=int(((x.prediction==1)&(y.prediction==0)).sum())
            loss=int(((x.prediction==0)&(y.prediction==1)).sum())
            observed.append(dict(comparison=a+' - '+b,seed=seed,n=42,gain=gain,loss=loss,
                                 discordant=gain+loss,difference=(gain-loss)/42,
                                 exact_p=binomtest(gain,gain+loss,.5).pvalue if gain+loss else 1))
    save(pd.DataFrame(observed),'observed_paired_positive_counts');return result

def remap(s):
    return DATA_ROOT/'data'/s.replace('\\','/').split('/data/',1)[1]

def mask_features(base):
    path=ROOT/'configs/splits/test.xlsx'; SOURCES.add(path)
    tables=pd.read_excel(path); tables[KEY]=tables[KEY].astype(int)
    tables=base.merge(tables,on=KEY,how='left',validate='one_to_one',suffixes=('','_table'))
    spec=importlib.util.spec_from_file_location('analysis_dataset',ROOT/'training/mtl/dataset.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    ds=module.ProstateMultiTaskDataset(pd.DataFrame(), mode='test',augment=False)
    records=[]; empties=[]
    for row in tables.itertuples():
        r=dict(patient_id=row.patient_id,study_id=row.study_id,mask_status='unavailable')
        if not isinstance(row.mask_path_human,str): records.append(r);continue
        mp=remap(row.mask_path_human)
        if not mp.is_file():records.append(r);continue
        SOURCES.add(mp); nii=nib.load(str(mp)); mask=np.asarray(nii.dataobj)>0
        if nii.header.get_xyzt_units()[0]!='mm':
            raise ValueError(f'Volume conversion requires millimetre geometry: {mp}')
        if not mask.any():r['mask_status']='empty_source';records.append(r);continue
        r['mask_status']='nonempty';vox_ml=abs(np.linalg.det(nii.affine[:3,:3]))/1000
        cc,n=label(mask,np.ones((3,3,3)));counts=np.bincount(cc.ravel())[1:]
        r.update(total_volume_ml=float(mask.sum()*vox_ml),largest_component_ml=float(counts.max()*vox_ml),
                 connected_components=n,voxel_volume_ml=vox_ml)
        r['size_group']='<0.5 mL' if r['largest_component_ml']<.5 else '>=0.5 mL'
        for source in ('HeviAI23','Yuan23'):
            zp=DATA_ROOT/'data/picai_labels-main/anatomical_delineations/zonal_pz_tz/AI'/source/f'{row.patient_id}_{row.study_id}.nii.gz'
            if not zp.is_file():r[source+'_zone']='unavailable';continue
            SOURCES.add(zp); zn=nib.load(str(zp))
            z=np.asarray(resample_from_to(zn,nii,order=0).dataobj)
            pz=float((z[mask]==1).mean());tz=float((z[mask]==2).mean())
            r[source+'_pz_fraction']=pz;r[source+'_tz_fraction']=tz
            r[source+'_zone']='PZ_majority' if pz>.5 else 'TZ_majority' if tz>.5 else 'mixed_or_outside'
        gp=remap(row.whole_gland_mask_path)
        if gp.is_file():
            SOURCES.add(gp);gn=nib.load(str(gp))
            if gn.shape!=nii.shape or not np.allclose(gn.affine,nii.affine,atol=1e-3):
                r['crop_status']='grid_mismatch_not_inferred';records.append(r);continue
            gland=np.asarray(gn.dataobj)>0
            m=mask.transpose(2,0,1).astype(np.float32);g=gland.transpose(2,0,1)
            image=np.zeros((1,)+m.shape,dtype=np.float32)
            image,first=ds._crop_or_pad_to_target(image,m,g,(20,256,256))
            _,cropped=ds._apply_crop(image,first,(20,192,192))
            r['roi_kept_fraction']=float(cropped.sum()/mask.sum());r['roi_voxels']=int(cropped.sum())
            r['crop_status']='empty_after_crop' if cropped.sum()==0 else 'nonempty_after_crop'
            if cropped.sum()==0:
                xyz=np.argwhere(mask); gxyz=np.argwhere(gland)
                phys=nib.affines.apply_affine(nii.affine,xyz)
                gphys=nib.affines.apply_affine(gn.affine,gxyz)
                details=dict(r,centroid_RAS_mm=phys.mean(0).tolist(),gland_centroid_RAS_mm=gphys.mean(0).tolist(),
                             centroid_offset_RAS_mm=(phys.mean(0)-gphys.mean(0)).tolist(),
                             bbox_RAS_min_mm=phys.min(0).tolist(),bbox_RAS_max_mm=phys.max(0).tolist(),
                             gland_overlap_fraction=float(gland[mask].mean()))
                empties.append(details)
        records.append(r)
    feats=pd.DataFrame(records);save(feats,'patient_mask_features')
    (OUT/'empty_after_crop_geometry.json').write_text(json.dumps(empties,ensure_ascii=False,indent=2),encoding='utf-8')
    return feats,empties

def stratify(pred,features):
    x=pred.merge(features,on=KEY,how='left',validate='many_to_one')
    rows=[]
    for variable in ['size_group','HeviAI23_zone','Yuan23_zone']:
        for (model,seed,group),g in x[x.label.eq(1)].dropna(subset=[variable]).groupby(['model','seed',variable]):
            if group=='unavailable':continue
            k=int(g.prediction.sum());n=len(g);v,lo,hi=rate_ci(k,n)
            rows.append(dict(variable=variable,group=group,model=model,seed=seed,n_positive=n,tp=k,tpr=v,ci_low=lo,ci_high=hi))
    df=pd.DataFrame(rows);save(df,'positive_strata_per_seed')
    agg=df.groupby(['variable','group','model']).agg(n_positive=('n_positive','first'),mean_tpr=('tpr','mean'),sd_tpr=('tpr','std')).reset_index()
    save(agg,'positive_strata_summary');return agg

def errors(pred,clinical):
    x=pred.merge(clinical,on=KEY,how='left',validate='many_to_one',indicator=True)
    assert x._merge.eq('both').all(), 'Missing official clinical metadata'
    x=x[x.label.eq(0)].copy(); x['has_histopath_record']=x.histopath_type.notna()
    rows=[]
    for (model,seed),g in x.groupby(['model','seed']):
        fp=g[g.prediction.eq(1)]; tn=g[g.prediction.eq(0)]
        for column in ['patient_age','psa','psad','prostate_volume']:
            for kind,part in [('FP',fp),('TN',tn)]:
                vals=pd.to_numeric(part[column],errors='coerce').dropna()
                rows.append(dict(model=model,seed=seed,group=kind,variable=column,n_group=len(part),n_available=len(vals),
                                 median=vals.median(),q1=vals.quantile(.25),q3=vals.quantile(.75)))
    save(pd.DataFrame(rows),'fp_tn_clinical_profiles')
    categories=[]
    for variable in ['center','has_histopath_record']:
        for (model,seed,group),g in x.groupby(['model','seed',variable]):
            k=int(g.prediction.sum());n=len(g);v,lo,hi=rate_ci(k,n)
            categories.append(dict(variable=variable,group=group,model=model,seed=seed,n_negative=n,fp=k,fpr=v,ci_low=lo,ci_high=hi))
    save(pd.DataFrame(categories),'fp_reference_and_center_strata')
    patient=x.groupby(['model']+KEY).agg(fp_seeds=('prediction','sum'),mean_probability=('probability','mean')).reset_index()
    patient=patient.merge(clinical,on=KEY,how='left',validate='many_to_one')
    patient['etiology_review']='not_available';save(patient,'negative_patient_fp_recurrence')
    review=patient[patient.fp_seeds.gt(0)].copy()
    review['reviewer']='';review['confirmed_cause']='';review['supporting_record']=''
    save(review,'fp_cases_for_clinical_review')
    summary=patient.groupby('model').agg(negative_patients=('patient_id','size'),ever_fp=('fp_seeds',lambda s:int((s>0).sum())),
                                        fp_all_three_seeds=('fp_seeds',lambda s:int((s==3).sum()))).reset_index()
    save(summary,'fp_recurrence_summary');return summary

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    frames=[]
    for model in MODELS:
        for seed in SEEDS:
            p=ROOT/'results/runs'/model/f'seed_{seed}/test/test_predictions.csv'
            f=csv(p);f[KEY]=f[KEY].astype(int)
            assert len(f)==148 and f.label.sum()==42 and not f.duplicated(KEY).any()
            assert np.array_equal(f.prediction.to_numpy(),(f.probability.to_numpy()>=.5).astype(int))
            frames.append(f.assign(model=model,seed=seed))
    pred=pd.concat(frames,ignore_index=True)
    base=frames[0][KEY+['label']]
    for f in frames:
        check=base.merge(f[KEY+['label']],on=KEY,validate='one_to_one')
        assert len(check)==148 and (check.label_x==check.label_y).all()
    clinical=csv(ROOT/'configs/official_marksheet.csv')
    pw=power_analysis(pred); features,empty=mask_features(base); strata=stratify(pred,features); fp=errors(pred,clinical)
    present=[c for c in clinical if 'pirad' in c.lower().replace('-','')]
    report=['# 补充分析结果','', '## 1 统计功效',
      '42例阳性、双侧精确McNemar检验、α=0.05。q为总体配对判定不一致概率，δ为TPR绝对差。先对不一致例数的二项分布求和，再计算给定不一致例数的精确拒绝概率；不是观察结果的事后功效。',
      pw.to_string(index=False),'','## 2 病灶分层',
      f'非空人工参考掩膜覆盖{features.mask_status.eq("nonempty").sum()}例。按患者最大的26连通病灶分量体积，以0.5 mL作固定描述性分界，未根据结果选择切点；不是病灶级检测敏感度。',
      'PZ/TZ根据官方AI分区掩膜在物理空间最近邻重采样后的重叠比例判断：超过全部参考病灶体素的50%才归为该区，否则为混合或分区外。HeviAI23为主，Yuan23为辅助核对，均不是人工分区金标准。',
      '这些分层仅含有人工病灶标注的阳性患者，因此报告TPR，不计算无定义的分层FPR。',strata.to_string(index=False),
      f'PI-RADS字段：{present if present else "现有临床表与测试表均未提供，无法完成PI-RADS分层。"}',
      '','## 3 假阳性分析',fp.to_string(index=False),
      '已输出FP/TN的年龄、PSA、PSAD、前列腺体积描述，以及中心、是否有组织病理记录的分层FPR。按患者列出三次训练中反复假阳性的频次。',
      '上述属于错误分布和相关临床特征分析，不是病因确证。没有炎症、增生、伪影诊断字段，未给病例添加这些病因标签。临床复核表保留待填字段。',
      '','## 4 裁剪后空参考掩膜',json.dumps(empty,ensure_ascii=False,indent=2),
      '位置由参考掩膜物理坐标、相对腺体位置及AI分区重叠描述，不用裁剪失败推断外周带病灶。',
      '','## 分析边界','所有新增分层均为探索性描述，不将三个种子视为新增患者。逐种子TPR/FPR区间为患者二项精确区间；种子均值旁的标准差仅描述训练波动。未修改原始表、标签、训练代码或论文。']
    (OUT/'补充分析结果.md').write_text('\n\n'.join(report),encoding='utf-8')
    manifest={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SOURCES)}
    (OUT/'source_sha256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print('Analysis saved:',OUT)
    print(pw.to_string(index=False));print(fp.to_string(index=False));print('Empty masks:',len(empty))

if __name__=='__main__':main()
