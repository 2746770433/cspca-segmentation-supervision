"""Two real images and temporary random weights; never scientific test results."""
import json,sys,tempfile
from pathlib import Path
import pandas as pd
import torch
from settings import ROOT,data_root

def main():
    sys.path.insert(0,str(ROOT/'training/mtl'))
    sys.path.insert(0,str(ROOT/'evaluation'))
    from model import MultiTaskUNet3D
    from test_model import run_test,_remap_project_paths
    frame=_remap_project_paths(pd.read_excel(ROOT/'configs/splits/test.xlsx'),data_root())
    # Select only genuinely present image/mask files, never silently test zero images.
    columns=['t2w_path','adc_path','hbv_path','whole_gland_mask_path']
    present=frame.apply(lambda r:all(isinstance(r.get(c),str) and Path(r[c]).is_file() for c in columns),axis=1)
    frame=frame.loc[present]
    label='cspca_label' if 'cspca_label' in frame else 'label'
    # Original tables store labels under csPCa; use one of each wherever possible.
    if 'csPCa' in frame:label='csPCa'
    groups=frame.groupby(label,dropna=False) if label in frame else [(None,frame)]
    selected=pd.concat([g.head(1) for _,g in groups]).head(2)
    if len(selected)!=2:raise RuntimeError('Need two local cases with all MRI modalities and gland masks for inference smoke.')
    model=MultiTaskUNet3D(in_channels=3,out_channels=1,base_channels=32,backbone='3dunet')
    device='cuda' if torch.cuda.is_available() else 'cpu'
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp);table=tmp/'smoke.xlsx';weight=tmp/'random_smoke.pth'
        selected.to_excel(table,index=False)
        torch.save({'model_state_dict':model.state_dict(),'epoch':0},weight)
        run_test(ROOT/'training/mtl',weight,table,tmp/'test',device_override=device,num_workers=0,bootstrap=0,project_root_override=data_root())
        pred=pd.read_csv(tmp/'test/test_predictions.csv')
        assert len(pred)==2 and pred.probability.between(0,1).all()
        assert (tmp/'test/test_summary.json').is_file() and (tmp/'test/test_summary.md').is_file()
    report=dict(real_image_cases=2,temporary_random_weights=True,device=device,prediction_and_summary_written=True,temporary_files_removed=True)
    out=ROOT/'results/verification';out.mkdir(parents=True,exist_ok=True)
    (out/'inference_smoke.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report))

if __name__=='__main__':main()
