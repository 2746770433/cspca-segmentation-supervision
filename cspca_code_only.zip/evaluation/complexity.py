from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics
import sys
import time
from pathlib import Path


EXPERIMENT_ROOT = Path(__file__).resolve().parent
if str(EXPERIMENT_ROOT) not in sys.path:
    sys.path.insert(0, str(EXPERIMENT_ROOT))

from common import MODEL_LABELS, MODELS, default_project_root  # noqa: E402


def parse_args():
    parser = argparse.ArgumentParser(description="Measure model complexity and inference efficiency.")
    parser.add_argument("--project-root", type=Path, default=default_project_root())
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--warmup", type=int, default=30)
    parser.add_argument("--repeats", type=int, default=200)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parents[1] / "results/analysis/complexity")
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def import_model(branch_dir: Path):
    sys.path.insert(0, str(branch_dir))
    try:
        from model import MultiTaskUNet3D
    finally:
        sys.path.pop(0)
    return MultiTaskUNet3D


def count_macs(model, sample):
    import torch.nn as nn

    macs = {"value": 0}
    handles = []

    def conv_hook(module, inputs, output):
        out_elements = output.numel()
        kernel = 1
        for size in module.kernel_size:
            kernel *= size
        macs["value"] += out_elements * kernel * module.in_channels // module.groups

    def transpose_hook(module, inputs, output):
        input_tensor = inputs[0]
        spatial = input_tensor.shape[2] * input_tensor.shape[3] * input_tensor.shape[4]
        kernel = module.kernel_size[0] * module.kernel_size[1] * module.kernel_size[2]
        macs["value"] += (
            input_tensor.shape[0] * spatial * module.in_channels * module.out_channels * kernel // module.groups
        )

    def linear_hook(module, inputs, output):
        macs["value"] += output.numel() * module.in_features

    for module in model.modules():
        if isinstance(module, nn.Conv3d):
            handles.append(module.register_forward_hook(conv_hook))
        elif isinstance(module, nn.ConvTranspose3d):
            handles.append(module.register_forward_hook(transpose_hook))
        elif isinstance(module, nn.Linear):
            handles.append(module.register_forward_hook(linear_hook))
    model(sample)
    for handle in handles:
        handle.remove()
    return int(macs["value"])


def percentile(values, q):
    import numpy as np

    return float(np.percentile(values, q))


def main():
    args = parse_args()
    if args.warmup < 1 or args.repeats < 2:
        raise ValueError('Use at least one warmup and two timed forward passes.')
    import torch
    import numpy as np

    project_root = args.project_root.resolve()
    branch_root = Path(__file__).resolve().parents[1] / "training"
    architecture_files = ("model.py", "model_3dunet.py", "model_nnunet3d.py")
    hashes = {}
    for model_name in MODELS:
        hashes[model_name] = {}
        for filename in architecture_files:
            model_file = branch_root / model_name / filename
            if not model_file.is_file():
                raise FileNotFoundError(model_file)
            hashes[model_name][filename] = sha256(model_file)
    for filename in architecture_files:
        if len({hashes[model_name][filename] for model_name in MODELS}) != 1:
            raise RuntimeError(f"The three {filename} files are not identical; complexity must be measured separately.")

    requested = args.device
    if requested.startswith("cuda") and not torch.cuda.is_available():
        device = torch.device("cpu")
        print("CUDA is unavailable; latency is measured on CPU and GPU memory is not reported.")
    else:
        device = torch.device(requested)

    Model = import_model(branch_root / "classification")
    model = Model(in_channels=3, out_channels=1, base_channels=32, backbone="3dunet").to(device).eval()
    sample = torch.randn(1, 3, 20, 192, 192, device=device)
    parameters = sum(parameter.numel() for parameter in model.parameters())
    trainable = sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)

    with torch.inference_mode():
        macs = count_macs(model, sample)
        for _ in range(args.warmup):
            model(sample)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats(device)
            baseline_allocated = torch.cuda.memory_allocated(device)
        else:
            baseline_allocated = None

        elapsed_ms = []
        for _ in range(args.repeats):
            if device.type == "cuda":
                torch.cuda.synchronize(device)
            start = time.perf_counter()
            model(sample)
            if device.type == "cuda":
                torch.cuda.synchronize(device)
            elapsed_ms.append((time.perf_counter() - start) * 1000.0)

        if device.type == "cuda":
            peak_allocated = torch.cuda.max_memory_allocated(device)
            peak_reserved = torch.cuda.max_memory_reserved(device)
            incremental_peak = peak_allocated - baseline_allocated
        else:
            peak_allocated = peak_reserved = incremental_peak = None

    result = {
        "architecture_shared_by": list(MODELS),
        "model_sha256": hashes,
        "input_shape": [1, 3, 20, 192, 192],
        "dtype": "float32",
        "device": str(device),
        "hardware_name": torch.cuda.get_device_name(device) if device.type == "cuda" else "CPU",
        "gpu_total_memory_mib": torch.cuda.get_device_properties(device).total_memory / 1024**2 if device.type == "cuda" else None,
        "python_version": sys.version,
        "pytorch_version": torch.__version__,
        "cuda_runtime_version": torch.version.cuda,
        "numpy_version": np.__version__,
        "cudnn_version": torch.backends.cudnn.version(),
        "cudnn_benchmark": torch.backends.cudnn.benchmark,
        "cudnn_allow_tf32": torch.backends.cudnn.allow_tf32,
        "matmul_allow_tf32": torch.backends.cuda.matmul.allow_tf32,
        "measurement_scope": "batch=1 complete forward pass, both heads; excludes disk I/O and preprocessing",
        "parameters": int(parameters),
        "trainable_parameters": int(trainable),
        "macs": int(macs),
        "flops": int(2 * macs),
        "flops_convention": "2 FLOPs per MAC; Conv3d, ConvTranspose3d and Linear only",
        "warmup": int(args.warmup),
        "repeats": int(args.repeats),
        "latency_ms_mean": float(statistics.mean(elapsed_ms)),
        "latency_ms_sd": float(statistics.stdev(elapsed_ms)) if len(elapsed_ms) > 1 else 0.0,
        "latency_ms_median": float(statistics.median(elapsed_ms)),
        "latency_ms_q1": percentile(elapsed_ms, 25),
        "latency_ms_q3": percentile(elapsed_ms, 75),
        "throughput_cases_per_s": float(1000.0 / statistics.mean(elapsed_ms)),
        "peak_allocated_mib": None if peak_allocated is None else float(peak_allocated / 1024 ** 2),
        "peak_reserved_mib": None if peak_reserved is None else float(peak_reserved / 1024 ** 2),
        "incremental_peak_allocated_mib": None if incremental_peak is None else float(incremental_peak / 1024 ** 2),
    }

    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "complexity_results.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    with (args.output_dir / "complexity_results.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=["configuration", *[k for k in result if k not in {"architecture_shared_by", "model_sha256"}]])
        writer.writeheader()
        for model_name in MODELS:
            writer.writerow({"configuration": MODEL_LABELS[model_name], **{k: v for k, v in result.items() if k not in {"architecture_shared_by", "model_sha256"}}})

    memory_text = "not available on CPU"
    if result["peak_allocated_mib"] is not None:
        memory_text = f'{result["peak_allocated_mib"]:.1f} MiB allocated ({result["peak_reserved_mib"]:.1f} MiB reserved)'
    report = f"""# Complexity analysis

The three configurations use byte-identical network definitions, so their inference complexity is identical; only the training supervision/loss differs.

- Input: 1 x 3 x 20 x 192 x 192, FP32
- Measurement hardware: {result['hardware_name']}; PyTorch {result['pytorch_version']}, CUDA runtime {result['cuda_runtime_version']}
- Parameters: {parameters:,}
- MACs: {macs / 1e9:.3f} GMACs
- FLOPs: {2 * macs / 1e9:.3f} GFLOPs (2 FLOPs/MAC; normalization, activation and pooling excluded)
- Latency: {result['latency_ms_median']:.2f} ms median, {result['latency_ms_mean']:.2f} ± {result['latency_ms_sd']:.2f} ms mean ± SD ({device})
- Throughput: {result['throughput_cases_per_s']:.2f} cases/s
- Peak memory: {memory_text}

Latency includes the complete forward pass that produces both the segmentation map and classification probability. Disk I/O and preprocessing are excluded.
"""
    (args.output_dir / "complexity_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
