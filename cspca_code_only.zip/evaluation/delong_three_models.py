#!/usr/bin/env python3
"""Paired DeLong tests for the three manuscript classification models.

This script is independent of the training and inference code. It reads the
saved patient-level prediction CSV files and compares correlated ROC AUCs.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BASELINE = ROOT / "test" / "single_task_classification" / "test_predictions.csv"
DEFAULT_MTL = ROOT / "test" / "initial_multitask_192_tpr" / "test_predictions.csv"
DEFAULT_FOCAL = ROOT / "test" / "focal_multitask_192_tpr" / "test_predictions.csv"
DEFAULT_OUTPUT = ROOT / "training_branches" / "supplemental" / "paper_statistics" / "results" / "delong"

REQUIRED_COLUMNS = {"patient_id", "study_id", "label", "probability"}


@dataclass(frozen=True)
class PredictionTable:
    name: str
    path: Path
    keys: tuple[tuple[str, str], ...]
    labels: np.ndarray
    probabilities: np.ndarray


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run paired DeLong tests for the classification baseline, MTL, "
            "and MTL+Focal using saved test probabilities."
        )
    )
    parser.add_argument("--baseline", type=Path, default=DEFAULT_BASELINE)
    parser.add_argument("--mtl", type=Path, default=DEFAULT_MTL)
    parser.add_argument("--focal", type=Path, default=DEFAULT_FOCAL)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def load_predictions(name: str, path: Path) -> PredictionTable:
    if not path.is_file():
        raise FileNotFoundError(f"{name}: prediction file not found: {path}")

    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        columns = set(reader.fieldnames or [])
        missing = REQUIRED_COLUMNS - columns
        if missing:
            raise ValueError(f"{name}: missing CSV columns: {sorted(missing)}")
        rows = list(reader)

    if not rows:
        raise ValueError(f"{name}: prediction file is empty")

    keys = tuple((row["patient_id"].strip(), row["study_id"].strip()) for row in rows)
    if len(set(keys)) != len(keys):
        raise ValueError(f"{name}: duplicate patient_id/study_id pairs detected")

    labels = np.asarray([int(row["label"]) for row in rows], dtype=np.int64)
    probabilities = np.asarray(
        [float(row["probability"]) for row in rows], dtype=np.float64
    )

    if not np.isin(labels, [0, 1]).all():
        raise ValueError(f"{name}: labels must be binary 0/1")
    if np.unique(labels).size != 2:
        raise ValueError(f"{name}: both positive and negative labels are required")
    if not np.isfinite(probabilities).all():
        raise ValueError(f"{name}: probabilities contain NaN or infinity")
    if ((probabilities < 0.0) | (probabilities > 1.0)).any():
        raise ValueError(f"{name}: probabilities must lie in [0, 1]")

    return PredictionTable(name, path, keys, labels, probabilities)


def align_tables(tables: Iterable[PredictionTable]) -> tuple[np.ndarray, np.ndarray]:
    tables = tuple(tables)
    reference = tables[0]
    reference_set = set(reference.keys)
    aligned_probabilities = []

    for table in tables:
        table_set = set(table.keys)
        if table_set != reference_set:
            missing = sorted(reference_set - table_set)[:5]
            extra = sorted(table_set - reference_set)[:5]
            raise ValueError(
                f"{table.name}: patient set differs from {reference.name}; "
                f"missing examples={missing}, extra examples={extra}"
            )

        index = {key: i for i, key in enumerate(table.keys)}
        order = np.asarray([index[key] for key in reference.keys], dtype=np.int64)
        aligned_labels = table.labels[order]
        if not np.array_equal(aligned_labels, reference.labels):
            mismatch = np.flatnonzero(aligned_labels != reference.labels)[:5]
            details = [
                {
                    "key": reference.keys[i],
                    "reference_label": int(reference.labels[i]),
                    "other_label": int(aligned_labels[i]),
                }
                for i in mismatch
            ]
            raise ValueError(f"{table.name}: label mismatch: {details}")
        aligned_probabilities.append(table.probabilities[order])

    return reference.labels, np.vstack(aligned_probabilities)


def compute_midrank(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values)
    sorted_values = values[order]
    count = len(values)
    midranks = np.zeros(count, dtype=np.float64)
    start = 0
    while start < count:
        end = start
        while end < count and sorted_values[end] == sorted_values[start]:
            end += 1
        midranks[start:end] = 0.5 * (start + end - 1)
        start = end
    result = np.empty(count, dtype=np.float64)
    result[order] = midranks + 1.0
    return result


def covariance_matrix(values: np.ndarray) -> np.ndarray:
    """Return a stable 2-D covariance matrix for row-wise variables."""
    variables, observations = values.shape
    if observations <= 1:
        return np.zeros((variables, variables), dtype=np.float64)
    covariance = np.cov(values, bias=False)
    return np.atleast_2d(covariance).reshape(variables, variables)


def fast_delong(
    predictions_sorted_by_label: np.ndarray, positive_count: int
) -> tuple[np.ndarray, np.ndarray]:
    """Compute correlated AUC estimates and their DeLong covariance matrix."""
    model_count, total_count = predictions_sorted_by_label.shape
    negative_count = total_count - positive_count
    positive_scores = predictions_sorted_by_label[:, :positive_count]
    negative_scores = predictions_sorted_by_label[:, positive_count:]

    positive_midranks = np.empty_like(positive_scores, dtype=np.float64)
    negative_midranks = np.empty_like(negative_scores, dtype=np.float64)
    all_midranks = np.empty_like(predictions_sorted_by_label, dtype=np.float64)

    for model_index in range(model_count):
        positive_midranks[model_index] = compute_midrank(
            positive_scores[model_index]
        )
        negative_midranks[model_index] = compute_midrank(
            negative_scores[model_index]
        )
        all_midranks[model_index] = compute_midrank(
            predictions_sorted_by_label[model_index]
        )

    aucs = (
        all_midranks[:, :positive_count].sum(axis=1)
        / positive_count
        / negative_count
        - (positive_count + 1.0) / (2.0 * negative_count)
    )
    positive_components = (
        all_midranks[:, :positive_count] - positive_midranks
    ) / negative_count
    negative_components = (
        all_midranks[:, positive_count:] - negative_midranks
    ) / positive_count
    covariance = (
        covariance_matrix(positive_components) / positive_count
        + covariance_matrix(negative_components) / negative_count
    )
    return aucs, covariance


def delong_for_models(
    labels: np.ndarray, probabilities: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    positive_count = int(labels.sum())
    order = np.argsort(-labels, kind="stable")
    return fast_delong(probabilities[:, order], positive_count)


def normal_two_sided_p(z_value: float) -> float:
    return math.erfc(abs(z_value) / math.sqrt(2.0))


def auc_confidence_interval(auc: float, variance: float) -> tuple[float, float]:
    standard_error = math.sqrt(max(float(variance), 0.0))
    return max(0.0, auc - 1.96 * standard_error), min(
        1.0, auc + 1.96 * standard_error
    )


def pairwise_result(
    model_a: int,
    model_b: int,
    names: list[str],
    aucs: np.ndarray,
    covariance: np.ndarray,
) -> dict[str, float | str]:
    difference = float(aucs[model_a] - aucs[model_b])
    variance = float(
        covariance[model_a, model_a]
        + covariance[model_b, model_b]
        - 2.0 * covariance[model_a, model_b]
    )
    variance = max(variance, 0.0)
    standard_error = math.sqrt(variance)

    if standard_error == 0.0:
        z_value = 0.0 if difference == 0.0 else math.copysign(math.inf, difference)
        p_value = 1.0 if difference == 0.0 else 0.0
    else:
        z_value = difference / standard_error
        p_value = normal_two_sided_p(z_value)

    return {
        "model_a": names[model_a],
        "model_b": names[model_b],
        "auc_a": float(aucs[model_a]),
        "auc_b": float(aucs[model_b]),
        "auc_difference_a_minus_b": difference,
        "difference_standard_error": standard_error,
        "difference_ci95_lower": difference - 1.96 * standard_error,
        "difference_ci95_upper": difference + 1.96 * standard_error,
        "z": z_value,
        "p_value_two_sided": p_value,
    }


def holm_adjust(p_values: list[float]) -> list[float]:
    count = len(p_values)
    order = sorted(range(count), key=lambda index: p_values[index])
    adjusted = [0.0] * count
    running_max = 0.0
    for rank, index in enumerate(order):
        candidate = min(1.0, (count - rank) * p_values[index])
        running_max = max(running_max, candidate)
        adjusted[index] = running_max
    return adjusted


def format_number(value: float, digits: int = 4) -> str:
    if math.isinf(value):
        return "inf" if value > 0 else "-inf"
    return f"{value:.{digits}f}"


def write_outputs(
    output_dir: Path,
    tables: list[PredictionTable],
    labels: np.ndarray,
    aucs: np.ndarray,
    covariance: np.ndarray,
    comparisons: list[dict[str, float | str]],
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    names = [table.name for table in tables]

    auc_rows = []
    for index, name in enumerate(names):
        lower, upper = auc_confidence_interval(
            float(aucs[index]), float(covariance[index, index])
        )
        auc_rows.append(
            {
                "model": name,
                "auc": float(aucs[index]),
                "delong_ci95_lower": lower,
                "delong_ci95_upper": upper,
            }
        )

    with (output_dir / "delong_pairwise_results.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=list(comparisons[0].keys()))
        writer.writeheader()
        writer.writerows(comparisons)

    payload = {
        "sample_count": int(labels.size),
        "positive_count": int(labels.sum()),
        "negative_count": int((labels == 0).sum()),
        "inputs": {table.name: str(table.path) for table in tables},
        "auc_estimates": auc_rows,
        "delong_covariance": covariance.tolist(),
        "pairwise_comparisons": comparisons,
    }
    (output_dir / "delong_results.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    lines = [
        "# 三种模型的配对DeLong检验",
        "",
        f"- 测试病例：{labels.size}例",
        f"- 阳性：{int(labels.sum())}例",
        f"- 阴性：{int((labels == 0).sum())}例",
        "- 检验输入：逐病例连续预测概率",
        "- 检验类型：双侧、配对DeLong检验",
        "",
        "## AUC",
        "",
        "| 模型 | AUC | DeLong 95% CI |",
        "|---|---:|---:|",
    ]
    for row in auc_rows:
        lines.append(
            f"| {row['model']} | {row['auc']:.4f} | "
            f"{row['delong_ci95_lower']:.4f}-{row['delong_ci95_upper']:.4f} |"
        )

    lines.extend(
        [
            "",
            "## 两两比较",
            "",
            "| 模型A | 模型B | AUC差值（A-B） | 差值95% CI | z | 原始p值 | Holm校正p值 |",
            "|---|---|---:|---:|---:|---:|---:|",
        ]
    )
    for row in comparisons:
        lines.append(
            f"| {row['model_a']} | {row['model_b']} | "
            f"{format_number(float(row['auc_difference_a_minus_b']))} | "
            f"{format_number(float(row['difference_ci95_lower']))}-"
            f"{format_number(float(row['difference_ci95_upper']))} | "
            f"{format_number(float(row['z']))} | "
            f"{format_number(float(row['p_value_two_sided']), 6)} | "
            f"{format_number(float(row['p_value_holm']), 6)} |"
        )

    primary = comparisons[0]
    lines.extend(
        [
            "",
            "## 论文主要比较",
            "",
            "主要比较预先指定为 Classification baseline 与 MTL。",
            (
                f"两者AUC差值（Classification baseline - MTL）为 "
                f"{format_number(float(primary['auc_difference_a_minus_b']))}，"
                f"双侧DeLong检验p值为 "
                f"{format_number(float(primary['p_value_two_sided']), 6)}。"
            ),
            "",
            "说明：DeLong检验只比较AUC，不评价固定阈值下的TPR或FPR；"
            "后两者应使用配对的分类结果进行McNemar检验。",
        ]
    )
    (output_dir / "delong_report_CN.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main() -> None:
    args = parse_args()
    tables = [
        load_predictions("Classification baseline", args.baseline),
        load_predictions("MTL", args.mtl),
        load_predictions("MTL+Focal", args.focal),
    ]
    labels, probabilities = align_tables(tables)
    aucs, covariance = delong_for_models(labels, probabilities)
    names = [table.name for table in tables]

    pairs = [(0, 1), (0, 2), (1, 2)]
    comparisons = [
        pairwise_result(model_a, model_b, names, aucs, covariance)
        for model_a, model_b in pairs
    ]
    adjusted = holm_adjust(
        [float(result["p_value_two_sided"]) for result in comparisons]
    )
    for result, adjusted_p in zip(comparisons, adjusted):
        result["p_value_holm"] = adjusted_p

    write_outputs(
        args.output_dir,
        tables,
        labels,
        aucs,
        covariance,
        comparisons,
    )

    print(f"Patients: {labels.size} ({int(labels.sum())} positive)")
    for name, auc in zip(names, aucs):
        print(f"{name}: AUC={auc:.4f}")
    print()
    for result in comparisons:
        print(
            f"{result['model_a']} vs {result['model_b']}: "
            f"difference={float(result['auc_difference_a_minus_b']):.4f}, "
            f"p={float(result['p_value_two_sided']):.6f}, "
            f"Holm p={float(result['p_value_holm']):.6f}"
        )
    print(f"\nSaved results to: {args.output_dir}")


if __name__ == "__main__":
    main()
