from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd


EXPERIMENT_ROOT = Path(__file__).resolve().parent
if str(EXPERIMENT_ROOT) not in sys.path:
    sys.path.insert(0, str(EXPERIMENT_ROOT))

from common import (  # noqa: E402
    MODEL_LABELS,
    binary_auc,
    default_project_root,
    discover_run_root,
    load_all_predictions,
    normalize_id,
    stratified_auc_ci,
    wilson_interval,
)


def parse_args():
    parser = argparse.ArgumentParser(description="Exploratory center-stratified test analysis.")
    parser.add_argument("--project-root", type=Path, default=default_project_root())
    parser.add_argument("--run-root", type=Path)
    parser.add_argument("--threshold", type=float, default=0.5)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parents[1] / "results/analysis/centers")
    return parser.parse_args()


def main():
    args = parse_args()
    project_root = args.project_root.resolve()
    run_root = discover_run_root(project_root, args.run_root)
    predictions = load_all_predictions(run_root)

    marksheet_path = Path(__file__).resolve().parents[1] / "configs/official_marksheet.csv"
    if not marksheet_path.is_file():
        raise FileNotFoundError(marksheet_path)
    marksheet = pd.read_csv(marksheet_path, usecols=["patient_id", "study_id", "center", "case_csPCa"])
    marksheet["patient_id"] = marksheet["patient_id"].map(normalize_id)
    marksheet["study_id"] = marksheet["study_id"].map(normalize_id)
    if marksheet[["patient_id", "study_id"]].duplicated().any():
        raise ValueError("Duplicate patient-study pairs in PI-CAI marksheet")
    merged = predictions.merge(marksheet, on=["patient_id", "study_id"], how="left", validate="many_to_one")
    official_labels = merged["case_csPCa"].astype(str).str.upper().map({"YES": 1, "NO": 0})
    if official_labels.isna().any() or not np.array_equal(official_labels.to_numpy(), merged["label"].to_numpy()):
        raise ValueError("Test labels do not match official PI-CAI case_csPCa labels.")
    if merged["center"].isna().any():
        missing = merged.loc[merged["center"].isna(), ["patient_id", "study_id"]].drop_duplicates()
        raise ValueError(f"Center is missing for {len(missing)} test cases")

    counts = (
        merged[["patient_id", "study_id", "label", "center"]]
        .drop_duplicates()
        .groupby("center", as_index=False)
        .agg(n=("label", "size"), positive=("label", "sum"))
    )
    counts["negative"] = counts["n"] - counts["positive"]

    records = []
    for (model, seed, center), group in merged.groupby(["model", "seed", "center"], sort=True):
        y = group["label"].to_numpy(dtype=int)
        probability = group["probability"].to_numpy(dtype=float)
        prediction = (probability >= args.threshold).astype(int)
        positive = int((y == 1).sum())
        negative = int((y == 0).sum())
        tp = int(((prediction == 1) & (y == 1)).sum())
        fp = int(((prediction == 1) & (y == 0)).sum())
        auc = binary_auc(y, probability) if positive and negative else math.nan
        auc_low, auc_high = stratified_auc_ci(y, probability, args.bootstrap, seed=seed + sum(map(ord, center)))
        tpr_low, tpr_high = wilson_interval(tp, positive)
        fpr_low, fpr_high = wilson_interval(fp, negative)
        records.append(
            {
                "model": model,
                "model_label": MODEL_LABELS[model],
                "seed": seed,
                "center": center,
                "n": len(group),
                "positive": positive,
                "negative": negative,
                "auc": auc,
                "auc_ci_low": auc_low,
                "auc_ci_high": auc_high,
                "tpr": tp / positive if positive else math.nan,
                "tpr_ci_low": tpr_low,
                "tpr_ci_high": tpr_high,
                "fpr": fp / negative if negative else math.nan,
                "fpr_ci_low": fpr_low,
                "fpr_ci_high": fpr_high,
                "tp": tp,
                "fp": fp,
            }
        )
    per_seed = pd.DataFrame(records)

    summary_rows = []
    for (model, center), group in per_seed.groupby(["model", "center"], sort=True):
        row = {"model": model, "model_label": MODEL_LABELS[model], "center": center, "seeds": len(group)}
        for metric in ("auc", "tpr", "fpr"):
            values = group[metric].dropna()
            row[f"{metric}_mean"] = values.mean()
            row[f"{metric}_sd"] = values.std(ddof=1) if len(values) > 1 else math.nan
            row[f"{metric}_min"] = values.min()
            row[f"{metric}_max"] = values.max()
        summary_rows.append(row)
    summary = pd.DataFrame(summary_rows)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    counts.to_csv(args.output_dir / "center_case_counts.csv", index=False, encoding="utf-8-sig")
    per_seed.to_csv(args.output_dir / "center_metrics_per_seed.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(args.output_dir / "center_metrics_summary.csv", index=False, encoding="utf-8-sig")

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    centers = counts.sort_values("n", ascending=False)["center"].tolist()
    colors = {
        "classification": "#D97706",
        "classification_scratch": "#B279A2",
        "mtl": "#2E7D32",
        "mtl_focal": "#C43C4E",
    }
    present_models = [model for model in MODEL_LABELS if model in set(summary["model"])]
    fig, axes = plt.subplots(1, 3, figsize=(13.2, 4.2), constrained_layout=True)
    x = np.arange(len(centers))
    width = 0.24
    for axis, metric, title in zip(axes, ("auc", "tpr", "fpr"), ("AUC", "Sensitivity", "False-positive rate")):
        for offset, model in enumerate(present_models):
            subset = summary[summary["model"] == model].set_index("center").reindex(centers)
            axis.errorbar(
                x + (offset - (len(present_models) - 1) / 2) * width,
                subset[f"{metric}_mean"],
                yerr=subset[f"{metric}_sd"],
                fmt="o",
                capsize=3,
                color=colors[model],
                label=MODEL_LABELS[model],
            )
        count_index = counts.set_index("center")
        axis.set_xticks(x, [f"{center}\nn={int(count_index.loc[center, 'n'])}, positive={int(count_index.loc[center, 'positive'])}" for center in centers])
        axis.set_ylim(-0.04, 1.04)
        axis.set_title(title)
        axis.grid(axis="y", alpha=0.25)
    axes[0].legend(frameon=False, fontsize=9, loc="lower left")
    fig.savefig(args.output_dir / "cross_center_metrics.png", dpi=300)
    fig.savefig(args.output_dir / "cross_center_metrics.pdf")
    plt.close(fig)

    count_lines = [f"- {row.center}: n={row.n}, positive={row.positive}, negative={row.negative}" for row in counts.itertuples()]
    table = summary.copy()
    for metric in ("auc", "tpr", "fpr"):
        table[metric.upper()] = table.apply(lambda r: f"{r[f'{metric}_mean']:.3f} ± {r[f'{metric}_sd']:.3f}", axis=1)
    table_lines = [
        "| Center | Configuration | AUC | TPR | FPR |",
        "|---|---|---:|---:|---:|",
    ]
    for row in table.itertuples():
        table_lines.append(f"| {row.center} | {row.model_label} | {row.AUC} | {row.TPR} | {row.FPR} |")
    table_text = "\n".join(table_lines)
    report = "# Cross-center analysis\n\n" + "\n".join(count_lines) + "\n\n" + table_text + (
        "\n\nMetrics are reported as the mean ± SD across the three prespecified random seeds at a fixed classification threshold of "
        f"{args.threshold:.2f}. Per-seed AUC intervals use stratified bootstrap; TPR/FPR intervals use Wilson intervals. "
        "This is an exploratory subgroup analysis without formal between-center hypothesis testing. Results from centers with few positive cases, "
        "especially a center with only three positives, have substantial uncertainty and should not be used to claim center-level superiority. "
        "A degenerate empirical bootstrap AUC interval (e.g. [1, 1]) reflects perfect ranking in this small observed sample, not certainty about population AUC. "
        "All centers contribute to the same internal held-out cohort; this is not leave-one-center-out or independent external validation.\n"
    )
    (args.output_dir / "cross_center_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
