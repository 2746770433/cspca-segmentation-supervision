import argparse
import json
import os
import random
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import confusion_matrix, roc_auc_score
from torch.utils.data import DataLoader
from tqdm import tqdm


PATH_COLUMNS = (
    "t2w_path",
    "adc_path",
    "hbv_path",
    "mask_path_human",
    "mask_path_ai",
    "whole_gland_mask_path",
)


def _remap_project_paths(frame, project_root):
    frame = frame.copy()
    for column in PATH_COLUMNS:
        if column not in frame.columns:
            continue

        def remap(value):
            if not isinstance(value, str) or not value.strip():
                return value
            normalized = value.replace("\\", "/")
            marker_index = normalized.find("/data/")
            if marker_index < 0:
                return value
            return str(project_root / Path(normalized[marker_index + 1 :]))

        frame[column] = frame[column].map(remap)
    return frame


def _import_from_branch(branch_dir):
    branch_dir = Path(branch_dir).resolve()
    if str(branch_dir) not in sys.path:
        sys.path.insert(0, str(branch_dir))

    import config  # noqa: WPS433
    from dataset import ProstateMultiTaskDataset  # noqa: WPS433
    from model import MultiTaskUNet3D  # noqa: WPS433

    return config, ProstateMultiTaskDataset, MultiTaskUNet3D


def _set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _load_checkpoint(path, device):
    try:
        checkpoint = torch.load(path, map_location=device, weights_only=False)
    except TypeError:
        checkpoint = torch.load(path, map_location=device)
    if isinstance(checkpoint, dict) and "model_state_dict" in checkpoint:
        return checkpoint, checkpoint["model_state_dict"]
    return checkpoint, checkpoint


def _dice_from_logits(logits, targets, threshold=0.45, smooth=1e-5):
    preds = (torch.sigmoid(logits) > threshold).float()
    preds_flat = preds.reshape(-1)
    targets_flat = targets.reshape(-1)
    intersection = (preds_flat * targets_flat).sum()
    denom = preds_flat.sum() + targets_flat.sum()
    return ((2.0 * intersection + smooth) / (denom + smooth)).item()


def _safe_auc(y_true, y_score):
    if len(np.unique(y_true)) < 2:
        return float("nan")
    return float(roc_auc_score(y_true, y_score))


def _classification_metrics(y_true, y_prob, cls_threshold=0.5):
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob).astype(float)
    y_pred = (y_prob >= cls_threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "auc": _safe_auc(y_true, y_prob),
        "tpr": float(tp / (tp + fn)) if (tp + fn) else 0.0,
        "fpr": float(fp / (fp + tn)) if (fp + tn) else 0.0,
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


def _bootstrap_ci(y_true, y_prob, dice_values, n_boot=1000, seed=42, cls_threshold=0.5):
    if n_boot <= 0:
        return {}

    rng = np.random.default_rng(seed)
    y_true = np.asarray(y_true).astype(int)
    y_prob = np.asarray(y_prob).astype(float)
    dice_values = np.asarray(dice_values).astype(float)

    out = {"n_boot": int(n_boot)}
    cls_stats = {"auc": [], "tpr": [], "fpr": []}
    n = len(y_true)
    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        if len(np.unique(y_true[idx])) < 2:
            continue
        m = _classification_metrics(y_true[idx], y_prob[idx], cls_threshold)
        for key in cls_stats:
            cls_stats[key].append(m[key])

    for key, values in cls_stats.items():
        if values:
            out[key] = [float(np.percentile(values, 2.5)), float(np.percentile(values, 97.5))]
        else:
            out[key] = [float("nan"), float("nan")]

    if len(dice_values) > 0:
        dice_boot = []
        for _ in range(n_boot):
            idx = rng.integers(0, len(dice_values), size=len(dice_values))
            dice_boot.append(float(np.mean(dice_values[idx])))
        out["dice"] = [float(np.percentile(dice_boot, 2.5)), float(np.percentile(dice_boot, 97.5))]
    else:
        out["dice"] = [float("nan"), float("nan")]

    return out


def run_test(
    branch_dir,
    checkpoint,
    test_table,
    output_dir,
    device_override=None,
    batch_size=1,
    num_workers=None,
    cls_threshold=0.5,
    seg_threshold=None,
    bootstrap=1000,
    seed=42,
    classification_only=False,
    project_root_override=None,
):
    branch_dir = Path(branch_dir).resolve()
    config, DatasetCls, ModelCls = _import_from_branch(branch_dir)

    _set_seed(seed)

    device_name = device_override or getattr(config, "DEVICE", "cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(device_name)
    checkpoint = Path(checkpoint) if checkpoint else Path(getattr(config, "MODEL_SAVE_PATH"))
    test_table = Path(test_table) if test_table else Path(getattr(config, "TEST_TABLE"))
    output_dir = Path(output_dir) if output_dir else branch_dir / "test_results" / checkpoint.parent.name
    output_dir.mkdir(parents=True, exist_ok=True)

    if seg_threshold is None:
        seg_threshold = float(getattr(config, "THRESHOLD", 0.45))
    if num_workers is None:
        num_workers = int(getattr(config, "NUM_WORKERS", 4))

    print(f"Branch: {branch_dir}")
    print(f"Test table: {test_table}")
    print(f"Checkpoint: {checkpoint}")
    print(f"Output dir: {output_dir}")
    print(f"Device: {device}")

    if not test_table.exists():
        raise FileNotFoundError(f"Test table not found: {test_table}")
    if not checkpoint.exists():
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint}")

    test_df = pd.read_excel(test_table)
    project_root = (
        Path(project_root_override).resolve()
        if project_root_override
        else test_table.resolve().parents[2]
    )
    test_df = _remap_project_paths(test_df, project_root)
    if "has_valid_human_mask" in test_df.columns:
        test_df["has_valid_human_mask_clean"] = test_df["has_valid_human_mask"].apply(
            lambda x: str(x).strip().upper() in ["TRUE", "1", "1.0"] if not pd.isna(x) else False
        )

    print("\nDataset distribution:")
    print(f"  total: {len(test_df)}")
    if "cspca_label" in test_df.columns:
        print(f"  class positive: {int((test_df['cspca_label'] == 1).sum())}")
        print(f"  class negative: {int((test_df['cspca_label'] == 0).sum())}")
    if "has_valid_human_mask_clean" in test_df.columns:
        print(f"  valid masks: {int(test_df['has_valid_human_mask_clean'].sum())}")

    dataset = DatasetCls(
        test_df,
        mode="val",
        target_shape=getattr(config, "TARGET_SHAPE"),
        crop_shape=getattr(config, "CROP_SHAPE"),
        use_roi_crop=getattr(config, "USE_ROI_CROP", True),
        augment=False,
    )
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers)

    model = ModelCls(
        in_channels=3,
        out_channels=1,
        base_channels=32,
        backbone=getattr(config, "BACKBONE", "3dunet"),
    ).to(device)

    checkpoint_obj, state_dict = _load_checkpoint(checkpoint, device)
    model.load_state_dict(state_dict)
    model.eval()

    labels, probs, dices, rows = [], [], [], []
    with torch.no_grad():
        for start_idx, batch in enumerate(tqdm(loader, desc="Testing")):
            images = batch["image"].to(device)
            masks_gt = batch["mask"].to(device)
            labels_gt = batch["label"].to(device).float()
            has_valid_mask = batch["has_valid_mask"].to(device).float()

            masks_pred, cls_logits = model(images)
            batch_probs = torch.sigmoid(cls_logits).detach().cpu().numpy().reshape(-1)
            batch_labels = labels_gt.detach().cpu().numpy().reshape(-1).astype(int)
            batch_has_mask = has_valid_mask.detach().cpu().numpy().reshape(-1)

            for i in range(images.shape[0]):
                global_idx = start_idx * batch_size + i
                dice = np.nan
                if (
                    not classification_only
                    and float(batch_has_mask[i]) == 1.0
                    and float(masks_gt[i].sum().item()) > 0.0
                ):
                    dice = _dice_from_logits(masks_pred[i : i + 1], masks_gt[i : i + 1], seg_threshold)
                    dices.append(dice)

                labels.append(int(batch_labels[i]))
                probs.append(float(batch_probs[i]))
                source_row = test_df.iloc[global_idx].to_dict()
                rows.append(
                    {
                        "index": int(global_idx),
                        "patient_id": source_row.get("patient_id", ""),
                        "study_id": source_row.get("study_id", ""),
                        "label": int(batch_labels[i]),
                        "probability": float(batch_probs[i]),
                        "prediction": int(batch_probs[i] >= cls_threshold),
                        "has_valid_mask": int(
                            not classification_only
                            and float(batch_has_mask[i]) == 1.0
                            and float(masks_gt[i].sum().item()) > 0.0
                        ),
                        "dice": dice,
                    }
                )

    cls = _classification_metrics(labels, probs, cls_threshold)
    mean_dice = float(np.nanmean(dices)) if len(dices) else float("nan")
    score = (cls["auc"] * 2.0) + cls["tpr"] - (cls["fpr"] * 1.5)
    ci = _bootstrap_ci(labels, probs, dices, bootstrap, seed, cls_threshold)

    summary = {
        "branch": str(branch_dir),
        "checkpoint": str(checkpoint),
        "checkpoint_epoch": checkpoint_obj.get("epoch") if isinstance(checkpoint_obj, dict) else None,
        "test_table": str(test_table),
        "n_cases": int(len(labels)),
        "n_valid_masks": int(len(dices)),
        "classification_threshold": float(cls_threshold),
        "segmentation_threshold": float(seg_threshold),
        "auc": cls["auc"],
        "tpr": cls["tpr"],
        "fpr": cls["fpr"],
        "dice": mean_dice,
        "tp": cls["tp"],
        "fp": cls["fp"],
        "tn": cls["tn"],
        "fn": cls["fn"],
        "unified_classification_score_no_dice_penalty": float(score),
        "bootstrap_95ci": ci,
    }

    pd.DataFrame(rows).to_csv(output_dir / "test_predictions.csv", index=False, encoding="utf-8-sig")
    (output_dir / "test_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    md_lines = [
        "# Test-set evaluation",
        "",
        f"- Branch: `{branch_dir}`",
        f"- Checkpoint: `{checkpoint}`",
        f"- Checkpoint epoch: {summary['checkpoint_epoch']}",
        f"- Test table: `{test_table}`",
        f"- Cases: {summary['n_cases']}",
        f"- Valid lesion masks for Dice: {summary['n_valid_masks']}",
        "",
        "| Metric | Value | 95% CI |",
        "|---|---:|---:|",
    ]
    for key, name in [("auc", "AUC"), ("tpr", "TPR"), ("fpr", "FPR"), ("dice", "Dice")]:
        value = summary[key]
        interval = ci.get(key)
        ci_text = "" if not interval else f"{interval[0]:.4f}-{interval[1]:.4f}"
        value_text = "nan" if np.isnan(value) else f"{value:.4f}"
        md_lines.append(f"| {name} | {value_text} | {ci_text} |")
    md_lines.extend(
        [
            "",
            f"- Confusion matrix at threshold {cls_threshold}: TP={cls['tp']}, FP={cls['fp']}, TN={cls['tn']}, FN={cls['fn']}",
            f"- Unified classification score without Dice penalty: {score:.4f}",
        ]
    )
    (output_dir / "test_summary.md").write_text("\n".join(md_lines), encoding="utf-8")

    print("\n" + "=" * 70)
    print("Test evaluation complete")
    print("=" * 70)
    print(f"AUC : {summary['auc']:.4f}")
    print(f"TPR : {summary['tpr']:.4f}")
    print(f"FPR : {summary['fpr']:.4f}")
    print(f"Dice: {summary['dice']:.4f}")
    print(f"Confusion matrix: TP={cls['tp']} FP={cls['fp']} TN={cls['tn']} FN={cls['fn']}")
    print(f"Saved: {output_dir / 'test_summary.md'}")
    print(f"Saved: {output_dir / 'test_predictions.csv'}")


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Evaluate a multitask prostate MRI model on the test split.")
    parser.add_argument("--branch-dir", required=True, help="Directory containing config.py, dataset.py and model.py.")
    parser.add_argument("--checkpoint", default=None, help="Checkpoint path. Defaults to config.MODEL_SAVE_PATH.")
    parser.add_argument("--test-table", default=None, help="Test Excel path. Defaults to config.TEST_TABLE.")
    parser.add_argument("--project-root", default=None, help="Project root used to remap legacy paths in the table.")
    parser.add_argument("--output-dir", default=None, help="Directory for summary and predictions.")
    parser.add_argument("--device", default=None, help="Override device, e.g. cuda:0, cuda:1, cuda:2 or cpu.")
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--num-workers", type=int, default=None)
    parser.add_argument("--cls-threshold", type=float, default=0.5)
    parser.add_argument("--seg-threshold", type=float, default=None)
    parser.add_argument("--bootstrap", type=int, default=1000, help="Bootstrap iterations for 95%% CI. Use 0 to disable.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--classification-only",
        action="store_true",
        help="Evaluate classification only and report Dice as not applicable.",
    )
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    run_test(
        branch_dir=args.branch_dir,
        checkpoint=args.checkpoint,
        test_table=args.test_table,
        output_dir=args.output_dir,
        device_override=args.device,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        cls_threshold=args.cls_threshold,
        seg_threshold=args.seg_threshold,
        bootstrap=args.bootstrap,
        seed=args.seed,
        classification_only=args.classification_only,
        project_root_override=args.project_root,
    )


if __name__ == "__main__":
    main()
