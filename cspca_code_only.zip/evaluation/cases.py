from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd


EXPERIMENT_ROOT = Path(__file__).resolve().parent
if str(EXPERIMENT_ROOT) not in sys.path:
    sys.path.insert(0, str(EXPERIMENT_ROOT))

from common import (  # noqa: E402
    MODEL_LABELS,
    assert_files_exist,
    checkpoint_path,
    default_project_root,
    discover_run_root,
    load_all_predictions,
    normalize_id,
    remap_project_paths,
)


def parse_args():
    parser = argparse.ArgumentParser(description="Objectively select and visualize TP/FP/FN cases.")
    parser.add_argument("--project-root", type=Path, default=default_project_root())
    parser.add_argument("--run-root", type=Path)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--classification-threshold", type=float, default=0.5)
    parser.add_argument("--segmentation-threshold", type=float, default=0.45)
    parser.add_argument("--checkpoint-seed", type=int, default=42)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parents[1] / "results/analysis/cases")
    return parser.parse_args()


def import_branch(branch_dir: Path):
    sys.path.insert(0, str(branch_dir))
    try:
        from dataset import ProstateMultiTaskDataset
        from model import MultiTaskUNet3D
    finally:
        sys.path.pop(0)
    return ProstateMultiTaskDataset, MultiTaskUNet3D


def load_state(path: Path, device):
    import torch

    try:
        checkpoint = torch.load(path, map_location=device, weights_only=False)
    except TypeError:
        checkpoint = torch.load(path, map_location=device)
    return checkpoint["model_state_dict"] if isinstance(checkpoint, dict) and "model_state_dict" in checkpoint else checkpoint


def clean_valid_mask(value) -> bool:
    if pd.isna(value):
        return False
    return str(value).strip().upper() in {"TRUE", "1", "1.0"}


def probability_summary(predictions: pd.DataFrame, seed: int) -> pd.DataFrame:
    """Use the same seed for case classification and segmentation visualization."""
    selected = predictions[predictions["seed"] == seed]
    if selected.empty:
        raise ValueError(f"No stored predictions for checkpoint seed {seed}")
    result = selected.pivot(index=["patient_id", "study_id", "label"], columns="model", values="probability")
    result.columns = [str(c) + "_probability" for c in result.columns]
    return result.reset_index()


def select_cases(table: pd.DataFrame, threshold: float) -> pd.DataFrame:
    primary = table["mtl_probability"]
    table = table.copy()
    table["case_type"] = np.select(
        [
            (table["label"] == 1) & (primary >= threshold),
            (table["label"] == 0) & (primary >= threshold),
            (table["label"] == 1) & (primary < threshold),
        ],
        ["TP", "FP", "FN"],
        default="other",
    )
    selected = []
    for case_type in ("TP", "FP", "FN"):
        candidates = table[table["case_type"] == case_type].copy()
        if case_type in {"TP", "FN"}:
            candidates = candidates[candidates["roi_valid_human_mask"]]
        if candidates.empty:
            raise ValueError(f"No {case_type} case is available under the prespecified rule")
        median_probability = candidates["mtl_probability"].median()
        candidates["distance_to_group_median"] = (candidates["mtl_probability"] - median_probability).abs()
        chosen = candidates.sort_values(
            ["distance_to_group_median", "patient_id", "study_id"]
        ).iloc[0].copy()
        chosen["group_size"] = len(candidates)
        chosen["group_median_probability"] = median_probability
        selected.append(chosen)
    return pd.DataFrame(selected)


def display_image(array):
    finite = np.asarray(array, dtype=float)
    low, high = np.percentile(finite, [1, 99])
    if high <= low:
        return np.zeros_like(finite)
    return np.clip((finite - low) / (high - low), 0, 1)


def draw_case_row(axes, image, gt, mtl_probability, focal_probability, selected_row, seg_threshold):
    modalities = ("T2-weighted", "ADC", "High-b DWI")
    if gt.sum() > 0:
        slice_index = int(np.argmax(gt.sum(axis=(1, 2))))
    else:
        combined = mtl_probability + focal_probability
        slice_index = int(np.argmax(combined.sum(axis=(1, 2))))
    for index, title in enumerate(modalities):
        axes[index].imshow(display_image(image[index, slice_index]), cmap="gray")
        axes[index].set_title(title)
    base = display_image(image[0, slice_index])
    axes[3].imshow(base, cmap="gray")
    if gt[slice_index].max() > 0:
        axes[3].contour(gt[slice_index], levels=[0.5], colors=["#E41A1C"], linewidths=1.4)
    if mtl_probability[slice_index].max() >= seg_threshold:
        axes[3].contour(mtl_probability[slice_index], levels=[seg_threshold], colors=["#00BFC4"], linewidths=1.2)
    if focal_probability[slice_index].max() >= seg_threshold:
        axes[3].contour(focal_probability[slice_index], levels=[seg_threshold], colors=["#FFD92F"], linewidths=1.2)
    axes[3].set_title("Contours: GT / MTL / Focal")
    im1 = axes[4].imshow(mtl_probability[slice_index], cmap="magma", vmin=0, vmax=1)
    axes[4].set_title("MTL probability map")
    im2 = axes[5].imshow(focal_probability[slice_index], cmap="magma", vmin=0, vmax=1)
    axes[5].set_title("MTL+Focal probability map")
    for axis in axes:
        axis.axis("off")
    return slice_index, im1, im2


def main():
    args = parse_args()
    import torch

    project_root = args.project_root.resolve()
    run_root = discover_run_root(project_root, args.run_root)
    predictions = load_all_predictions(run_root)
    probability_models = [
        model for model in MODEL_LABELS
        if model in set(predictions["model"])
    ]
    checkpoints = {
        "mtl": checkpoint_path(run_root, "mtl", args.checkpoint_seed),
        "mtl_focal": checkpoint_path(run_root, "mtl_focal", args.checkpoint_seed),
    }
    assert_files_exist(checkpoints.values(), "segmentation checkpoints")

    test_table_path = Path(__file__).resolve().parents[1] / "configs/splits/test.xlsx"
    if not test_table_path.is_file():
        raise FileNotFoundError(test_table_path)
    test_table = pd.read_excel(test_table_path)
    test_table["patient_id"] = test_table["patient_id"].map(normalize_id)
    test_table["study_id"] = test_table["study_id"].map(normalize_id)
    test_table["has_valid_human_mask_clean"] = test_table["has_valid_human_mask"].map(clean_valid_mask)
    test_table = remap_project_paths(test_table, project_root)

    summary = probability_summary(predictions, args.checkpoint_seed)
    full_table = summary.merge(test_table, on=["patient_id", "study_id"], how="left", validate="one_to_one")
    matched = full_table["t2w_path"].notna()
    unmatched = full_table.loc[~matched, ["patient_id", "study_id"]].copy()
    if not np.array_equal(full_table.loc[matched, "label"].to_numpy(), full_table.loc[matched, "cspca_label"].astype(int).to_numpy()):
        raise ValueError("Prediction labels differ from test-table labels")
    valid_keys = None
    for model_name in ("mtl", "mtl_focal"):
        raw = pd.read_csv(run_root / model_name / f"seed_{args.checkpoint_seed}" / "test/test_predictions.csv")
        raw["patient_id"] = raw["patient_id"].map(normalize_id)
        raw["study_id"] = raw["study_id"].map(normalize_id)
        usable = pd.to_numeric(raw["dice"], errors="coerce").notna()
        keys = set(zip(raw.loc[usable, "patient_id"], raw.loc[usable, "study_id"]))
        if valid_keys is None:
            valid_keys = keys
        elif keys != valid_keys:
            raise ValueError("The two segmentation models have different valid reference-mask cases")
    full_table["roi_valid_human_mask"] = [(p, s) in valid_keys for p, s in zip(full_table["patient_id"], full_table["study_id"])]
    # Select using all stored predictions, before consulting local image availability.
    # Never change the selected case to hide an unavailable source image.
    selected = select_cases(full_table, args.classification_threshold)
    if selected["t2w_path"].isna().any():
        raise ValueError("An objectively selected case does not match the local test table; obtain the exact server table before visualizing it.")

    # Dataset fallback for missing files must not silently produce a blank case figure.
    required_images = []
    for row in selected.itertuples(index=False):
        for column in ("t2w_path", "adc_path", "hbv_path", "whole_gland_mask_path"):
            value = getattr(row, column)
            if not isinstance(value, str) or not value:
                raise ValueError(f"Missing {column} for case {row.patient_id}/{row.study_id}")
            required_images.append(Path(value))
        if row.roi_valid_human_mask:
            required_images.append(Path(row.mask_path_human))
    assert_files_exist(required_images, "selected-case source images and masks")

    device = torch.device(args.device if not args.device.startswith("cuda") or torch.cuda.is_available() else "cpu")
    branch_dir = Path(__file__).resolve().parents[1] / "training" / "mtl"
    Dataset, Model = import_branch(branch_dir)
    models = {}
    for model_name, path in checkpoints.items():
        model = Model(in_channels=3, out_channels=1, base_channels=32, backbone="3dunet").to(device)
        model.load_state_dict(load_state(path, device))
        model.eval()
        models[model_name] = model

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    args.output_dir.mkdir(parents=True, exist_ok=True)
    if not unmatched.empty:
        unmatched.to_csv(args.output_dir / "unmatched_test_study_ids.csv", index=False, encoding="utf-8-sig")
        print(f"WARNING: {len(unmatched)} nonselected prediction records have different study IDs from the local test table; no IDs or source files were changed.")
    selected_records = []
    combined, combined_axes = plt.subplots(3, 6, figsize=(19, 9.8), constrained_layout=True)
    for row_index, selected_row in enumerate(selected.itertuples(index=False)):
        row_series = pd.Series(selected_row._asdict())
        source = full_table[
            (full_table["patient_id"] == str(selected_row.patient_id))
            & (full_table["study_id"] == str(selected_row.study_id))
        ].iloc[[0]]
        dataset = Dataset(
            source,
            mode="val",
            target_shape=(20, 256, 256),
            crop_shape=(20, 192, 192),
            use_roi_crop=True,
            augment=False,
        )
        item = dataset[0]
        if not np.isfinite(item["image"].numpy()).all() or any(float(channel.std()) == 0 for channel in item["image"]):
            raise ValueError(f"Non-finite or blank image channel in case {selected_row.patient_id}")
        image_tensor = item["image"].unsqueeze(0).to(device)
        with torch.inference_mode():
            mtl_logits, mtl_cls = models["mtl"](image_tensor)
            focal_logits, focal_cls = models["mtl_focal"](image_tensor)
        new_probabilities = {"mtl": float(torch.sigmoid(mtl_cls).item()), "mtl_focal": float(torch.sigmoid(focal_cls).item())}
        for model_name, probability in new_probabilities.items():
            stored = float(getattr(selected_row, model_name + "_probability"))
            if not np.isclose(probability, stored, atol=1e-4, rtol=0):
                raise ValueError(f"Re-inference differs from stored probability for {model_name}, {selected_row.patient_id}: {probability} vs {stored}")
        image = item["image"].numpy()
        gt = item["mask"].numpy()[0]
        if selected_row.case_type in {"TP", "FN"} and not gt.any():
            raise ValueError("A selected positive case lost its reference lesion after ROI cropping")
        mtl_probability = torch.sigmoid(mtl_logits)[0, 0].cpu().numpy()
        focal_probability = torch.sigmoid(focal_logits)[0, 0].cpu().numpy()

        figure, axes = plt.subplots(1, 6, figsize=(19, 3.6), constrained_layout=True)
        slice_index, _, _ = draw_case_row(
            axes, image, gt, mtl_probability, focal_probability, row_series, args.segmentation_threshold
        )
        probability_title = ", ".join(
            f"{MODEL_LABELS[model]}={getattr(selected_row, model + '_probability'):.3f}"
            for model in probability_models
        )
        figure.suptitle(
            f"{selected_row.case_type} (MTL, seed {args.checkpoint_seed}): patient {selected_row.patient_id}, slice {slice_index}; {probability_title}",
            fontsize=11,
        )
        file_stem = f"{selected_row.case_type}_{selected_row.patient_id}_{selected_row.study_id}"
        figure.savefig(args.output_dir / f"{file_stem}.png", dpi=300)
        plt.close(figure)

        draw_case_row(
            combined_axes[row_index], image, gt, mtl_probability, focal_probability, row_series, args.segmentation_threshold
        )
        reference_note = "reference mask available" if gt.any() else "no lesion reference mask"
        combined_axes[row_index, 0].text(0, -.10, f"{selected_row.case_type}: {selected_row.patient_id}/{selected_row.study_id}\n{reference_note}", transform=combined_axes[row_index, 0].transAxes, fontsize=9, va="top")
        combined_axes[row_index, 3].text(0, -.10, probability_title.replace(", ", "\n"), transform=combined_axes[row_index, 3].transAxes, fontsize=9, va="top")
        selected_record = {
            "case_type": selected_row.case_type,
            "patient_id": selected_row.patient_id,
            "study_id": selected_row.study_id,
            "label": selected_row.label,
            "selected_slice": slice_index,
            "has_valid_human_mask": bool(selected_row.has_valid_human_mask_clean),
            "checkpoint_seed": args.checkpoint_seed,
            "selection_rule": "MTL same-seed probability closest to group median; TP/FN require nonempty post-ROI human mask",
            "candidate_group_size": int(selected_row.group_size),
            "group_median_probability": float(selected_row.group_median_probability),
        }
        for model in probability_models:
            selected_record[f"{model}_probability"] = float(getattr(selected_row, model + "_probability"))
        for model_name, probability in new_probabilities.items():
            selected_record[f"{model_name}_probability_recomputed"] = probability
            prediction = (mtl_probability if model_name == "mtl" else focal_probability) > args.segmentation_threshold
            selected_record[f"{model_name}_dice_recomputed"] = float((2*(prediction*gt).sum()+1e-5)/(prediction.sum()+gt.sum()+1e-5)) if gt.any() else np.nan
        selected_records.append(selected_record)

    combined.suptitle(
        f"Representative cases, seed {args.checkpoint_seed} (red: reference; cyan: MTL; yellow: MTL+Focal)", fontsize=13
    )
    from matplotlib.cm import ScalarMappable
    combined.colorbar(ScalarMappable(norm=plt.Normalize(0, 1), cmap="magma"), ax=combined_axes[:, 4:].ravel().tolist(), label="Segmentation probability", shrink=.65, pad=.015)
    combined.savefig(args.output_dir / "representative_cases.png", dpi=300)
    combined.savefig(args.output_dir / "representative_cases.pdf")
    plt.close(combined)
    selected_frame = pd.DataFrame(selected_records)
    selected_frame.to_csv(args.output_dir / "selected_cases.csv", index=False, encoding="utf-8-sig")

    lines = [
        "# Case visualization",
        "",
        f"Cases were selected before viewing their images. Using MTL classification probability from the fixed seed {args.checkpoint_seed}, "
        "one TP, one FP and one FN case were chosen as the candidate closest to the median probability of its error group. "
        "TP and FN candidates required a nonempty human lesion mask after ROI cropping. Classification probabilities and segmentation maps use the same seed. "
        "An absent reference contour in an FP case means that no human lesion reference is available, not pathological proof of absence of any abnormality.",
        "",
    ]
    if not unmatched.empty:
        lines += [f"Source-table review: {len(unmatched)} nonselected patient-study pairs did not match the local test.xlsx. Selected cases match exactly and their probabilities were verified by re-inference. See unmatched_test_study_ids.csv; the full test-table provenance remains to be reconciled with the server table.", ""]
    for row in selected_records:
        probability_text = ", ".join(
            f"{MODEL_LABELS[model]}={row[f'{model}_probability']:.3f}"
            for model in probability_models
        )
        lines.append(
            f"- {row['case_type']}: patient {row['patient_id']}, study {row['study_id']}; "
            f"{probability_text}."
        )
    (args.output_dir / "case_visualization_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
